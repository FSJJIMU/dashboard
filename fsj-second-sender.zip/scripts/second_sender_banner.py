#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""second_sender_banner.py — 常駐起動時の案内を出す（batは純ASCIIにする必要があるため）。"""

import json
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))


def main():
    try:
        cfg = json.loads((SCRIPT_DIR / "second_sender.json").read_text(encoding="utf-8"))
        who = cfg.get("display_name") or cfg.get("staff_key")
    except Exception:
        who = "(未設定)"

    print("=" * 58)
    print("  セカンド自動送信 クライアント")
    print("=" * 58)
    print()
    print(f"  このPCの担当者: {who}")
    print()
    print("  ・ダッシュボードで自分のトグルをONにすると送信を始めます")
    print("  ・OFFの間は何もしません。閉じずに置いておいて構いません")
    print("  ・Chrome版LINEを開いたままにしてください（閉じると送信できません）")
    # 隠れた窓は画面更新が止まる。実測で、最小化するとページの更新は0回、
    # タイマーも1/20に落ちた。別の仮想デスクトップに置くのも同じ扱いになる。
    print("  ・Chrome版LINEは最小化せず、出したままが最速です"
          "（別のデスクトップに置くのも最小化と同じ扱いになります）")
    print("  ・終了するときは Ctrl+C を2回、またはこのウィンドウを閉じてください")
    print()
    print("=" * 58)
    print()

    # Chrome版LINEに繋がるか先に確かめて、繋がらなければ理由を出す
    try:
        import line_chrome_check
        line_chrome_check.main()
    except SystemExit:
        pass
    except Exception as e:
        print(f"[情報] Chrome版LINEの確認は省略しました: {e}")
    print()


if __name__ == "__main__":
    main()
