#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""second_sender.py — セカンド自動送信クライアント（案件手配員のPCで常駐させる）

案件紹介ROOMでプレイヤーが取得（リプライ）したら、その人の1:1トークに
トランジットROOMのセカンド本文を送る。送信は事務員本人のLINEアカウントから
Chrome版LINEを操作して行うため、このスクリプトは各事務員のPCで動かす。

★宛先は「取得のリプライを送ったメッセージ」から特定する。
  グループのメッセージ要素には送信者の内部IDが入っており、Webhookで受け取った
  message_id と突き合わせれば本人を一意に特定できる。名前で探さないので、
  同姓の知人や本人の2つ目のアカウントと取り違えない。
  事前の登録作業も不要で、どの事務員のPCでもそのまま動く。

★安全のため既定はドライラン。--live を付けたときだけ実際に送信する。

送信しない条件（どれか1つでも当てはまれば必ず止まる）:
  ・ダッシュボードで自分のトグルがOFF（ONにできるのは常に1人だけ）
  ・トグルをONにした時刻より前の取得（手作業で送致済みのため）
  ・取得の判定が「曖昧」（どの案件宛てか確定できない）
  ・取得リプライのメッセージが画面に見つからない
  ・セカンド本文が見つからない／案件番号が本文と一致しない
  ・同じ案件が既にキューにある（二重送信の防止）

使い方:
    python -X utf8 scripts/second_sender.py --once            # 1回だけ・ドライラン
    python -X utf8 scripts/second_sender.py                   # 常駐・ドライラン
    python -X utf8 scripts/second_sender.py --live --confirm  # 実送信・毎回確認
    python -X utf8 scripts/second_sender.py --live            # 実送信・無人
    python -X utf8 scripts/second_sender.py --status          # 状況表示

初回設定: scripts/second_sender.json に自分の識別名を書く
    {"staff_key": "kawakami", "display_name": "川上"}
"""

import argparse
import http.client
import json
import re
import shutil
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import line_pull as lp          # noqa: E402
import detect_claims as dc      # noqa: E402

CONFIG_PATH = SCRIPT_DIR / "second_sender.json"
SETTING_KEY = "second_auto_send"
# ★テストモードは全員共通。PCごとの設定ファイルではなくDBを正とする。
#   PCごとに持つと、新しい事務員が初期設定しただけでその人だけ本番送信になり、
#   気づかないまま実際のプレイヤーへ送ってしまう。
TEST_KEY = "second_test_mode"
TRANSIT_ROOM = "トランジットROOM"
LOOKBACK_HOURS = 6              # 取得判定に使う直近の時間幅
POLL_SECONDS = 2                # 送信担当のとき（往復を減らしたぶん詰めた）
# ★送信担当でないときは間隔を空ける。
#   「開いたままで大丈夫」と案内している以上、3交代の3人が
#   一日中開けっぱなしになる。全員が5秒ごとに問い合わせると
#   通信量が3倍かかり、無料枠(10GB/月)を無駄に削る。
#   担当になったことに30秒以内に気づければ実用上まったく困らない。
IDLE_POLL_SECONDS = 30
# ★Realtimeで通知を受けられているときの「保険」の間隔。
#   通知が来た瞬間に動くので、待つ側の間隔は長くてよい。
#   それでも0にしないのは、接続が切れている間の分が届かないため。
#   速さはRealtimeが、取りこぼしの無さはこの見回りが担保する。
# ★60秒では長すぎることが実測で分かった。
#   668件を測ると、12%で通知が届いておらず、その待ちの中央値は32.6秒
#   ＝ちょうど60秒の半分。取りこぼしたぶんをこの見回りが拾っている形。
#   15秒にすると、取りこぼしても待ちは平均7.5秒で済む。
#   通信量は担当PC1台あたり月39MB→155MB（無料枠5GBの3%）。
SAFETY_POLL_SECONDS = 15

# ★これより古い取得はキューに積まない。
#   セカンドはお客様への連絡期限（受取から15分）に間に合わせるものなので、
#   時間が経った取得は既に手動で送られていると考えるのが自然。
#   この歯止めが無いと、システムを有効にした瞬間に過去分が一斉送信される。
MAX_CLAIM_AGE_MINUTES = 15

# セカンド本文が投稿されるのを待つ上限。
# ★取得の検知が、本文がトランジットROOMに流れるより先になることがある。
#   実際に9442725で2.5秒先行し、本文があるのに送れなかった。
#   キュー投入時に取れなかった本文をそのまま信じて即失敗にすると、
#   直後に本文が来ても二度と送られない。
SECOND_WAIT_SECONDS = 300
SECOND_RECHECK_SECONDS = 5      # 待っている間、本文を探し直す間隔

# すでに取得済みの案件にリプライされたとき、そのルームに知らせる。
# ★狙いは「気づけないこと」をなくすこと。
#   セカンドが二重に送られることは一意制約で防げているが、
#   リプライした本人も事務員も「取れた」と思い込んだままになる。
#   別の案件のリプライと見分けが付かないので、その場で言う。
WRONG_REPLY_NOTICE = True
# 1回の巡回で出す通知の上限。
# ★万一まとめて誤検知したとき、ルームを埋め尽くさないための歯止め。
#   人が読む場所なので、多すぎると本物の連絡が流れてしまう。
WRONG_REPLY_MAX_PER_CYCLE = 3

# ★「その案件が悪い」のか「このPCが壊れている」のかを分ける。
#   環境側の失敗なら、案件を失敗印で終わらせずに待ち行列へ戻す。
#   2026/08/22 の夜、LINEのタブが描画を止めたPCが48分間で9件を
#   すべて失敗にした。案件に罪はなく、別のPCなら送れたはずだった。
ENV_FAILURE = (
    "見つかりません（画面",          # リプライが描かれていない
    "CDP 到達不可",                  # Chromeが落ちた
    "拡張ターゲット未検出",          # LINEのタブが無い
    "navigate 最大試行超過",         # ルームを開けない
    "compose 値が入らず",            # 入力欄が反応しない
    "フォーカス失敗",
)
# 待ち行列へ戻して再挑戦する時間の上限。
# ★セカンドは受取から15分以内に届いてこそ意味がある。
#   それを過ぎたら、機械が延々と試すより人が手で送った方が早い。
RETRY_WINDOW_MINUTES = 15
# 同じ案件を何回まで試すか。
# ★環境のせいに見えても、その案件だけが通らないことはある。
#   際限なく試すと、後から来た正常な案件が待たされる。
MAX_TRIES_PER_CASE = 3
# 何回続けて環境の失敗が出たら「このPCが壊れている」とみなすか。
REPAIR_AFTER = 2                # LINEのタブを読み込み直す
HALT_AFTER = 3                  # 案件を取るのをやめて休む
HALT_COOLDOWN_SECONDS = 60

# このPCの調子。プロセス内だけで持つ（再起動すれば白紙に戻る）。
HEALTH = {"streak": 0, "halt_until": 0.0, "tries": {}, "told": False,
          "sick": False, "next_probe": 0.0, "bad_probes": 0}
# LINEが使える状態かを見直す間隔。
# ★起動時に一度だけ確認しても足りない。LINEは動かしている最中に
#   ログアウトされることがある（端末の再連携・長時間放置など）。
#   起きたことに気づけないと、ダッシュボードは「稼働中」のまま
#   そのPCが送信担当にされ、来た案件が全部失敗する。
HEALTH_PROBE_SECONDS = 60


def is_env_failure(msg):
    return any(k in msg for k in ENV_FAILURE)


def note_health(result, live):
    """1件の結果を受けて、このPCの調子を更新する。

    result は3通り:
      "ok"   送れた           → 調子を戻す
      "env"  環境が壊れている → 連続を数える
      "case" その案件の事情   → 数えない

    ★案件固有の失敗を数えてはいけない。
      「相手がまだ友だちに入っていない」プレイヤーが3人続いただけで
      「このPCが壊れた」と判断し、正常なPCが休んでしまう。
      止めるべきなのは、環境が壊れているときだけ。

    壊れていると判断したら、その場でLINEのタブを読み込み直す。
    直せないときは案件を取るのをやめて休む。取ったまま失敗を
    積み上げるより、他のPCや後の再挑戦に回した方がよい。
    """
    if result == "case":
        return
    if result == "ok":
        if HEALTH["streak"]:
            log("送信が通りました。通常の動作に戻ります")
        HEALTH["streak"] = 0
        HEALTH["halt_until"] = 0.0
        HEALTH["told"] = False
        HEALTH["sick"] = False
        # 何日も動かすので、際限なく覚えない。
        if len(HEALTH["tries"]) > 500:
            HEALTH["tries"].clear()
        return
    HEALTH["streak"] += 1
    n = HEALTH["streak"]
    if n == REPAIR_AFTER:
        log(f"{n}件続けて送れませんでした。Chrome版LINEを読み込み直します")
        if not live:
            log("（ドライランなので読み込み直しません）")
        else:
            log(_repair_line())
    elif n >= HALT_AFTER:
        HEALTH["halt_until"] = time.time() + HALT_COOLDOWN_SECONDS
        # ★ここで sick を立ててはいけない。
        #   sick は「LINEが使えない」印で、解除の条件は probe が ok を
        #   返すこと。タブが固まっているだけのとき probe は ok を返すので、
        #   次の巡回で即座に解除され「使える状態に戻りました」と嘘をつく。
        #   さらに sick の間は問い合わせを止めるため、送信して直ったか
        #   確かめる機会そのものが無くなり、二度と復帰しない。
        #   代わりに、次の巡回で必ず確認し直させる（ログアウトならそこで捕まる）。
        HEALTH["next_probe"] = 0.0
        # ★案内は最初の1回だけ。60秒ごとに枠を出すと、
        #   本当に読んでほしい最初の1枚が流れて見えなくなる。
        if HEALTH["told"]:
            return
        HEALTH["told"] = True
        print()
        print("=" * 58)
        print(f"  {n}件続けて送れていません")
        print("  このPCのChrome版LINEが応答していない可能性があります。")
        print()
        print("  ・Chrome版LINEのタブを開き直してください")
        print("  ・案件は待ち行列に残してあるので、直れば自動で送ります")
        print("=" * 58)
        print()


def _repair_line():
    """LINEを使える状態に戻す。戻り値: 画面に出す一言

    ★2段構え。
      タブは生きているのに描画が止まっている → 読み込み直しで戻る。
      Chromeごと落ちている → 読み込み直しは届かないので、起動し直す。
      前者だけを実装すると、後者のとき「読み込み直せませんでした」と
      出して何もしない。事務員には同じ「送れない」にしか見えない。
    """
    try:
        import line_chrome
        if line_chrome.repair():
            return "読み込み直しました"
    except Exception as ex:
        logged = str(ex)[:60]
        try:
            import line_chrome_check as lcc
            state = lcc.probe()
            if state in ("noport", "noext"):
                lcc.open_in_chrome(lcc.LINE_PAGE_URL)
                return "Chrome版LINEを開き直しています"
        except Exception:
            pass
        return f"読み込み直せませんでした: {logged}"
    return "読み込み直せませんでした"


def check_line_health(url, key, staff):
    """LINEがまだ使えるか、ときどき見直す。

    使えないと分かったら生存報告を消す。
    ★ダッシュボードの「稼働中」は client_seen_at で決まる。
      消しておけば「PC未起動」と出るので、送れないPCが
      送信担当に選ばれない。新しい画面も新しい印も要らない。
    """
    if (staff.get("send_mode") or "chrome").lower() != "chrome":
        return
    if time.time() < HEALTH["next_probe"]:
        return
    HEALTH["next_probe"] = time.time() + HEALTH_PROBE_SECONDS
    try:
        import line_chrome_check as lcc
        state = lcc.probe()
    except Exception:
        return                      # 確認できないことを不調とはみなさない
    if state == "ok":
        HEALTH["bad_probes"] = 0
        if HEALTH["sick"]:
            HEALTH["sick"] = False
            HEALTH["told"] = False
            log("Chrome版LINEが使える状態に戻りました")
        return
    if HEALTH["sick"]:
        return
    # ★1回の読み取りだけでPCを止めない。
    #   ここで止めると、そのPCは案件を一切受け取らなくなる。
    #   読み込み途中を掴んだ・一瞬つながらなかった、程度のことで
    #   稼働中のPCを落とすほうが、ログアウトの発見が1分遅れるより痛い。
    HEALTH["bad_probes"] = HEALTH.get("bad_probes", 0) + 1
    if HEALTH["bad_probes"] < 2:
        return
    HEALTH["sick"] = True
    説明 = {"noport": "Chromeが起動していません",
            "noext": "LINEのタブが閉じられています",
            "nologin": "LINEからログアウトされています",
            "notinstalled": "LINE拡張機能が入っていません"}
    print()
    print("=" * 58)
    print("  いま送信できません")
    print("  " + 説明.get(state, state))
    print()
    print("  直すまで、このPCは「未起動」として扱われます")
    print("  （送信担当に選ばれないので、案件は他のPCへ回ります）")
    print("=" * 58)
    print()
    try:
        api(url, key, "PATCH", "staff",
            {"staff_key": f"eq.{staff['staff_key']}"},
            body={"client_seen_at": None}, prefer="return=minimal")
    except Exception:
        pass


def halted():
    """休んでいる間か。休み明けに1件だけ試して様子を見る。"""
    left = HEALTH["halt_until"] - time.time()
    if left > 0:
        status(f"送れない状態が続いています。あと{int(left)}秒で試します")
        return True
    return False


_status_shown = False


def _cols():
    """画面の桁数。1桁残すのは、右端まで書くと勝手に改行する端末があるため。"""
    return max(20, shutil.get_terminal_size((80, 25)).columns - 1)


def _fit(text, cols):
    """ちょうど cols 桁になるよう、切るか空白で埋めるかする。

    ★数えるのは「文字数」ではなく「桁数」。
      日本語は1文字で2桁ぶん場所を取るので、文字数で埋めると
      画面幅を超えて折り返す。折り返すと \\r は最後の物理行にしか
      戻らないため、上書きしたはずの行が履歴に残り続ける。
      （これで「監視中」が延々と積み上がっていた）
      全角か半角かの区別が曖昧な記号（— など）は、広い側で数える。
      狭く見積もると折り返す＝直したい症状そのものが再発するため。
    """
    out, n = [], 0
    for c in text:
        cw = 2 if unicodedata.east_asian_width(c) in "WFA" else 1
        if n + cw > cols:
            break
        out.append(c)
        n += cw
    return "".join(out) + " " * (cols - n)


def status(text):
    """待機中の表示。同じ行を書き換えるだけで、履歴には残さない。

    画面でないとき（ログファイルへ流しているとき）は書かない。
    上書きが効かず、同じ内容で埋め尽くされてしまうため。
    """
    global _status_shown
    if not sys.stdout.isatty():
        return
    sys.stdout.write(
        "\r" + _fit(f"[{datetime.now(lp.JST):%H:%M:%S}] {text}", _cols()))
    sys.stdout.flush()
    _status_shown = True


# 詳しい表示を出すか。
# ★既定は出さない。事務員の画面は、これまでと同じ行だけにする。
#   出したいときは scripts/second_sender.json に
#   {"verbose": true} を足すか、環境変数 FSJ_VERBOSE=1 で動かす。
VERBOSE = bool(__import__("os").environ.get("FSJ_VERBOSE"))


def log_detail(text):
    """診断用。ふだんは出さない。

    ここに回すのは「システムが自分で処理した出来事」で、
    事務員が何かする必要がないもの。記録はDBに残るので、
    管理ページから後で追える。
    """
    if VERBOSE:
        log(text)


def log(text):
    """履歴に残す。待機表示が出ていれば消してから書く。"""
    global _status_shown
    if _status_shown:
        sys.stdout.write("\r" + " " * _cols() + "\r")
        _status_shown = False
    print(f"[{datetime.now(lp.JST):%H:%M:%S}] {text}", flush=True)


# ══════════════════════════════════════════════════════════
#  Supabase 読み書き
# ══════════════════════════════════════════════════════════

def load_staff():
    if not CONFIG_PATH.exists():
        sys.exit(f"{CONFIG_PATH} を作って自分の識別名を書いてください:\n"
                 '{"staff_key": "kawakami", "display_name": "川上"}')
    global VERBOSE
    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    if not cfg.get("staff_key"):
        sys.exit(f"{CONFIG_PATH} に staff_key がありません")
    if cfg.get("verbose"):
        VERBOSE = True
    return cfg


def load_sender(staff):
    """送信方式を選ぶ。

    chrome … Chrome拡張版LINEをCDP経由で操作する（既定）。
             ページ内でJSを実行するだけなので**マウスもキーボードも奪わない**。
             事務員は普通に作業しながら自動送信を走らせられる。
             送信先の確認も3段階（サイドバー行→ヘッダー名とdata-mid→貼付直前）で堅い。
    pc     … PC版LINEをpyautoguiで操作する。実行中はPCを触れなくなるうえ、
             座標クリック頼みで確認も弱いため、Chromeが使えない場合の予備。
    """
    mode = (staff.get("send_mode") or "chrome").lower()
    if mode == "pc":
        # line_pc.py は配布物に入れていない（実行中PCを占有するため）。
        # 設定だけ書き換えられたときに、何が起きたか分かるようにする。
        try:
            import line_pc
        except ImportError:
            sys.exit("send_mode に \"pc\" が指定されていますが、"
                     "この配布物にはPC版LINEの送信方式が入っていません。\n"
                     "scripts/second_sender.json の send_mode を消してください"
                     "（既定のChrome版が使われます）。")
        return line_pc
    import line_chrome
    return line_chrome


_conn = None
_conn_host = None


def _close_connection():
    global _conn
    if _conn is not None:
        try:
            _conn.close()
        except Exception:
            pass
        _conn = None


def _connection(url):
    """HTTPS接続を張りっぱなしにして使い回す。

    ★毎回つなぎ直してはいけない。
      そのたびにTLSの握手が入り、証明書のやり取りも発生する。
      実測で1回114ms → 58ms（2倍速）。2秒ごとに回すなら、
      この待ち時間がそのまま「取得から送信までの遅れ」になる。
    """
    global _conn, _conn_host
    host = urllib.parse.urlparse(url).hostname
    if _conn is None or _conn_host != host:
        _close_connection()
        _conn = http.client.HTTPSConnection(host, timeout=60)
        _conn_host = host
    return _conn


def api(url, key, method, table, params=None, body=None, prefer=None):
    q = ("?" + urllib.parse.urlencode(params)) if params else ""
    path = f"/rest/v1/{table}{q}"
    headers = {"apikey": key, "Authorization": f"Bearer {key}",
               "Content-Type": "application/json"}
    if prefer:
        headers["Prefer"] = prefer
    data = json.dumps(body).encode() if body is not None else None

    # 接続はサーバ側から切られることがある。1度だけ張り直して試す。
    for attempt in (1, 2):
        try:
            conn = _connection(url)
            conn.request(method, path, body=data, headers=headers)
            res = conn.getresponse()
            raw = res.read().decode("utf-8")     # 読み切らないと次が使えない
            if res.status >= 400:
                raise RuntimeError(
                    f"{method} {table}: HTTP {res.status} {raw[:300]}")
            return json.loads(raw) if raw.strip() else []
        except RuntimeError:
            raise                                 # HTTPエラーは再試行しない
        except Exception:
            _close_connection()
            if attempt == 2:
                raise


def my_turn_since(url, key, staff_key):
    """自分が送信担当か、そしていつONにしたか。

    ★ONにした時刻より前の取得には送らない。
      ONにする前の案件は事務員が手作業で送致済みのはずで、
      後追いで自動送信すると二重送信になる。
    """
    rows = api(url, key, "GET", "staff",
               {"staff_key": f"eq.{staff_key}",
                "select": "auto_send,display_name,auto_send_on_at"})
    if not rows or not rows[0].get("auto_send"):
        return None
    return lp.parse_ts(rows[0]["auto_send_on_at"]) if rows[0].get("auto_send_on_at") \
        else datetime.now(lp.JST)


def is_my_turn(url, key, staff_key):
    """自分のPCが送信担当か（ダッシュボードで自分のトグルがONか）。

    ★全体の1つのスイッチではなく、事務員ごとのトグルで判定する。
      前のシフトの人がクライアントを閉じ忘れても、その人のトグルは
      交代時にOFFになるので、そのPCからは送信されない。
      DB側のトリガーで「同時にONにできるのは1人だけ」も保証している。
    """
    rows = api(url, key, "GET", "staff",
               {"staff_key": f"eq.{staff_key}", "select": "auto_send,display_name"})
    if not rows:
        return False, None
    return bool(rows[0].get("auto_send")), rows[0].get("display_name")


def heartbeat(url, key, staff_key):
    """自分のPCでクライアントが動いていることをDBに記録する。

    トグルがONでもクライアントが起動していなければ送信されないので、
    ダッシュボードで「稼働中／未起動」を見分けられるようにする。
    """
    try:
        api(url, key, "PATCH", "staff", {"staff_key": f"eq.{staff_key}"},
            body={"client_seen_at": datetime.now(lp.JST).isoformat()},
            prefer="return=minimal")
    except Exception:
        pass          # 生存報告の失敗で本処理を止めない


def current_sender(url, key):
    """いま送信担当になっている事務員（表示用）。"""
    rows = api(url, key, "GET", "staff",
               {"auto_send": "eq.true", "select": "staff_key,display_name"})
    return rows[0] if rows else None


def poll_once(url, key, staff_key, last_event_id):
    """巡回1回分の状態を1往復で取る。使えないときは None。

    ★往復を減らすのは通信量のためだけではない。
      1回あたりの待ち時間が4分の1になるので、取得から送信までが速くなる。
      セカンドは受取から15分が期限なので、ここは落とせない。

    サーバ側に関数が無い（SQLをまだ実行していない）場合は None を返し、
    呼び出し側が従来の4回問い合わせに戻る。更新の順序に依存させない。
    """
    try:
        r = api(url, key, "POST", "rpc/sender_poll",
                body={"p_staff": staff_key, "p_last_event_id": last_event_id or 0})
    except Exception:
        return None
    # PostgRESTはスカラー戻り値をそのまま返す
    return r if isinstance(r, dict) else None


def apply_mode(staff, mode):
    """sender_poll が返したモードを staff に反映する（判定は下と同じ）。"""
    cfg = mode if isinstance(mode, dict) else None
    if cfg is None:
        log("[警告] テストモード設定が見つかりません。安全のためテストモードで動きます。")
        cfg = {"enabled": True}
    staff["test_mode"] = bool(cfg.get("enabled", True)) or bool(
        staff.get("force_test_mode"))
    staff["test_redirect_to"] = cfg.get("redirect_to") or "FSJ事務bot"
    staff["test_report_room"] = cfg.get("report_room") or "テストトランジットROOM"
    return staff


def resolve_test_mode(url, key, staff):
    """テストモードかどうかをDBから読み、staff に反映する。

    ★PCごとの設定ファイルには置かない。事務員が「はじめに実行」をすると
      設定ファイルが作り直されるため、そこにテストモードを書いていると
      新しい人だけ本番送信になる。全員が同じ設定を見るようにする。

    ★読めなかった場合・設定が無い場合はテストモードとして扱う。
      判断がつかないときに実際のプレイヤーへ送るより、送らない方が安全。
      （本番に切り替えたのに送られない事故は、画面を見ればすぐ気づける）
    """
    cfg = None
    try:
        rows = api(url, key, "GET", "app_settings",
                   {"key": f"eq.{TEST_KEY}", "select": "value"})
        cfg = rows[0]["value"] if rows else None
    except Exception as ex:
        log(f"[警告] テストモード設定を読めません（{str(ex)[:60]}）")
    if not isinstance(cfg, dict):
        log("[警告] テストモード設定が見つかりません。安全のためテストモードで動きます。")
        cfg = {"enabled": True}

    # force_test_mode はそのPCだけを強制的にテストにする逃げ道。
    # 逆向き（1台だけ本番にする）は用意しない。事故の向きが違う。
    staff["test_mode"] = bool(cfg.get("enabled", True)) or bool(
        staff.get("force_test_mode"))
    staff["test_redirect_to"] = cfg.get("redirect_to") or "FSJ事務bot"
    staff["test_report_room"] = cfg.get("report_room") or "テストトランジットROOM"
    return staff


# ══════════════════════════════════════════════════════════
#  取得の検知 → キュー投入
# ══════════════════════════════════════════════════════════

_EVENT_COLS = ("id,event_type,group_id,user_id,message_id,text,"
               "quoted_message_id,case_nos,sent_at")


def recent_events(url, key, hours):
    """直近hours分のイベントを一度に取る（初回・単発用）。"""
    since = (datetime.now(lp.JST) - timedelta(hours=hours)).isoformat()
    return api(url, key, "GET", "line_events", {
        "select": _EVENT_COLS,
        "sent_at": f"gte.{since}", "order": "id.asc", "limit": 5000})


class EventWindow:
    """直近N時間のイベントを手元に持ち、増えた分だけ取りに行く。

    ★毎回6時間分を取り直してはいけない。
      1回169KB × 5秒ごと ＝ 1か月83GB になり、無料枠(10GB/月)を
      数日で使い切って受信が止まる（＝取り返せない取りこぼし）。

    ★かといって窓は狭められない。
      「名前だけの短い返信」をどの案件に紐づけるかは、前に流れた
      ファーストを見て決めるため、過去数時間分が手元に要る。

    そこで窓は保持したまま、差分だけ取る。idは連番なのでこれが使える。
    """

    def __init__(self, hours):
        self.hours = hours
        self.rows = []
        self.last_id = None

    def refresh(self, url, key):
        if self.last_id is None:
            since = (datetime.now(lp.JST) - timedelta(hours=self.hours)).isoformat()
            new = api(url, key, "GET", "line_events", {
                "select": _EVENT_COLS, "sent_at": f"gte.{since}",
                "order": "id.asc", "limit": 5000})
            self.rows = list(new)
        else:
            new = api(url, key, "GET", "line_events", {
                "select": _EVENT_COLS, "id": f"gt.{self.last_id}",
                "order": "id.asc", "limit": 5000})
            self.rows.extend(new)

        # ★last_id は取得した生の最大値で進める。
        #   下の切り捨て後の一覧から取り直すと値が戻り、同じ行を
        #   何度も取りに行くことになる。
        if new:
            self.last_id = max(r["id"] for r in new)
        elif self.last_id is None:
            self.last_id = 0

        cutoff = datetime.now(lp.JST) - timedelta(hours=self.hours)
        self.rows = [r for r in self.rows if lp.parse_ts(r["sent_at"]) >= cutoff]
        return self.rows


def find_second(url, key, transit_gid, case_no):
    """トランジットROOMから該当案件のセカンド本文を取る（最新を採用）。"""
    if not transit_gid:
        return ""
    rows = api(url, key, "GET", "line_events", {
        "select": "text,sent_at", "group_id": f"eq.{transit_gid}",
        "case_nos": f"cs.{{{case_no}}}", "order": "id.desc", "limit": 1})
    return (rows[0].get("text") or "") if rows else ""


# このセッションで既にキューへ入れた案件。
# ★これが無いと、本文待ちで pending が残っている間ずっと
#   同じ案件を拾い直し、[検知]を2秒ごとに出し、
#   セカンド本文の問い合わせと投入も毎回やってしまう。
_enqueued = set()


# このセッションで処理済みのリプライ。同じものを何度も見ないため。
_seen_replies = set()


def _ns(s):
    """空白・記号の幅の違いを無視して比べるための形にする。"""
    s = (s or "").replace("\u3000", " ")
    return "".join(c for c in s if not c.isspace()).strip().lower()


def _undouble(s):
    """「山田山田」のように同じ語を繰り返した名乗りを1つに戻す。"""
    n = len(s)
    return s[: n // 2] if n >= 4 and n % 2 == 0 and s[: n // 2] == s[n // 2:] else s


# 名乗りには出てこない語。ここに当たったら名前ではないと判断する。
# ★通知はルームにいる全員が読む。ふつうの連絡に割り込むと、
#   そのうち誰も読まなくなる。落とす側を厚くしておく。
_NOT_NAME = re.compile(
    r"案件|詳細|対応|確認|連絡|現場|到着|出発|完了|報告|お客|時間|本日|明日"
    r"|至急|よろしく|お願い|すみません|申し訳|ありがとう|了解|承知|不在|留守"
    r"|折り返し|転送|送致|移動|引き継|キャンセル|無理|不可|できま|ました"
    r"|します|ですか|どう|いつ|どこ|なぜ"
    # ↓ 実際の案件紹介ROOM（15か月・約5万件）を調べて足したもの。
    #   架電の途中経過・事務連絡・枠取りが、短いために名乗りと
    #   見分けが付かなかった。
    r"|不通|不出|話中|話し中|架電|伝達|呼出|呼び出|応答|出ない|くださ"
    r"|コール|鳴ら|出ず|リスケ|追記|情報共有|枠取|ポジション|変更"
    r"|クロージング|重要|お疲れ|希望|画像|スタンプ|済|動画"
    r"|再度|差し戻|送信間違|稼働|電源|理解|冗談|追撃|間違い"
    # 作業内容そのもの。案件の説明であって名乗りではない。
    r"|バッテリー|上がり|タイヤ|パンク|ガス欠|インロック|レッカー|積車"
    r"|キー|カギ|鍵|ハチ|蜂|トラブル"
    r"|周知|予約|急ぎ|学生")
# ★これ以上は増やさない。
#   15か月・35,072件を調べて、名乗り以外で残るのは15件（0.04%）まで来た。
#   語を足すほど、同じ字を含む名前を巻き添えにする危険が上がる。
#   ここから先は「取りこぼさない」ことを優先する。

# 絵文字。実際の名乗り410件には1つも入っていなかった。
_EMOJI = re.compile("[🀀-🫿☀-➿️‍]")

# これだけで送られてきたら名乗りではない、と分かるもの。
# ★大文字小文字をそろえてから比べる。「OK」を見落としていた。
_AIZUCHI = {"はい", "うん", "ok", "yes", "no", "わかりました", "大丈夫",
            "りょうかい", "しょうち"}

# 文の途中で切れたものを落とす（「この案件は」など）。
# ★「と」「の」「や」は入れない。
#   名前の末尾によく出る（やまもと・おおの・なおや）。
#   助詞として落とすと、本物の名乗りまで取りこぼす。
_PARTICLE_END = ("は", "が", "を", "に", "で", "も", "へ",
                 "から", "まで", "けど", "ので")


def looks_like_name_claim(text, replier_name):
    """取得の名乗りらしいか。誤リプライを知らせる前の歯止め。

    ★名乗り方は人によってばらつく。
      「やまもと」「やま」「山田山田」「yamamoto」「ume」のように、
      ひらがな・一部だけ・繰り返し・ローマ字もある。
      名前と一字一句合うことを条件にすると、そのほとんどを取りこぼす。

    そこで2段にする。
      ① 名前と結びつくなら通す（漢字・前方一致・繰り返しを戻して比較）
      ② 結びつかなくても、「名前ではない」と分かる特徴が無ければ通す

    ②を置くのは、読み方の表がどこにも無いため。
    「やまもと→山本」を機械的に確かめる手段が無いので、
    代わりに「名乗りには出てこない語」で落とす。

    ★通知はルームに出るが、内容は「この案件はもう取得済み」という
      事実で、誰かを咎めるものではない。取りこぼして誰も気づかない方が
      困るので、迷ったときは通す側に倒す。
    """
    s = (text or "").strip()
    # ★会社名や肩書きを前に付けて名乗る人がいる。
    #   「（株）○○○○○担当△△」のような書き方は14字あり、上限12で弾かれていた。
    #   名前が中に入っているなら名乗りとみなしてよいので、
    #   その場合だけ上限を伸ばす。文らしさの判定は下でそのまま効く。
    _base = _ns(replier_name)
    _named = bool(_base) and len(_base) >= 2 and _base[:2] in _ns(s)
    if not (1 <= len(s) <= (24 if _named else 12)):
        return False
    if any(ch in s for ch in "。、．，？！?!\n"):
        return False
    if s.count(" ") + s.count("\u3000") > 1:      # 語が3つ以上＝文
        return False

    # ★実際の名乗り410件を調べたところ、数字・【】・「時」「県」は
    #   ひとつも含まれていなかった。逆にこれらを含む短文は、
    #   時間の連絡（18時／13-14時）・案件種別（【RS】）・
    #   地域（大分県）・金額（○○40）などで、名乗りではない。
    if re.search(r"[0-9０-９【】]|時|県", s):
        return False
    # 「そうです」「行ってきます」のような言い切り
    if s.endswith(("です", "ます", "でした", "ません", "ました")):
        return False

    tok = _undouble(_ns(s))
    if not tok:
        return False

    # ① 名前と結びつくか
    base = _ns(replier_name)
    if base and (tok in base or base in tok):
        return True
    # 会社名・肩書き付き（「（株）○○○○○担当△△」）もここで拾う
    if _named:
        return True

    # ② 名前でないと分かる特徴があれば落とす
    if tok in _AIZUCHI:
        return False
    if _EMOJI.search(s):
        return False
    # 英数字だけの名乗りは ume / Ishii / yamamoto のように3文字以上。
    # 「m」「go」のような1〜2文字は名前ではない（実データで確認）。
    if tok.isascii() and len(tok) < 3:
        return False
    if _NOT_NAME.search(s):
        return False
    if len(s) >= 3 and s.endswith(_PARTICLE_END):
        return False
    # 「○○さん」は他の人を指している＝自分の名乗りではない（代理取得の連絡）
    if s.endswith(("さん", "さま", "様")):
        return False
    # ★終助詞（ね・よ・な）では落とさない。
    #   「たちばな」「あかね」のように名前の末尾によく出る。
    #   代わりに、名前には絶対に含まれない言い回しで落とす。
    if any(w in s for w in ("です", "ました", "ません", "でしょ")):
        return False
    if tok.isdigit():                              # 案件番号だけの返信
        return False
    return True


def already_done(url, key, case_no):
    """その案件がもう送り終わっているか。送信済みなら中身を返す。"""
    rows = api(url, key, "GET", "dispatch_queue",
               {"select": "status,player_line_name,claim_message_id",
                "case_no": f"eq.{case_no}", "order": "id.asc", "limit": 5})
    return next((r for r in rows if r["status"] in ("sent", "test")), None)


def enqueue(url, key, groups, master, transit_gid, events, since=None):
    """新しく検知した取得をキューに積む。既にあるものは一意制約で弾かれる。

    since（トグルをONにした時刻）より前の取得は積まない。

    戻り値: (積んだもの, すでに取得済みの案件へのリプライ)
    """
    added, wrong = [], []
    by_room = {}
    for e in events:
        name = groups.get(e.get("group_id")) or ""
        if "案件紹介" in name or "送客" in name:
            by_room.setdefault((e["group_id"], name), []).append(e)

    # ①トグルをONにした時刻より前は対象外（ONにする前は手作業で送致済み）
    # ②さらに15分より古いものも対象外（クライアントが長時間止まっていた場合の保険）
    # ★2つに分ける。
    #   誤リプライを知らせるかどうかは「いつリプライされたか」だけで決める。
    #   送るかどうかだけ、トグルをONにした時刻でも絞る。
    #   一緒にすると、交代直後は「ONより前の誤リプライ」を黙って捨ててしまい、
    #   同じ間違いなのに事務員が誰かで挙動が変わる。
    age_cutoff = datetime.now(lp.JST) - timedelta(minutes=MAX_CLAIM_AGE_MINUTES)
    send_cutoff = since if (since and since > age_cutoff) else age_cutoff
    for (gid, name), evs in by_room.items():
        for r in dc.detect(evs, master, name):
            if r["confidence"] not in ("確定", "推定"):
                continue
            if r["case_no"] in _enqueued:
                continue
            if r.get("message_id") in _seen_replies:
                continue
            if lp.parse_ts(r["sent_at"]) < age_cutoff:
                continue
            # ★すでに送り終わった案件へのリプライか。
            #   事務員が交代したあと、プレイヤーが別の案件と間違えて
            #   古い投稿にリプライすることがある。二重送信は一意制約で
            #   防げるが、黙って捨てると誰も気づかない。
            done = already_done(url, key, r["case_no"])
            if done:
                _seen_replies.add(r.get("message_id"))
                if r.get("message_id") == done.get("claim_message_id"):
                    continue          # 取得した本人の、そのリプライ自体
                # 再起動しても二度言わないよう、DB側にも記録が無いか見る
                seen = api(url, key, "GET", "dispatch_queue",
                           {"select": "id", "limit": 1,
                            "claim_message_id": f"eq.{r.get('message_id')}"})
                # ★名乗り以外は知らせない（案件移動の連絡・雑談など）
                if not looks_like_name_claim(
                        r.get("text"), dc.display_name(master.get(r["user_id"]), "")):
                    continue
                if not seen:
                    wrong.append({
                        "case_no": r["case_no"], "room_name": name,
                        "room_group_id": gid,
                        "claim_message_id": r.get("message_id"),
                        "player_user_id": r["user_id"],
                        "taken_by": done.get("player_line_name") or "",
                        "replied_by": dc.display_name(
                            master.get(r["user_id"]), ""),
                    })
                continue

            # ここから先は送信の話。トグルをONにする前の取得には送らない
            #（ONより前は手作業で送致済みのはずで、後追いは二重送信になる）。
            if lp.parse_ts(r["sent_at"]) < send_cutoff:
                continue

            m = master.get(r["user_id"]) or {}
            second = find_second(url, key, transit_gid, r["case_no"])
            row = {
                "case_no": r["case_no"], "room_group_id": gid, "room_name": name,
                "player_user_id": r["user_id"],
                # ★列名は player_line_name のままだが、入れるのは管理表の呼び名。
                #   画面に出るのはこの値で、LINE登録名では他の事務員に通じない。
                "player_line_name": dc.display_name(m),
                "claim_message_id": r.get("message_id"),
                "second_text": second, "confidence": r["confidence"],
                "detect_reason": r["reason"], "detected_at": r["sent_at"],
            }
            try:
                api(url, key, "POST", "dispatch_queue", body=row,
                    prefer="return=minimal,resolution=ignore-duplicates")
                added.append(row)
                _enqueued.add(r["case_no"])
            except RuntimeError as ex:
                if "duplicate" not in str(ex).lower():
                    log(f"[警告] キュー投入に失敗 {r['case_no']}: {ex}")
                else:
                    _enqueued.add(r["case_no"])
    return added, wrong


def notice_text(w):
    """ルームに出す一文。

    ★読むのはプレイヤー。事務員どうしの言い方をそのまま出さない。
      「セカンド」は事務側の呼び方で、プレイヤーには通じない。
    """
    # 取得者が分からないときは、その部分ごと落とす。
    # 「他の方が」と入れると、誰か分かっているのに
    # 伏せているように読める。
    who = f"{w['taken_by']}さんが" if w["taken_by"] else ""
    return (f"⚠ この案件({w['case_no']})はすでに{who}取得済みです。\n"
            f"リプライする案件を確認してください。")


def warn_wrong_reply(url, key, staff, wrong, live=False):
    """すでに取得済みの案件へのリプライを、その場で知らせる。

    ルームに一文を出すだけ（リアクションは付けない）。

    ★live でないときは出さない。
      このスクリプトは既定がドライランで、--live を付けたときだけ
      実際に送る約束になっている。ここだけ例外にすると、
      動作確認のつもりで回した人が、本物のルームに書き込んでしまう。
    """
    if not (WRONG_REPLY_NOTICE and wrong):
        return
    if not live:
        for w in wrong:
            log_detail(f"[ドライラン] {w['case_no']} … すでに取得済みの案件への"
                f"リプライです（{w['room_name']}への通知は送りません）")
        return
    if len(wrong) > WRONG_REPLY_MAX_PER_CYCLE:
        log_detail(f"[誤リプライ] {len(wrong)}件ありましたが、"
            f"{WRONG_REPLY_MAX_PER_CYCLE}件だけ知らせます（出し過ぎ防止）")
        wrong = wrong[:WRONG_REPLY_MAX_PER_CYCLE]
    sender = load_sender(staff)
    test = staff.get("test_mode")
    for w in wrong:
        label = f"{w['case_no']} ← {w['replied_by'] or '取得者不明'}"
        room = (staff.get("test_report_room", "テストトランジットROOM")
                if test else w["room_name"])
        try:
            sender.send_to_room(room, notice_text(w))
            log_detail(f"[誤リプライ] {label} … すでに{w['taken_by'] or '他の方'}が"
                f"取得済み。{room}に知らせました")
        except Exception as ex:
            log_detail(f"[誤リプライ] {label} … 知らせられませんでした: {str(ex)[:60]}")
            continue
        # 知らせた記録を残す。再起動しても二度言わないため。
        try:
            api(url, key, "POST", "dispatch_queue", prefer="return=minimal",
                body={"case_no": w["case_no"], "room_group_id": w["room_group_id"],
                      "room_name": w["room_name"],
                      "player_user_id": w["player_user_id"],
                      "player_line_name": w["replied_by"],
                      "claim_message_id": w["claim_message_id"],
                      "second_text": "", "confidence": "確定",
                      "detect_reason": "誤リプライ",
                      "detected_at": datetime.now(lp.JST).isoformat(),
                      "status": "skipped",
                      "note": f"すでに取得済みの案件へのリプライ"
                              f"（取得者: {w['taken_by'] or '不明'}）"})
        except Exception as ex:
            log_detail(f"[情報] 誤リプライの記録に失敗: {str(ex)[:60]}")


# ══════════════════════════════════════════════════════════
#  送信
# ══════════════════════════════════════════════════════════


def update_queue(url, key, qid, patch):
    api(url, key, "PATCH", "dispatch_queue", {"id": f"eq.{qid}"},
        body=patch, prefer="return=minimal")


def claim_queue(url, key, qid, staff_key):
    """まだ pending のときだけ自分のものにする。取れたら True。

    ★条件付きで更新するのが要点。
      同じPCで常駐を2つ開いた／シフト交代の数秒間だけ2人ともONだった、
      という状況で、同じ案件を2人が同時に送ってしまう。
      顧客に同じセカンドが2通届くので、DB側で1つに絞る。
      条件を外して更新すると、後から来た方も「取れた」と思って送る。
    """
    rows = api(url, key, "PATCH", "dispatch_queue",
               {"id": f"eq.{qid}", "status": "eq.pending"},
               body={"status": "sending", "locked_by": staff_key,
                     "locked_at": datetime.now(lp.JST).isoformat()},
               prefer="return=representation")
    return bool(rows)


def reclaim_stuck(url, key, minutes=10):
    """送信中のまま止まった行を拾い上げる。戻り値: 拾った行

    ★放置すると案件が消える。
      ウィンドウを閉じた・PCが落ちた等で 'sending' のまま残ると、
      次からは pending だけを見るので二度と処理されず、その案件は
      誰にも送られないまま誰も気づかない。

    ★pending には戻さない。
      中断した時点で送信済みだったかどうかは分からない。戻すと
      顧客に2通届く恐れがあるので、失敗として画面に出し、
      人が判断できるようにする。
    """
    cutoff = (datetime.now(lp.JST) - timedelta(minutes=minutes)).isoformat()
    rows = api(url, key, "PATCH", "dispatch_queue",
               {"status": "eq.sending",
                "or": f"(locked_at.lt.{cutoff},locked_at.is.null)"},
               body={"status": "failed",
                     "note": "送信中に中断（送信済みかどうか要確認）"},
               prefer="return=representation")
    return rows or []


# 本文待ちの案件の状態。キューIDごとに持つ。
_second_recheck_at = {}     # 次に本文を探してよい時刻
_second_waiting = set()     # 「待っています」を出し終えたもの（毎巡回で出さない）


def refetch_second(url, key, transit_gid, qid, case_no):
    """セカンド本文をもう一度探し、見つかればキューに書き戻す。

    毎巡回（2秒ごと）に問い合わせると通信が増えるので、数秒に1回に絞る。
    """
    if time.time() < _second_recheck_at.get(qid, 0):
        return ""
    _second_recheck_at[qid] = time.time() + SECOND_RECHECK_SECONDS
    body = find_second(url, key, transit_gid, case_no)
    if not body or case_no not in body:
        return ""
    update_queue(url, key, qid, {"second_text": body})
    return body


def wait_for_line(staff):
    """Chrome版LINEにつながるまで、ここから先へ進まない。

    ★つながらないまま常駐させない。
      つながらなくても常駐そのものは動くので、ダッシュボードには
      「PC稼働中」と出る。その状態で送信担当にされると、案件が来た
      瞬間に必ず失敗する（実際に9442740がこれで落ちた）。
      ここで待てば生存報告を送らないので、ダッシュボードは
      「PC未起動」のまま＝担当にしてはいけないPCだと分かる。
    """
    if (staff.get("send_mode") or "chrome").lower() != "chrome":
        return
    try:
        import line_chrome_check as lcc
    except Exception:
        return
    説明 = {
        "noport": "Chromeが起動していません。「LINE用Chrome起動」を実行してください。",
        "noext": "LINEのタブが開かれていません。いま開いています…",
        "notinstalled": "この専用ChromeにLINE拡張機能が入っていません。"
                        "ストアのページを開いたので「Chromeに追加」を押してください。"
                        "（普段使いのChromeに入れても効きません）",
        "nologin": "LINEのタブはありますが、ログインが済んでいないようです。",
    }
    shown = False
    opened, stored = False, False
    while True:
        state = lcc.probe()
        # 開けるものは自分で開く。事務員に探させない。
        if state == "noext" and not opened:
            opened = lcc.open_in_chrome(lcc.LINE_PAGE_URL)
        if state == "notinstalled" and not stored:
            stored = lcc.open_in_chrome(lcc.LINE_STORE_URL)
        if state == "ok":
            if shown:
                log("Chrome版LINEにつながりました。監視を始めます")
            return
        msg = 説明.get(state, state)
        if not shown:
            shown = True
            print()
            print("=" * 58)
            print("  まだ送信できません")
            print("  " + msg)
            print()
            print("  直すと、この画面はひとりでに先へ進みます。")
            print("  （直るまでは送信担当にできません）")
            print("=" * 58)
        status("LINEの準備を待っています — " + msg)
        time.sleep(3)


def process_pending(url, key, staff, live, confirm, transit_gid=None):
    # 壊れていると分かっているPCで案件を取らない。
    # ★取ってから失敗すると、その案件は他のPCから見えなくなる。
    #   休んでいる間は待ち行列に残しておく方が、送られる見込みが高い。
    if halted():
        return 0, 0
    pend = api(url, key, "GET", "dispatch_queue", {
        "select": "*", "status": "eq.pending", "order": "detected_at.asc",
        "limit": 20})
    if not pend:
        return 0, 0

    sent = skipped = 0
    for q in pend:
        case_no, uid = q["case_no"], q.get("player_user_id") or ""
        label = f"{case_no} → {q.get('player_line_name') or uid[:10]}"

        # 送信先は「取得のリプライを送ったメッセージ」から特定する。
        # 事前の紐づけも名前の照合も不要。
        claim_msg = q.get("claim_message_id")
        name = q.get("player_line_name") or ""
        if not claim_msg:
            log(f"[保留] {label} … 取得リプライのメッセージIDがありません")
            update_queue(url, key, q["id"],
                         {"status": "failed", "note": "claim_message_id なし"})
            skipped += 1
            continue

        body = q.get("second_text") or ""
        if not body or case_no not in body:
            # ★ここで諦めない。取得を検知した時点ではまだ本文が
            #   トランジットROOMに流れていないことがある（実測2.5秒先行）。
            body = refetch_second(url, key, transit_gid, q["id"], case_no)

        if not body:
            waited = (datetime.now(lp.JST)
                      - lp.parse_ts(q["detected_at"])).total_seconds()
            if waited < SECOND_WAIT_SECONDS:
                # pending のまま残し、次の巡回で見直す。
                # 案内は1回だけ。2秒ごとに出すと履歴が埋まる。
                if q["id"] not in _second_waiting:
                    _second_waiting.add(q["id"])
                    log_detail(f"[待機] {label} … セカンド本文がまだ届いていません"
                        f"（{SECOND_WAIT_SECONDS // 60}分待ちます）")
                continue
            log(f"[保留] {label} … セカンド本文が"
                f"{SECOND_WAIT_SECONDS // 60}分待っても届きませんでした")
            update_queue(url, key, q["id"],
                         {"status": "failed",
                          "note": f"セカンド本文なし（{SECOND_WAIT_SECONDS // 60}分待機）"})
            _second_waiting.discard(q["id"])
            _second_recheck_at.pop(q["id"], None)
            skipped += 1
            continue

        if q["id"] in _second_waiting:
            log_detail(f"[本文着] {label} … セカンド本文が届きました。送信します")
            _second_waiting.discard(q["id"])
            _second_recheck_at.pop(q["id"], None)

        if not live:
            try:
                sender = load_sender(staff)
                mid, shown = sender.send_reply_sender(
                    q.get("room_name"), claim_msg, body,
                    ctx=sender.SendContext(dry_run=True))
                log(f"[ドライラン] {label} … 「{shown}」宛に {len(body)}文字を送信予定")
            except Exception as ex:
                log(f"[ドライラン] {label} … 送信先を特定できません: {str(ex)[:60]}")
            sent += 1
            continue

        # 送信直前にもう一度担当を確認する。巡回中にシフト交代でトグルが
        # 切り替わった場合、前の担当のPCから送ってしまわないようにするため。
        mine, _ = is_my_turn(url, key, staff["staff_key"])
        if not mine:
            log(f"[中止] {label} … 送信担当から外れました")
            return sent, skipped

        if confirm:
            ans = input(f"  送信しますか？ {label} → 「{name}」 (y/n) > ").strip().lower()
            if ans not in ("y", "yes"):
                update_queue(url, key, q["id"],
                             {"status": "skipped", "note": "手動で見送り"})
                print("    見送りました")
                skipped += 1
                continue

        # 取れなかった＝他のPC（または同じPCの別ウィンドウ）が先に取った。
        # 二重送信になるので、ここで必ず降りる。
        if not claim_queue(url, key, q["id"], staff["staff_key"]):
            log(f"[譲渡] {label} … 他で処理中のため送りません")
            continue
        try:
            sender = load_sender(staff)

            # ── テストモード ──
            # 取得者の特定までは本番と同じ手順を踏むが、セカンドは
            # プレイヤーではなく転送先へ送り、リアクションも付けない。
            if staff.get("test_mode"):
                res = sender.send_reply_sender_test(
                    q.get("room_name"), claim_msg, body,
                    redirect_to=staff.get("test_redirect_to", "FSJ事務bot"),
                    report_room=staff.get("test_report_room", "テストトランジットROOM"),
                    report_prefix=f"{case_no} セカンド送信完了、"
                                  f"リアクションマークテスト済み",
                    react_emoji=staff.get("reaction_emoji", "1003"))
                update_queue(url, key, q["id"], {
                    "status": "test", "sent_at": datetime.now(lp.JST).isoformat(),
                    "note": f"テストモード（本来の宛先: {res['sender']}）"})
                log(f"[テスト] {case_no} 本来の宛先={res['sender']} → "
                      f"{staff.get('test_redirect_to', 'FSJ事務bot')} に送信 / "
                      f"リアクション{'可' if res['can_react'] else '不可'}")
                note_health("ok", live)
                sent += 1
                continue

            # ★取得のリプライを送った本人のトークへ送る。
            #   ルーム内の該当メッセージから送信者の内部IDを読み取るので、
            #   同姓の知人や本人の2つ目のアカウントと取り違えない。
            #   送信成功後、取得リプライにリアクションを付けて「送った印」にする。
            # ★届いた瞬間に「送信済み」を書く（リアクション付けを待たない）。
            #   後始末の数秒でPCが落ちても、届いた事実は残る。
            wrote = {"ok": False}

            def mark_sent(mid, shown_name, _q=q):
                update_queue(url, key, _q["id"], {
                    "status": "sent",
                    "sent_at": datetime.now(lp.JST).isoformat()})
                wrote["ok"] = True

            _, sent_to = sender.send_reply_sender(
                q.get("room_name"), claim_msg, body,
                react_emoji=staff.get("reaction_emoji", "1003"),
                on_sent=mark_sent)
            # ★その場で書けなかったとき（通信の一時不良など）の受け皿。
            #   送信側は記録の失敗を握りつぶすので、ここで書き直さないと
            #   送信中のまま取り残され、あとで「中断」として失敗に数えられる。
            if not wrote["ok"]:
                update_queue(url, key, q["id"], {
                    "status": "sent",
                    "sent_at": datetime.now(lp.JST).isoformat()})
            name = sent_to or name
            # 送れた＝検索名が正しかった証拠として記録しておく
            log(f"[送信] {label} → 「{name}」")
            note_health("ok", live)
            sent += 1
        except Exception as ex:
            # ★locked_by は消さない。
            #   誰のPCで失敗したかが分からないと、事務員ごとの環境差
            #   （そのアカウントだけ初めての相手だった等）を追えない。
            #   実際、この記録が無いせいで原因の切り分けに時間がかかった。
            msg = str(ex)[:200]
            tries = HEALTH["tries"].get(case_no, 0) + 1
            HEALTH["tries"][case_no] = tries
            # 環境のせいで、まだ間に合う時間なら、待ち行列へ戻して再挑戦する。
            fresh = (datetime.now(lp.JST) - lp.parse_ts(q["detected_at"])
                     ).total_seconds() < RETRY_WINDOW_MINUTES * 60
            retry = (is_env_failure(msg) and fresh
                     and tries < MAX_TRIES_PER_CASE)
            if retry:
                patch = {"status": "pending", "locked_by": None,
                         "locked_at": None,
                         "note": f"再挑戦待ち（{tries}回目）: {msg}"}
            else:
                over = is_env_failure(msg) and not fresh
                patch = {"status": "failed",
                         "note": (msg + "（時間切れ・手で送ってください）")[:200]
                                 if over else msg}
            # 失敗した瞬間の画面。あとから写真を頼まなくて済む。
            snap = getattr(ex, "snapshot", None)
            if snap:
                patch["debug"] = snap
            try:
                update_queue(url, key, q["id"], patch)
            except RuntimeError:
                # debug列をまだ作っていないDBでも動くようにする。
                # ここで落とすと、失敗の記録そのものが残らなくなる。
                patch.pop("debug", None)
                update_queue(url, key, q["id"], patch)
            if retry:
                log(f"[保留] {label} … 送れませんでした。あとで試します")
            else:
                log(f"[失敗] {label}: {ex}")
            note_health("env" if is_env_failure(msg) else "case", live)
            skipped += 1
            if halted():
                break                 # 壊れているPCで案件を消費しない
    return sent, skipped


# ══════════════════════════════════════════════════════════
#  サブコマンド
# ══════════════════════════════════════════════════════════

def cmd_status(url, key, staff):
    print(f"事務員: {staff.get('display_name') or staff['staff_key']}")
    print(f"モード: {'テストモード（プレイヤーには送りません）' if staff.get('test_mode') else '★本番送信'}")
    mine, _ = is_my_turn(url, key, staff["staff_key"])
    cur = current_sender(url, key)
    print(f"このPCの自動送信: {'ON（送信担当）' if mine else 'OFF'}")
    print(f"現在の送信担当: {cur['display_name'] if cur else '誰もいません'}")
    rows = api(url, key, "GET", "dispatch_queue", {"select": "status"})
    tally = {}
    for r in rows:
        tally[r["status"]] = tally.get(r["status"], 0) + 1
    print("キュー: " + (" / ".join(f"{k} {v}件" for k, v in sorted(tally.items()))
                    or "空"))




# ══════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true", help="実際に送信する（既定はドライラン）")
    ap.add_argument("--confirm", action="store_true", help="1件ごとに送信確認する")
    ap.add_argument("--once", action="store_true", help="1回だけ実行して終了")
    ap.add_argument("--interval", type=int, default=POLL_SECONDS, help="巡回間隔(秒)")
    ap.add_argument("--status", action="store_true", help="状況を表示して終了")
    args = ap.parse_args()

    staff = load_staff()
    url, key = lp.load_config()
    resolve_test_mode(url, key, staff)

    if args.status:
        return cmd_status(url, key, staff)

    # 起動のたびに担当者マスタを取り直す。マッピングを直しても各PCが
    # 古いままだと、取得者を取り違えて別の人に顧客情報を送りかねない。
    try:
        n = dc.refresh_from_db(url, key)
        if n:
            print(f"担当者マスタ: {n}人分を取り込みました")
    except Exception as e:
        print(f"[警告] 担当者マスタを更新できません（{str(e)[:50]}）。手元の内容で動きます。")

    master = dc.load_master()
    groups = {g["group_id"]: g["name"] for g in
              lp.fetch_all(url, key, "line_groups", "group_id,name",
                           order_col="group_id")}
    transit_gid = next((g for g, n in groups.items() if n == TRANSIT_ROOM), None)
    if not transit_gid:
        print(f"[警告] 「{TRANSIT_ROOM}」が見つかりません。セカンド本文を取得できません。")

    if staff.get("test_mode"):
        mode = (f"テストモード（プレイヤーには送らず "
                f"{staff.get('test_redirect_to', 'FSJ事務bot')} へ送信）")
    else:
        mode = "実送信" if args.live else "ドライラン（送信しません）"
    print(f"事務員: {staff.get('display_name') or staff['staff_key']} / モード: {mode}")
    if staff.get("test_mode"):
        print(f"※ リアクションは付けません。結果は "
              f"{staff.get('test_report_room', 'テストトランジットROOM')} に書き込みます。")
    elif args.live and not args.confirm:
        print("※ 無人で実送信します。止めるときは Ctrl+C。")

    # ★待機中の表示は履歴に残さない。
    #   5秒ごとに「新しい取得はありません」を積むと、実際に起きたこと
    #   （検知・送信・失敗）が流れて見えなくなる。待機は最下行を
    #   書き換えるだけにして、履歴には出来事だけを残す。
    # ★監視に入る前に、LINEにつながることを確かめる。
    #   つながらないまま回ると、生存報告だけ届いて「稼働中」に見えてしまう。
    if not args.once:
        wait_for_line(staff)

    totals = {"検知": 0, "送信": 0, "失敗": 0}
    last_hour = None
    last_reclaim = 0.0
    on_duty = False
    window = EventWindow(LOOKBACK_HOURS)

    # 新着を「入った瞬間」に受け取る。失敗しても送信は止めない。
    watcher = None
    try:
        import realtime_watch
        watcher = realtime_watch.Watcher(url, key)
        watcher.start()
        if watcher.connected(timeout=8):
            log("新着の通知を受け取れます（即時反応）")
        else:
            log(f"通知は使えません。決まった間隔で確認します"
                f"（{watcher.last_error or '接続待ち'}）")
    except Exception as e:
        log(f"通知の準備に失敗（{str(e)[:60]}）。決まった間隔で確認します。")

    while True:
        try:
            # ★状態の取得は1往復にまとめる（生存報告・モード・担当・新着）。
            #   往復が減るぶん通信量も待ち時間も減る。
            #   サーバ側に関数が無い環境では従来の4回問い合わせに落ちる。
            was_test = staff.get("test_mode")
            # ★生存報告より先に見る。順番が逆だと、使えないと分かった
            #   直後に報告を送り直してしまい、消した意味が無くなる。
            check_line_health(url, key, staff)
            if HEALTH["sick"]:
                # ★問い合わせそのものを止める。
                #   sender_poll は生存報告を兼ねている（サーバ側で
                #   client_seen_at を更新する）ので、呼ぶだけで
                #   「稼働中」に戻ってしまい、消した意味が無くなる。
                status("Chrome版LINEが使えるようになるのを待っています")
                if args.once:
                    break          # 1回だけの実行を待ち続けさせない
                time.sleep(3)
                continue
            snap = poll_once(url, key, staff["staff_key"], window.last_id)
            if snap is not None:
                apply_mode(staff, snap.get("mode"))
                since = (lp.parse_ts(snap["since"]) if snap.get("since")
                         else (datetime.now(lp.JST) if snap.get("auto_send") else None))
                if not snap.get("auto_send"):
                    since = None
                duty = snap.get("duty") or "なし"
                has_new = bool(snap.get("has_new")) or bool(snap.get("pending"))
            else:
                if not HEALTH["sick"]:
                    heartbeat(url, key, staff["staff_key"])
                resolve_test_mode(url, key, staff)
                since = my_turn_since(url, key, staff["staff_key"])
                duty = (current_sender(url, key) or {}).get("display_name") or "なし"
                has_new = True          # 分からないので毎回見る
            if staff.get("test_mode") != was_test:
                log(f"モードが変わりました → "
                    f"{'テストモード' if staff['test_mode'] else '★本番送信'}")

            now = datetime.now(lp.JST)
            # 1時間ごとに1行だけ残す。朝見たときに「夜中も動いていた」と分かる。
            if last_hour is not None and now.hour != last_hour:
                log(f"稼働中（この時間の 検知{totals['検知']} / 送信{totals['送信']}"
                    f" / 失敗{totals['失敗']}）")
                totals = {"検知": 0, "送信": 0, "失敗": 0}
            last_hour = now.hour

            on_duty = since is not None
            if since is None:
                status(f"待機中 — このPCは送信担当ではありません（現在の担当: {duty}）")
            else:
                # 送信中のまま止まった行を拾う。毎巡回だと問い合わせが増えるので
                # 1分に1回でよい（止まった案件は分単位で気づけば十分）。
                if time.time() - last_reclaim > 60:
                    last_reclaim = time.time()
                    for r in reclaim_stuck(url, key):
                        totals["失敗"] += 1
                        log(f"[要確認] {r['case_no']} … 前回の送信が中断していました"
                            f"（送信済みかどうか確認してください）")

                # ★新着も送信待ちも無いなら、この先は何も起きない。
                #   問い合わせを増やさないために丸ごと飛ばす。
                if not has_new:
                    status(f"監視中 — この時間の 検知{totals['検知']}"
                           f" / 送信{totals['送信']} / 失敗{totals['失敗']}")
                    if args.once:
                        break
                    if watcher and watcher.connected():
                        watcher.wait(SAFETY_POLL_SECONDS)
                    else:
                        time.sleep(args.interval)
                    continue

                evs = window.refresh(url, key)
                added, wrong = enqueue(url, key, groups, master,
                                       transit_gid, evs, since)
                warn_wrong_reply(url, key, staff, wrong, args.live)
                for a in added:
                    totals["検知"] += 1
                    log(f"[検知] {a['case_no']} ← "
                        f"{a['player_line_name']}（{a['confidence']}）")
                sent, skipped = process_pending(url, key, staff, args.live,
                                                args.confirm, transit_gid)
                totals["送信"] += sent
                totals["失敗"] += skipped
                status(f"監視中 — この時間の 検知{totals['検知']}"
                       f" / 送信{totals['送信']} / 失敗{totals['失敗']}")
        except KeyboardInterrupt:
            raise
        except Exception as ex:
            log(f"[エラー] {ex}")

        if args.once:
            break

        # 通知が使えるなら、来るまで待つ（来た瞬間に次の巡回へ進む）。
        # 使えないときだけ、決まった間隔で回る。
        if on_duty:
            gap = (SAFETY_POLL_SECONDS
                   if (watcher and watcher.connected()) else args.interval)
        else:
            gap = IDLE_POLL_SECONDS
        if watcher and watcher.connected():
            watcher.wait(gap)
        else:
            time.sleep(gap)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n終了しました。")
