#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""second_sender.py — セカンド自動送信クライアント（案件手配員のPCで常駐させる）

案件紹介ROOMでプレイヤーが取得（リプライ）したら、その人の1:1トークに
トランジットROOMのセカンド本文を送る。送信は事務員本人のLINEアカウントから
Chrome版LINEを操作して行うため、このスクリプトは各事務員のPCで動かす。

★宛先は「取得のリプライを送ったメッセージ」から特定する。
  グループのメッセージ要素には送信者の内部IDが入っており、Webhookで受け取った
  message_id と突き合わせれば本人を一意に特定できる。名前で探さないので、
  同姓の知人や本人の2つ目のアカウントと取り違えない。
  事前の登録作業も不要で、どの事務員のPCでもそのまま動く。

★安全のため既定はドライラン。--live を付けたときだけ実際に送信する。

送信しない条件（どれか1つでも当てはまれば必ず止まる）:
  ・ダッシュボードで自分のトグルがOFF（ONにできるのは常に1人だけ）
  ・トグルをONにした時刻より前の取得（手作業で送致済みのため）
  ・取得の判定が「曖昧」（どの案件宛てか確定できない）
  ・取得リプライのメッセージが画面に見つからない
  ・セカンド本文が見つからない／案件番号が本文と一致しない
  ・同じ案件が既にキューにある（二重送信の防止）

使い方:
    python -X utf8 scripts/second_sender.py --once            # 1回だけ・ドライラン
    python -X utf8 scripts/second_sender.py                   # 常駐・ドライラン
    python -X utf8 scripts/second_sender.py --live --confirm  # 実送信・毎回確認
    python -X utf8 scripts/second_sender.py --live            # 実送信・無人
    python -X utf8 scripts/second_sender.py --status          # 状況表示

初回設定: scripts/second_sender.json に自分の識別名を書く
    {"staff_key": "kawakami", "display_name": "川上"}
"""

import argparse
import json
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import line_pull as lp          # noqa: E402
import detect_claims as dc      # noqa: E402

CONFIG_PATH = SCRIPT_DIR / "second_sender.json"
SETTING_KEY = "second_auto_send"
# ★テストモードは全員共通。PCごとの設定ファイルではなくDBを正とする。
#   PCごとに持つと、新しい事務員が初期設定しただけでその人だけ本番送信になり、
#   気づかないまま実際のプレイヤーへ送ってしまう。
TEST_KEY = "second_test_mode"
TRANSIT_ROOM = "トランジットROOM"
LOOKBACK_HOURS = 6              # 取得判定に使う直近の時間幅
POLL_SECONDS = 5

# ★これより古い取得はキューに積まない。
#   セカンドはお客様への連絡期限（受取から15分）に間に合わせるものなので、
#   時間が経った取得は既に手動で送られていると考えるのが自然。
#   この歯止めが無いと、システムを有効にした瞬間に過去分が一斉送信される。
MAX_CLAIM_AGE_MINUTES = 15

# 画面の最下行だけを書き換えるための幅。長い行を短い行で上書きすると
# 前の文字が残るので、必ずこの幅まで空白で埋める。
_LINE_W = 96
_status_shown = False


def status(text):
    """待機中の表示。同じ行を書き換えるだけで、履歴には残さない。"""
    global _status_shown
    sys.stdout.write("\r" + f"[{datetime.now(lp.JST):%H:%M:%S}] {text}"
                     .ljust(_LINE_W)[:_LINE_W])
    sys.stdout.flush()
    _status_shown = True


def log(text):
    """履歴に残す。待機表示が出ていれば消してから書く。"""
    global _status_shown
    if _status_shown:
        sys.stdout.write("\r" + " " * _LINE_W + "\r")
        _status_shown = False
    print(f"[{datetime.now(lp.JST):%H:%M:%S}] {text}", flush=True)


# ══════════════════════════════════════════════════════════
#  Supabase 読み書き
# ══════════════════════════════════════════════════════════

def load_staff():
    if not CONFIG_PATH.exists():
        sys.exit(f"{CONFIG_PATH} を作って自分の識別名を書いてください:\n"
                 '{"staff_key": "kawakami", "display_name": "川上"}')
    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    if not cfg.get("staff_key"):
        sys.exit(f"{CONFIG_PATH} に staff_key がありません")
    return cfg


def load_sender(staff):
    """送信方式を選ぶ。

    chrome … Chrome拡張版LINEをCDP経由で操作する（既定）。
             ページ内でJSを実行するだけなので**マウスもキーボードも奪わない**。
             事務員は普通に作業しながら自動送信を走らせられる。
             送信先の確認も3段階（サイドバー行→ヘッダー名とdata-mid→貼付直前）で堅い。
    pc     … PC版LINEをpyautoguiで操作する。実行中はPCを触れなくなるうえ、
             座標クリック頼みで確認も弱いため、Chromeが使えない場合の予備。
    """
    mode = (staff.get("send_mode") or "chrome").lower()
    if mode == "pc":
        import line_pc
        return line_pc
    import line_chrome
    return line_chrome


def api(url, key, method, table, params=None, body=None, prefer=None):
    q = ("?" + urllib.parse.urlencode(params)) if params else ""
    headers = {"apikey": key, "Authorization": f"Bearer {key}",
               "Content-Type": "application/json"}
    if prefer:
        headers["Prefer"] = prefer
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(f"{url}/rest/v1/{table}{q}", data=data,
                                 method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as res:
            raw = res.read().decode("utf-8")
            return json.loads(raw) if raw.strip() else []
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")[:300]
        raise RuntimeError(f"{method} {table}: HTTP {e.code} {detail}") from None


def my_turn_since(url, key, staff_key):
    """自分が送信担当か、そしていつONにしたか。

    ★ONにした時刻より前の取得には送らない。
      ONにする前の案件は事務員が手作業で送致済みのはずで、
      後追いで自動送信すると二重送信になる。
    """
    rows = api(url, key, "GET", "staff",
               {"staff_key": f"eq.{staff_key}",
                "select": "auto_send,display_name,auto_send_on_at"})
    if not rows or not rows[0].get("auto_send"):
        return None
    return lp.parse_ts(rows[0]["auto_send_on_at"]) if rows[0].get("auto_send_on_at") \
        else datetime.now(lp.JST)


def is_my_turn(url, key, staff_key):
    """自分のPCが送信担当か（ダッシュボードで自分のトグルがONか）。

    ★全体の1つのスイッチではなく、事務員ごとのトグルで判定する。
      前のシフトの人がクライアントを閉じ忘れても、その人のトグルは
      交代時にOFFになるので、そのPCからは送信されない。
      DB側のトリガーで「同時にONにできるのは1人だけ」も保証している。
    """
    rows = api(url, key, "GET", "staff",
               {"staff_key": f"eq.{staff_key}", "select": "auto_send,display_name"})
    if not rows:
        return False, None
    return bool(rows[0].get("auto_send")), rows[0].get("display_name")


def heartbeat(url, key, staff_key):
    """自分のPCでクライアントが動いていることをDBに記録する。

    トグルがONでもクライアントが起動していなければ送信されないので、
    ダッシュボードで「稼働中／未起動」を見分けられるようにする。
    """
    try:
        api(url, key, "PATCH", "staff", {"staff_key": f"eq.{staff_key}"},
            body={"client_seen_at": datetime.now(lp.JST).isoformat()},
            prefer="return=minimal")
    except Exception:
        pass          # 生存報告の失敗で本処理を止めない


def current_sender(url, key):
    """いま送信担当になっている事務員（表示用）。"""
    rows = api(url, key, "GET", "staff",
               {"auto_send": "eq.true", "select": "staff_key,display_name"})
    return rows[0] if rows else None


def resolve_test_mode(url, key, staff):
    """テストモードかどうかをDBから読み、staff に反映する。

    ★PCごとの設定ファイルには置かない。事務員が「はじめに実行」をすると
      設定ファイルが作り直されるため、そこにテストモードを書いていると
      新しい人だけ本番送信になる。全員が同じ設定を見るようにする。

    ★読めなかった場合・設定が無い場合はテストモードとして扱う。
      判断がつかないときに実際のプレイヤーへ送るより、送らない方が安全。
      （本番に切り替えたのに送られない事故は、画面を見ればすぐ気づける）
    """
    cfg = None
    try:
        rows = api(url, key, "GET", "app_settings",
                   {"key": f"eq.{TEST_KEY}", "select": "value"})
        cfg = rows[0]["value"] if rows else None
    except Exception as ex:
        log(f"[警告] テストモード設定を読めません（{str(ex)[:60]}）")
    if not isinstance(cfg, dict):
        log("[警告] テストモード設定が見つかりません。安全のためテストモードで動きます。")
        cfg = {"enabled": True}

    # force_test_mode はそのPCだけを強制的にテストにする逃げ道。
    # 逆向き（1台だけ本番にする）は用意しない。事故の向きが違う。
    staff["test_mode"] = bool(cfg.get("enabled", True)) or bool(
        staff.get("force_test_mode"))
    staff["test_redirect_to"] = cfg.get("redirect_to") or "FSJ事務bot"
    staff["test_report_room"] = cfg.get("report_room") or "テストトランジットROOM"
    return staff


# ══════════════════════════════════════════════════════════
#  取得の検知 → キュー投入
# ══════════════════════════════════════════════════════════

def recent_events(url, key, hours):
    since = (datetime.now(lp.JST) - timedelta(hours=hours)).isoformat()
    return api(url, key, "GET", "line_events", {
        "select": "id,event_type,group_id,user_id,message_id,text,"
                  "quoted_message_id,case_nos,sent_at",
        "sent_at": f"gte.{since}", "order": "id.asc", "limit": 5000})


def find_second(url, key, transit_gid, case_no):
    """トランジットROOMから該当案件のセカンド本文を取る（最新を採用）。"""
    if not transit_gid:
        return ""
    rows = api(url, key, "GET", "line_events", {
        "select": "text,sent_at", "group_id": f"eq.{transit_gid}",
        "case_nos": f"cs.{{{case_no}}}", "order": "id.desc", "limit": 1})
    return (rows[0].get("text") or "") if rows else ""


def enqueue(url, key, groups, master, transit_gid, events, since=None):
    """新しく検知した取得をキューに積む。既にあるものは一意制約で弾かれる。

    since（トグルをONにした時刻）より前の取得は積まない。
    """
    added = []
    by_room = {}
    for e in events:
        name = groups.get(e.get("group_id")) or ""
        if "案件紹介" in name or "送客" in name:
            by_room.setdefault((e["group_id"], name), []).append(e)

    # ①トグルをONにした時刻より前は対象外（ONにする前は手作業で送致済み）
    # ②さらに15分より古いものも対象外（クライアントが長時間止まっていた場合の保険）
    cutoff = datetime.now(lp.JST) - timedelta(minutes=MAX_CLAIM_AGE_MINUTES)
    if since and since > cutoff:
        cutoff = since
    for (gid, name), evs in by_room.items():
        for r in dc.detect(evs, master, name):
            if r["confidence"] not in ("確定", "推定"):
                continue
            if lp.parse_ts(r["sent_at"]) < cutoff:
                continue
            m = master.get(r["user_id"]) or {}
            second = find_second(url, key, transit_gid, r["case_no"])
            row = {
                "case_no": r["case_no"], "room_group_id": gid, "room_name": name,
                "player_user_id": r["user_id"],
                "player_line_name": m.get("LINE登録名") or "",
                "claim_message_id": r.get("message_id"),
                "second_text": second, "confidence": r["confidence"],
                "detect_reason": r["reason"], "detected_at": r["sent_at"],
            }
            try:
                api(url, key, "POST", "dispatch_queue", body=row,
                    prefer="return=minimal,resolution=ignore-duplicates")
                added.append(row)
            except RuntimeError as ex:
                if "duplicate" not in str(ex).lower():
                    log(f"[警告] キュー投入に失敗 {r['case_no']}: {ex}")
    return added


# ══════════════════════════════════════════════════════════
#  送信
# ══════════════════════════════════════════════════════════


def update_queue(url, key, qid, patch):
    api(url, key, "PATCH", "dispatch_queue", {"id": f"eq.{qid}"},
        body=patch, prefer="return=minimal")


def process_pending(url, key, staff, live, confirm):
    pend = api(url, key, "GET", "dispatch_queue", {
        "select": "*", "status": "eq.pending", "order": "detected_at.asc",
        "limit": 20})
    if not pend:
        return 0, 0

    sent = skipped = 0
    for q in pend:
        case_no, uid = q["case_no"], q.get("player_user_id") or ""
        label = f"{case_no} → {q.get('player_line_name') or uid[:10]}"

        # 送信先は「取得のリプライを送ったメッセージ」から特定する。
        # 事前の紐づけも名前の照合も不要。
        claim_msg = q.get("claim_message_id")
        name = q.get("player_line_name") or ""
        if not claim_msg:
            log(f"[保留] {label} … 取得リプライのメッセージIDがありません")
            update_queue(url, key, q["id"],
                         {"status": "failed", "note": "claim_message_id なし"})
            skipped += 1
            continue

        body = q.get("second_text") or ""
        if not body or case_no not in body:
            log(f"[保留] {label} … セカンド本文が見つからない/案件番号が一致しない")
            update_queue(url, key, q["id"],
                         {"status": "failed", "note": "セカンド本文なし"})
            skipped += 1
            continue

        if not live:
            try:
                sender = load_sender(staff)
                mid, shown = sender.send_reply_sender(
                    q.get("room_name"), claim_msg, body,
                    ctx=sender.SendContext(dry_run=True))
                log(f"[ドライラン] {label} … 「{shown}」宛に {len(body)}文字を送信予定")
            except Exception as ex:
                log(f"[ドライラン] {label} … 送信先を特定できません: {str(ex)[:60]}")
            sent += 1
            continue

        # 送信直前にもう一度担当を確認する。巡回中にシフト交代でトグルが
        # 切り替わった場合、前の担当のPCから送ってしまわないようにするため。
        mine, _ = is_my_turn(url, key, staff["staff_key"])
        if not mine:
            log(f"[中止] {label} … 送信担当から外れました")
            return sent, skipped

        if confirm:
            ans = input(f"  送信しますか？ {label} → 「{name}」 (y/n) > ").strip().lower()
            if ans not in ("y", "yes"):
                update_queue(url, key, q["id"],
                             {"status": "skipped", "note": "手動で見送り"})
                print("    見送りました")
                skipped += 1
                continue

        update_queue(url, key, q["id"], {
            "status": "sending", "locked_by": staff["staff_key"],
            "locked_at": datetime.now(lp.JST).isoformat()})
        try:
            sender = load_sender(staff)

            # ── テストモード ──
            # 取得者の特定までは本番と同じ手順を踏むが、セカンドは
            # プレイヤーではなく転送先へ送り、リアクションも付けない。
            if staff.get("test_mode"):
                res = sender.send_reply_sender_test(
                    q.get("room_name"), claim_msg, body,
                    redirect_to=staff.get("test_redirect_to", "FSJ事務bot"),
                    report_room=staff.get("test_report_room", "テストトランジットROOM"),
                    report_prefix=f"{case_no} セカンド送信完了、"
                                  f"リアクションマークテスト済み",
                    react_emoji=staff.get("reaction_emoji", "1003"))
                update_queue(url, key, q["id"], {
                    "status": "test", "sent_at": datetime.now(lp.JST).isoformat(),
                    "note": f"テストモード（本来の宛先: {res['sender']}）"})
                log(f"[テスト] {case_no} 本来の宛先={res['sender']} → "
                      f"{staff.get('test_redirect_to', 'FSJ事務bot')} に送信 / "
                      f"リアクション{'可' if res['can_react'] else '不可'}")
                sent += 1
                continue

            # ★取得のリプライを送った本人のトークへ送る。
            #   ルーム内の該当メッセージから送信者の内部IDを読み取るので、
            #   同姓の知人や本人の2つ目のアカウントと取り違えない。
            #   送信成功後、取得リプライにリアクションを付けて「送った印」にする。
            _, sent_to = sender.send_reply_sender(
                q.get("room_name"), claim_msg, body,
                react_emoji=staff.get("reaction_emoji", "1003"))
            name = sent_to or name
            update_queue(url, key, q["id"], {
                "status": "sent", "sent_at": datetime.now(lp.JST).isoformat()})
            # 送れた＝検索名が正しかった証拠として記録しておく
            log(f"[送信] {label} → 「{name}」")
            sent += 1
        except Exception as ex:
            update_queue(url, key, q["id"],
                         {"status": "failed", "note": str(ex)[:200],
                          "locked_by": None})
            log(f"[失敗] {label}: {ex}")
            skipped += 1
    return sent, skipped


# ══════════════════════════════════════════════════════════
#  サブコマンド
# ══════════════════════════════════════════════════════════

def cmd_status(url, key, staff):
    print(f"事務員: {staff.get('display_name') or staff['staff_key']}")
    print(f"モード: {'テストモード（プレイヤーには送りません）' if staff.get('test_mode') else '★本番送信'}")
    mine, _ = is_my_turn(url, key, staff["staff_key"])
    cur = current_sender(url, key)
    print(f"このPCの自動送信: {'ON（送信担当）' if mine else 'OFF'}")
    print(f"現在の送信担当: {cur['display_name'] if cur else '誰もいません'}")
    rows = api(url, key, "GET", "dispatch_queue", {"select": "status"})
    tally = {}
    for r in rows:
        tally[r["status"]] = tally.get(r["status"], 0) + 1
    print("キュー: " + (" / ".join(f"{k} {v}件" for k, v in sorted(tally.items()))
                    or "空"))




# ══════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true", help="実際に送信する（既定はドライラン）")
    ap.add_argument("--confirm", action="store_true", help="1件ごとに送信確認する")
    ap.add_argument("--once", action="store_true", help="1回だけ実行して終了")
    ap.add_argument("--interval", type=int, default=POLL_SECONDS, help="巡回間隔(秒)")
    ap.add_argument("--status", action="store_true", help="状況を表示して終了")
    args = ap.parse_args()

    staff = load_staff()
    url, key = lp.load_config()
    resolve_test_mode(url, key, staff)

    if args.status:
        return cmd_status(url, key, staff)

    # 起動のたびに担当者マスタを取り直す。マッピングを直しても各PCが
    # 古いままだと、取得者を取り違えて別の人に顧客情報を送りかねない。
    try:
        n = dc.refresh_from_db(url, key)
        if n:
            print(f"担当者マスタ: {n}人分を取り込みました")
    except Exception as e:
        print(f"[警告] 担当者マスタを更新できません（{str(e)[:50]}）。手元の内容で動きます。")

    master = dc.load_master()
    groups = {g["group_id"]: g["name"] for g in
              lp.fetch_all(url, key, "line_groups", "group_id,name",
                           order_col="group_id")}
    transit_gid = next((g for g, n in groups.items() if n == TRANSIT_ROOM), None)
    if not transit_gid:
        print(f"[警告] 「{TRANSIT_ROOM}」が見つかりません。セカンド本文を取得できません。")

    if staff.get("test_mode"):
        mode = (f"テストモード（プレイヤーには送らず "
                f"{staff.get('test_redirect_to', 'FSJ事務bot')} へ送信）")
    else:
        mode = "実送信" if args.live else "ドライラン（送信しません）"
    print(f"事務員: {staff.get('display_name') or staff['staff_key']} / モード: {mode}")
    if staff.get("test_mode"):
        print(f"※ リアクションは付けません。結果は "
              f"{staff.get('test_report_room', 'テストトランジットROOM')} に書き込みます。")
    elif args.live and not args.confirm:
        print("※ 無人で実送信します。止めるときは Ctrl+C。")

    # ★待機中の表示は履歴に残さない。
    #   5秒ごとに「新しい取得はありません」を積むと、実際に起きたこと
    #   （検知・送信・失敗）が流れて見えなくなる。待機は最下行を
    #   書き換えるだけにして、履歴には出来事だけを残す。
    totals = {"検知": 0, "送信": 0, "失敗": 0}
    last_hour = None

    while True:
        try:
            heartbeat(url, key, staff["staff_key"])
            # 巡回のたびに読み直す。本番へ切り替えた／テストへ戻した場合に、
            # 動いているクライアントを再起動しなくても追従させるため。
            was_test = staff.get("test_mode")
            resolve_test_mode(url, key, staff)
            if staff.get("test_mode") != was_test:
                log(f"モードが変わりました → "
                    f"{'テストモード' if staff['test_mode'] else '★本番送信'}")

            now = datetime.now(lp.JST)
            # 1時間ごとに1行だけ残す。朝見たときに「夜中も動いていた」と分かる。
            if last_hour is not None and now.hour != last_hour:
                log(f"稼働中（この時間の 検知{totals['検知']} / 送信{totals['送信']}"
                    f" / 失敗{totals['失敗']}）")
                totals = {"検知": 0, "送信": 0, "失敗": 0}
            last_hour = now.hour

            since = my_turn_since(url, key, staff["staff_key"])
            if since is None:
                cur = current_sender(url, key)
                who = cur["display_name"] if cur else "なし"
                status(f"待機中 — このPCは送信担当ではありません（現在の担当: {who}）")
            else:
                evs = recent_events(url, key, LOOKBACK_HOURS)
                added = enqueue(url, key, groups, master, transit_gid, evs, since)
                for a in added:
                    totals["検知"] += 1
                    log(f"[検知] {a['case_no']} ← "
                        f"{a['player_line_name']}（{a['confidence']}）")
                sent, skipped = process_pending(url, key, staff, args.live, args.confirm)
                totals["送信"] += sent
                totals["失敗"] += skipped
                status(f"監視中 — この時間の 検知{totals['検知']}"
                       f" / 送信{totals['送信']} / 失敗{totals['失敗']}")
        except KeyboardInterrupt:
            raise
        except Exception as ex:
            log(f"[エラー] {ex}")

        if args.once:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n終了しました。")
