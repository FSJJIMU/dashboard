#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""second_sender.py — セカンド自動送信クライアント（案件手配員のPCで常駐させる）

案件紹介ROOMでプレイヤーが取得（リプライ）したら、その人の1:1トークに
トランジットROOMのセカンド本文を送る。送信は事務員本人のLINEアカウントから
Chrome版LINEを操作して行うため、このスクリプトは各事務員のPCで動かす。

★宛先は「取得のリプライを送ったメッセージ」から特定する。
  グループのメッセージ要素には送信者の内部IDが入っており、Webhookで受け取った
  message_id と突き合わせれば本人を一意に特定できる。名前で探さないので、
  同姓の知人や本人の2つ目のアカウントと取り違えない。
  事前の登録作業も不要で、どの事務員のPCでもそのまま動く。

★安全のため既定はドライラン。--live を付けたときだけ実際に送信する。

送信しない条件（どれか1つでも当てはまれば必ず止まる）:
  ・ダッシュボードで自分のトグルがOFF（ONにできるのは常に1人だけ）
  ・トグルをONにした時刻より前の取得（手作業で送致済みのため）
  ・取得の判定が「曖昧」（どの案件宛てか確定できない）
  ・取得リプライのメッセージが画面に見つからない
  ・セカンド本文が見つからない／案件番号が本文と一致しない
  ・同じ案件が既にキューにある（二重送信の防止）

使い方:
    python -X utf8 scripts/second_sender.py --once            # 1回だけ・ドライラン
    python -X utf8 scripts/second_sender.py                   # 常駐・ドライラン
    python -X utf8 scripts/second_sender.py --live --confirm  # 実送信・毎回確認
    python -X utf8 scripts/second_sender.py --live            # 実送信・無人
    python -X utf8 scripts/second_sender.py --status          # 状況表示

初回設定: scripts/second_sender.json に自分の識別名を書く
    {"staff_key": "kawakami", "display_name": "川上"}
"""

import argparse
import http.client
import json
import shutil
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import line_pull as lp          # noqa: E402
import detect_claims as dc      # noqa: E402

CONFIG_PATH = SCRIPT_DIR / "second_sender.json"
SETTING_KEY = "second_auto_send"
# ★テストモードは全員共通。PCごとの設定ファイルではなくDBを正とする。
#   PCごとに持つと、新しい事務員が初期設定しただけでその人だけ本番送信になり、
#   気づかないまま実際のプレイヤーへ送ってしまう。
TEST_KEY = "second_test_mode"
TRANSIT_ROOM = "トランジットROOM"
LOOKBACK_HOURS = 6              # 取得判定に使う直近の時間幅
POLL_SECONDS = 2                # 送信担当のとき（往復を減らしたぶん詰めた）
# ★送信担当でないときは間隔を空ける。
#   「開いたままで大丈夫」と案内している以上、3交代の3人が
#   一日中開けっぱなしになる。全員が5秒ごとに問い合わせると
#   通信量が3倍かかり、無料枠(10GB/月)を無駄に削る。
#   担当になったことに30秒以内に気づければ実用上まったく困らない。
IDLE_POLL_SECONDS = 30
# ★Realtimeで通知を受けられているときの「保険」の間隔。
#   通知が来た瞬間に動くので、待つ側の間隔は長くてよい。
#   それでも0にしないのは、接続が切れている間の分が届かないため。
#   速さはRealtimeが、取りこぼしの無さはこの見回りが担保する。
SAFETY_POLL_SECONDS = 60

# ★これより古い取得はキューに積まない。
#   セカンドはお客様への連絡期限（受取から15分）に間に合わせるものなので、
#   時間が経った取得は既に手動で送られていると考えるのが自然。
#   この歯止めが無いと、システムを有効にした瞬間に過去分が一斉送信される。
MAX_CLAIM_AGE_MINUTES = 15

# セカンド本文が投稿されるのを待つ上限。
# ★取得の検知が、本文がトランジットROOMに流れるより先になることがある。
#   実際に9442725で2.5秒先行し、本文があるのに送れなかった。
#   キュー投入時に取れなかった本文をそのまま信じて即失敗にすると、
#   直後に本文が来ても二度と送られない。
SECOND_WAIT_SECONDS = 300
SECOND_RECHECK_SECONDS = 5      # 待っている間、本文を探し直す間隔

_status_shown = False


def _cols():
    """画面の桁数。1桁残すのは、右端まで書くと勝手に改行する端末があるため。"""
    return max(20, shutil.get_terminal_size((80, 25)).columns - 1)


def _fit(text, cols):
    """ちょうど cols 桁になるよう、切るか空白で埋めるかする。

    ★数えるのは「文字数」ではなく「桁数」。
      日本語は1文字で2桁ぶん場所を取るので、文字数で埋めると
      画面幅を超えて折り返す。折り返すと \\r は最後の物理行にしか
      戻らないため、上書きしたはずの行が履歴に残り続ける。
      （これで「監視中」が延々と積み上がっていた）
      全角か半角かの区別が曖昧な記号（— など）は、広い側で数える。
      狭く見積もると折り返す＝直したい症状そのものが再発するため。
    """
    out, n = [], 0
    for c in text:
        cw = 2 if unicodedata.east_asian_width(c) in "WFA" else 1
        if n + cw > cols:
            break
        out.append(c)
        n += cw
    return "".join(out) + " " * (cols - n)


def status(text):
    """待機中の表示。同じ行を書き換えるだけで、履歴には残さない。

    画面でないとき（ログファイルへ流しているとき）は書かない。
    上書きが効かず、同じ内容で埋め尽くされてしまうため。
    """
    global _status_shown
    if not sys.stdout.isatty():
        return
    sys.stdout.write(
        "\r" + _fit(f"[{datetime.now(lp.JST):%H:%M:%S}] {text}", _cols()))
    sys.stdout.flush()
    _status_shown = True


def log(text):
    """履歴に残す。待機表示が出ていれば消してから書く。"""
    global _status_shown
    if _status_shown:
        sys.stdout.write("\r" + " " * _cols() + "\r")
        _status_shown = False
    print(f"[{datetime.now(lp.JST):%H:%M:%S}] {text}", flush=True)


# ══════════════════════════════════════════════════════════
#  Supabase 読み書き
# ══════════════════════════════════════════════════════════

def load_staff():
    if not CONFIG_PATH.exists():
        sys.exit(f"{CONFIG_PATH} を作って自分の識別名を書いてください:\n"
                 '{"staff_key": "kawakami", "display_name": "川上"}')
    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    if not cfg.get("staff_key"):
        sys.exit(f"{CONFIG_PATH} に staff_key がありません")
    return cfg


def load_sender(staff):
    """送信方式を選ぶ。

    chrome … Chrome拡張版LINEをCDP経由で操作する（既定）。
             ページ内でJSを実行するだけなので**マウスもキーボードも奪わない**。
             事務員は普通に作業しながら自動送信を走らせられる。
             送信先の確認も3段階（サイドバー行→ヘッダー名とdata-mid→貼付直前）で堅い。
    pc     … PC版LINEをpyautoguiで操作する。実行中はPCを触れなくなるうえ、
             座標クリック頼みで確認も弱いため、Chromeが使えない場合の予備。
    """
    mode = (staff.get("send_mode") or "chrome").lower()
    if mode == "pc":
        import line_pc
        return line_pc
    import line_chrome
    return line_chrome


_conn = None
_conn_host = None


def _close_connection():
    global _conn
    if _conn is not None:
        try:
            _conn.close()
        except Exception:
            pass
        _conn = None


def _connection(url):
    """HTTPS接続を張りっぱなしにして使い回す。

    ★毎回つなぎ直してはいけない。
      そのたびにTLSの握手が入り、証明書のやり取りも発生する。
      実測で1回114ms → 58ms（2倍速）。2秒ごとに回すなら、
      この待ち時間がそのまま「取得から送信までの遅れ」になる。
    """
    global _conn, _conn_host
    host = urllib.parse.urlparse(url).hostname
    if _conn is None or _conn_host != host:
        _close_connection()
        _conn = http.client.HTTPSConnection(host, timeout=60)
        _conn_host = host
    return _conn


def api(url, key, method, table, params=None, body=None, prefer=None):
    q = ("?" + urllib.parse.urlencode(params)) if params else ""
    path = f"/rest/v1/{table}{q}"
    headers = {"apikey": key, "Authorization": f"Bearer {key}",
               "Content-Type": "application/json"}
    if prefer:
        headers["Prefer"] = prefer
    data = json.dumps(body).encode() if body is not None else None

    # 接続はサーバ側から切られることがある。1度だけ張り直して試す。
    for attempt in (1, 2):
        try:
            conn = _connection(url)
            conn.request(method, path, body=data, headers=headers)
            res = conn.getresponse()
            raw = res.read().decode("utf-8")     # 読み切らないと次が使えない
            if res.status >= 400:
                raise RuntimeError(
                    f"{method} {table}: HTTP {res.status} {raw[:300]}")
            return json.loads(raw) if raw.strip() else []
        except RuntimeError:
            raise                                 # HTTPエラーは再試行しない
        except Exception:
            _close_connection()
            if attempt == 2:
                raise


def my_turn_since(url, key, staff_key):
    """自分が送信担当か、そしていつONにしたか。

    ★ONにした時刻より前の取得には送らない。
      ONにする前の案件は事務員が手作業で送致済みのはずで、
      後追いで自動送信すると二重送信になる。
    """
    rows = api(url, key, "GET", "staff",
               {"staff_key": f"eq.{staff_key}",
                "select": "auto_send,display_name,auto_send_on_at"})
    if not rows or not rows[0].get("auto_send"):
        return None
    return lp.parse_ts(rows[0]["auto_send_on_at"]) if rows[0].get("auto_send_on_at") \
        else datetime.now(lp.JST)


def is_my_turn(url, key, staff_key):
    """自分のPCが送信担当か（ダッシュボードで自分のトグルがONか）。

    ★全体の1つのスイッチではなく、事務員ごとのトグルで判定する。
      前のシフトの人がクライアントを閉じ忘れても、その人のトグルは
      交代時にOFFになるので、そのPCからは送信されない。
      DB側のトリガーで「同時にONにできるのは1人だけ」も保証している。
    """
    rows = api(url, key, "GET", "staff",
               {"staff_key": f"eq.{staff_key}", "select": "auto_send,display_name"})
    if not rows:
        return False, None
    return bool(rows[0].get("auto_send")), rows[0].get("display_name")


def heartbeat(url, key, staff_key):
    """自分のPCでクライアントが動いていることをDBに記録する。

    トグルがONでもクライアントが起動していなければ送信されないので、
    ダッシュボードで「稼働中／未起動」を見分けられるようにする。
    """
    try:
        api(url, key, "PATCH", "staff", {"staff_key": f"eq.{staff_key}"},
            body={"client_seen_at": datetime.now(lp.JST).isoformat()},
            prefer="return=minimal")
    except Exception:
        pass          # 生存報告の失敗で本処理を止めない


def current_sender(url, key):
    """いま送信担当になっている事務員（表示用）。"""
    rows = api(url, key, "GET", "staff",
               {"auto_send": "eq.true", "select": "staff_key,display_name"})
    return rows[0] if rows else None


def poll_once(url, key, staff_key, last_event_id):
    """巡回1回分の状態を1往復で取る。使えないときは None。

    ★往復を減らすのは通信量のためだけではない。
      1回あたりの待ち時間が4分の1になるので、取得から送信までが速くなる。
      セカンドは受取から15分が期限なので、ここは落とせない。

    サーバ側に関数が無い（SQLをまだ実行していない）場合は None を返し、
    呼び出し側が従来の4回問い合わせに戻る。更新の順序に依存させない。
    """
    try:
        r = api(url, key, "POST", "rpc/sender_poll",
                body={"p_staff": staff_key, "p_last_event_id": last_event_id or 0})
    except Exception:
        return None
    # PostgRESTはスカラー戻り値をそのまま返す
    return r if isinstance(r, dict) else None


def apply_mode(staff, mode):
    """sender_poll が返したモードを staff に反映する（判定は下と同じ）。"""
    cfg = mode if isinstance(mode, dict) else None
    if cfg is None:
        log("[警告] テストモード設定が見つかりません。安全のためテストモードで動きます。")
        cfg = {"enabled": True}
    staff["test_mode"] = bool(cfg.get("enabled", True)) or bool(
        staff.get("force_test_mode"))
    staff["test_redirect_to"] = cfg.get("redirect_to") or "FSJ事務bot"
    staff["test_report_room"] = cfg.get("report_room") or "テストトランジットROOM"
    return staff


def resolve_test_mode(url, key, staff):
    """テストモードかどうかをDBから読み、staff に反映する。

    ★PCごとの設定ファイルには置かない。事務員が「はじめに実行」をすると
      設定ファイルが作り直されるため、そこにテストモードを書いていると
      新しい人だけ本番送信になる。全員が同じ設定を見るようにする。

    ★読めなかった場合・設定が無い場合はテストモードとして扱う。
      判断がつかないときに実際のプレイヤーへ送るより、送らない方が安全。
      （本番に切り替えたのに送られない事故は、画面を見ればすぐ気づける）
    """
    cfg = None
    try:
        rows = api(url, key, "GET", "app_settings",
                   {"key": f"eq.{TEST_KEY}", "select": "value"})
        cfg = rows[0]["value"] if rows else None
    except Exception as ex:
        log(f"[警告] テストモード設定を読めません（{str(ex)[:60]}）")
    if not isinstance(cfg, dict):
        log("[警告] テストモード設定が見つかりません。安全のためテストモードで動きます。")
        cfg = {"enabled": True}

    # force_test_mode はそのPCだけを強制的にテストにする逃げ道。
    # 逆向き（1台だけ本番にする）は用意しない。事故の向きが違う。
    staff["test_mode"] = bool(cfg.get("enabled", True)) or bool(
        staff.get("force_test_mode"))
    staff["test_redirect_to"] = cfg.get("redirect_to") or "FSJ事務bot"
    staff["test_report_room"] = cfg.get("report_room") or "テストトランジットROOM"
    return staff


# ══════════════════════════════════════════════════════════
#  取得の検知 → キュー投入
# ══════════════════════════════════════════════════════════

_EVENT_COLS = ("id,event_type,group_id,user_id,message_id,text,"
               "quoted_message_id,case_nos,sent_at")


def recent_events(url, key, hours):
    """直近hours分のイベントを一度に取る（初回・単発用）。"""
    since = (datetime.now(lp.JST) - timedelta(hours=hours)).isoformat()
    return api(url, key, "GET", "line_events", {
        "select": _EVENT_COLS,
        "sent_at": f"gte.{since}", "order": "id.asc", "limit": 5000})


class EventWindow:
    """直近N時間のイベントを手元に持ち、増えた分だけ取りに行く。

    ★毎回6時間分を取り直してはいけない。
      1回169KB × 5秒ごと ＝ 1か月83GB になり、無料枠(10GB/月)を
      数日で使い切って受信が止まる（＝取り返せない取りこぼし）。

    ★かといって窓は狭められない。
      「名前だけの短い返信」をどの案件に紐づけるかは、前に流れた
      ファーストを見て決めるため、過去数時間分が手元に要る。

    そこで窓は保持したまま、差分だけ取る。idは連番なのでこれが使える。
    """

    def __init__(self, hours):
        self.hours = hours
        self.rows = []
        self.last_id = None

    def refresh(self, url, key):
        if self.last_id is None:
            since = (datetime.now(lp.JST) - timedelta(hours=self.hours)).isoformat()
            new = api(url, key, "GET", "line_events", {
                "select": _EVENT_COLS, "sent_at": f"gte.{since}",
                "order": "id.asc", "limit": 5000})
            self.rows = list(new)
        else:
            new = api(url, key, "GET", "line_events", {
                "select": _EVENT_COLS, "id": f"gt.{self.last_id}",
                "order": "id.asc", "limit": 5000})
            self.rows.extend(new)

        # ★last_id は取得した生の最大値で進める。
        #   下の切り捨て後の一覧から取り直すと値が戻り、同じ行を
        #   何度も取りに行くことになる。
        if new:
            self.last_id = max(r["id"] for r in new)
        elif self.last_id is None:
            self.last_id = 0

        cutoff = datetime.now(lp.JST) - timedelta(hours=self.hours)
        self.rows = [r for r in self.rows if lp.parse_ts(r["sent_at"]) >= cutoff]
        return self.rows


def find_second(url, key, transit_gid, case_no):
    """トランジットROOMから該当案件のセカンド本文を取る（最新を採用）。"""
    if not transit_gid:
        return ""
    rows = api(url, key, "GET", "line_events", {
        "select": "text,sent_at", "group_id": f"eq.{transit_gid}",
        "case_nos": f"cs.{{{case_no}}}", "order": "id.desc", "limit": 1})
    return (rows[0].get("text") or "") if rows else ""


def enqueue(url, key, groups, master, transit_gid, events, since=None):
    """新しく検知した取得をキューに積む。既にあるものは一意制約で弾かれる。

    since（トグルをONにした時刻）より前の取得は積まない。
    """
    added = []
    by_room = {}
    for e in events:
        name = groups.get(e.get("group_id")) or ""
        if "案件紹介" in name or "送客" in name:
            by_room.setdefault((e["group_id"], name), []).append(e)

    # ①トグルをONにした時刻より前は対象外（ONにする前は手作業で送致済み）
    # ②さらに15分より古いものも対象外（クライアントが長時間止まっていた場合の保険）
    cutoff = datetime.now(lp.JST) - timedelta(minutes=MAX_CLAIM_AGE_MINUTES)
    if since and since > cutoff:
        cutoff = since
    for (gid, name), evs in by_room.items():
        for r in dc.detect(evs, master, name):
            if r["confidence"] not in ("確定", "推定"):
                continue
            if lp.parse_ts(r["sent_at"]) < cutoff:
                continue
            m = master.get(r["user_id"]) or {}
            second = find_second(url, key, transit_gid, r["case_no"])
            row = {
                "case_no": r["case_no"], "room_group_id": gid, "room_name": name,
                "player_user_id": r["user_id"],
                # ★列名は player_line_name のままだが、入れるのは管理表の呼び名。
                #   画面に出るのはこの値で、LINE登録名では他の事務員に通じない。
                "player_line_name": dc.display_name(m),
                "claim_message_id": r.get("message_id"),
                "second_text": second, "confidence": r["confidence"],
                "detect_reason": r["reason"], "detected_at": r["sent_at"],
            }
            try:
                api(url, key, "POST", "dispatch_queue", body=row,
                    prefer="return=minimal,resolution=ignore-duplicates")
                added.append(row)
            except RuntimeError as ex:
                if "duplicate" not in str(ex).lower():
                    log(f"[警告] キュー投入に失敗 {r['case_no']}: {ex}")
    return added


# ══════════════════════════════════════════════════════════
#  送信
# ══════════════════════════════════════════════════════════


def update_queue(url, key, qid, patch):
    api(url, key, "PATCH", "dispatch_queue", {"id": f"eq.{qid}"},
        body=patch, prefer="return=minimal")


def claim_queue(url, key, qid, staff_key):
    """まだ pending のときだけ自分のものにする。取れたら True。

    ★条件付きで更新するのが要点。
      同じPCで常駐を2つ開いた／シフト交代の数秒間だけ2人ともONだった、
      という状況で、同じ案件を2人が同時に送ってしまう。
      顧客に同じセカンドが2通届くので、DB側で1つに絞る。
      条件を外して更新すると、後から来た方も「取れた」と思って送る。
    """
    rows = api(url, key, "PATCH", "dispatch_queue",
               {"id": f"eq.{qid}", "status": "eq.pending"},
               body={"status": "sending", "locked_by": staff_key,
                     "locked_at": datetime.now(lp.JST).isoformat()},
               prefer="return=representation")
    return bool(rows)


def reclaim_stuck(url, key, minutes=10):
    """送信中のまま止まった行を拾い上げる。戻り値: 拾った行

    ★放置すると案件が消える。
      ウィンドウを閉じた・PCが落ちた等で 'sending' のまま残ると、
      次からは pending だけを見るので二度と処理されず、その案件は
      誰にも送られないまま誰も気づかない。

    ★pending には戻さない。
      中断した時点で送信済みだったかどうかは分からない。戻すと
      顧客に2通届く恐れがあるので、失敗として画面に出し、
      人が判断できるようにする。
    """
    cutoff = (datetime.now(lp.JST) - timedelta(minutes=minutes)).isoformat()
    rows = api(url, key, "PATCH", "dispatch_queue",
               {"status": "eq.sending",
                "or": f"(locked_at.lt.{cutoff},locked_at.is.null)"},
               body={"status": "failed",
                     "note": "送信中に中断（送信済みかどうか要確認）"},
               prefer="return=representation")
    return rows or []


# 本文待ちの案件の状態。キューIDごとに持つ。
_second_recheck_at = {}     # 次に本文を探してよい時刻
_second_waiting = set()     # 「待っています」を出し終えたもの（毎巡回で出さない）


def refetch_second(url, key, transit_gid, qid, case_no):
    """セカンド本文をもう一度探し、見つかればキューに書き戻す。

    毎巡回（2秒ごと）に問い合わせると通信が増えるので、数秒に1回に絞る。
    """
    if time.time() < _second_recheck_at.get(qid, 0):
        return ""
    _second_recheck_at[qid] = time.time() + SECOND_RECHECK_SECONDS
    body = find_second(url, key, transit_gid, case_no)
    if not body or case_no not in body:
        return ""
    update_queue(url, key, qid, {"second_text": body})
    return body


def process_pending(url, key, staff, live, confirm, transit_gid=None):
    pend = api(url, key, "GET", "dispatch_queue", {
        "select": "*", "status": "eq.pending", "order": "detected_at.asc",
        "limit": 20})
    if not pend:
        return 0, 0

    sent = skipped = 0
    for q in pend:
        case_no, uid = q["case_no"], q.get("player_user_id") or ""
        label = f"{case_no} → {q.get('player_line_name') or uid[:10]}"

        # 送信先は「取得のリプライを送ったメッセージ」から特定する。
        # 事前の紐づけも名前の照合も不要。
        claim_msg = q.get("claim_message_id")
        name = q.get("player_line_name") or ""
        if not claim_msg:
            log(f"[保留] {label} … 取得リプライのメッセージIDがありません")
            update_queue(url, key, q["id"],
                         {"status": "failed", "note": "claim_message_id なし"})
            skipped += 1
            continue

        body = q.get("second_text") or ""
        if not body or case_no not in body:
            # ★ここで諦めない。取得を検知した時点ではまだ本文が
            #   トランジットROOMに流れていないことがある（実測2.5秒先行）。
            body = refetch_second(url, key, transit_gid, q["id"], case_no)

        if not body:
            waited = (datetime.now(lp.JST)
                      - lp.parse_ts(q["detected_at"])).total_seconds()
            if waited < SECOND_WAIT_SECONDS:
                # pending のまま残し、次の巡回で見直す。
                # 案内は1回だけ。2秒ごとに出すと履歴が埋まる。
                if q["id"] not in _second_waiting:
                    _second_waiting.add(q["id"])
                    log(f"[待機] {label} … セカンド本文がまだ届いていません"
                        f"（{SECOND_WAIT_SECONDS // 60}分待ちます）")
                continue
            log(f"[保留] {label} … セカンド本文が"
                f"{SECOND_WAIT_SECONDS // 60}分待っても届きませんでした")
            update_queue(url, key, q["id"],
                         {"status": "failed",
                          "note": f"セカンド本文なし（{SECOND_WAIT_SECONDS // 60}分待機）"})
            _second_waiting.discard(q["id"])
            _second_recheck_at.pop(q["id"], None)
            skipped += 1
            continue

        if q["id"] in _second_waiting:
            log(f"[本文着] {label} … セカンド本文が届きました。送信します")
            _second_waiting.discard(q["id"])
            _second_recheck_at.pop(q["id"], None)

        if not live:
            try:
                sender = load_sender(staff)
                mid, shown = sender.send_reply_sender(
                    q.get("room_name"), claim_msg, body,
                    ctx=sender.SendContext(dry_run=True))
                log(f"[ドライラン] {label} … 「{shown}」宛に {len(body)}文字を送信予定")
            except Exception as ex:
                log(f"[ドライラン] {label} … 送信先を特定できません: {str(ex)[:60]}")
            sent += 1
            continue

        # 送信直前にもう一度担当を確認する。巡回中にシフト交代でトグルが
        # 切り替わった場合、前の担当のPCから送ってしまわないようにするため。
        mine, _ = is_my_turn(url, key, staff["staff_key"])
        if not mine:
            log(f"[中止] {label} … 送信担当から外れました")
            return sent, skipped

        if confirm:
            ans = input(f"  送信しますか？ {label} → 「{name}」 (y/n) > ").strip().lower()
            if ans not in ("y", "yes"):
                update_queue(url, key, q["id"],
                             {"status": "skipped", "note": "手動で見送り"})
                print("    見送りました")
                skipped += 1
                continue

        # 取れなかった＝他のPC（または同じPCの別ウィンドウ）が先に取った。
        # 二重送信になるので、ここで必ず降りる。
        if not claim_queue(url, key, q["id"], staff["staff_key"]):
            log(f"[譲渡] {label} … 他で処理中のため送りません")
            continue
        try:
            sender = load_sender(staff)

            # ── テストモード ──
            # 取得者の特定までは本番と同じ手順を踏むが、セカンドは
            # プレイヤーではなく転送先へ送り、リアクションも付けない。
            if staff.get("test_mode"):
                res = sender.send_reply_sender_test(
                    q.get("room_name"), claim_msg, body,
                    redirect_to=staff.get("test_redirect_to", "FSJ事務bot"),
                    report_room=staff.get("test_report_room", "テストトランジットROOM"),
                    report_prefix=f"{case_no} セカンド送信完了、"
                                  f"リアクションマークテスト済み",
                    react_emoji=staff.get("reaction_emoji", "1003"))
                update_queue(url, key, q["id"], {
                    "status": "test", "sent_at": datetime.now(lp.JST).isoformat(),
                    "note": f"テストモード（本来の宛先: {res['sender']}）"})
                log(f"[テスト] {case_no} 本来の宛先={res['sender']} → "
                      f"{staff.get('test_redirect_to', 'FSJ事務bot')} に送信 / "
                      f"リアクション{'可' if res['can_react'] else '不可'}")
                sent += 1
                continue

            # ★取得のリプライを送った本人のトークへ送る。
            #   ルーム内の該当メッセージから送信者の内部IDを読み取るので、
            #   同姓の知人や本人の2つ目のアカウントと取り違えない。
            #   送信成功後、取得リプライにリアクションを付けて「送った印」にする。
            _, sent_to = sender.send_reply_sender(
                q.get("room_name"), claim_msg, body,
                react_emoji=staff.get("reaction_emoji", "1003"))
            name = sent_to or name
            update_queue(url, key, q["id"], {
                "status": "sent", "sent_at": datetime.now(lp.JST).isoformat()})
            # 送れた＝検索名が正しかった証拠として記録しておく
            log(f"[送信] {label} → 「{name}」")
            sent += 1
        except Exception as ex:
            update_queue(url, key, q["id"],
                         {"status": "failed", "note": str(ex)[:200],
                          "locked_by": None})
            log(f"[失敗] {label}: {ex}")
            skipped += 1
    return sent, skipped


# ══════════════════════════════════════════════════════════
#  サブコマンド
# ══════════════════════════════════════════════════════════

def cmd_status(url, key, staff):
    print(f"事務員: {staff.get('display_name') or staff['staff_key']}")
    print(f"モード: {'テストモード（プレイヤーには送りません）' if staff.get('test_mode') else '★本番送信'}")
    mine, _ = is_my_turn(url, key, staff["staff_key"])
    cur = current_sender(url, key)
    print(f"このPCの自動送信: {'ON（送信担当）' if mine else 'OFF'}")
    print(f"現在の送信担当: {cur['display_name'] if cur else '誰もいません'}")
    rows = api(url, key, "GET", "dispatch_queue", {"select": "status"})
    tally = {}
    for r in rows:
        tally[r["status"]] = tally.get(r["status"], 0) + 1
    print("キュー: " + (" / ".join(f"{k} {v}件" for k, v in sorted(tally.items()))
                    or "空"))




# ══════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true", help="実際に送信する（既定はドライラン）")
    ap.add_argument("--confirm", action="store_true", help="1件ごとに送信確認する")
    ap.add_argument("--once", action="store_true", help="1回だけ実行して終了")
    ap.add_argument("--interval", type=int, default=POLL_SECONDS, help="巡回間隔(秒)")
    ap.add_argument("--status", action="store_true", help="状況を表示して終了")
    args = ap.parse_args()

    staff = load_staff()
    url, key = lp.load_config()
    resolve_test_mode(url, key, staff)

    if args.status:
        return cmd_status(url, key, staff)

    # 起動のたびに担当者マスタを取り直す。マッピングを直しても各PCが
    # 古いままだと、取得者を取り違えて別の人に顧客情報を送りかねない。
    try:
        n = dc.refresh_from_db(url, key)
        if n:
            print(f"担当者マスタ: {n}人分を取り込みました")
    except Exception as e:
        print(f"[警告] 担当者マスタを更新できません（{str(e)[:50]}）。手元の内容で動きます。")

    master = dc.load_master()
    groups = {g["group_id"]: g["name"] for g in
              lp.fetch_all(url, key, "line_groups", "group_id,name",
                           order_col="group_id")}
    transit_gid = next((g for g, n in groups.items() if n == TRANSIT_ROOM), None)
    if not transit_gid:
        print(f"[警告] 「{TRANSIT_ROOM}」が見つかりません。セカンド本文を取得できません。")

    if staff.get("test_mode"):
        mode = (f"テストモード（プレイヤーには送らず "
                f"{staff.get('test_redirect_to', 'FSJ事務bot')} へ送信）")
    else:
        mode = "実送信" if args.live else "ドライラン（送信しません）"
    print(f"事務員: {staff.get('display_name') or staff['staff_key']} / モード: {mode}")
    if staff.get("test_mode"):
        print(f"※ リアクションは付けません。結果は "
              f"{staff.get('test_report_room', 'テストトランジットROOM')} に書き込みます。")
    elif args.live and not args.confirm:
        print("※ 無人で実送信します。止めるときは Ctrl+C。")

    # ★待機中の表示は履歴に残さない。
    #   5秒ごとに「新しい取得はありません」を積むと、実際に起きたこと
    #   （検知・送信・失敗）が流れて見えなくなる。待機は最下行を
    #   書き換えるだけにして、履歴には出来事だけを残す。
    totals = {"検知": 0, "送信": 0, "失敗": 0}
    last_hour = None
    last_reclaim = 0.0
    on_duty = False
    window = EventWindow(LOOKBACK_HOURS)

    # 新着を「入った瞬間」に受け取る。失敗しても送信は止めない。
    watcher = None
    try:
        import realtime_watch
        watcher = realtime_watch.Watcher(url, key)
        watcher.start()
        if watcher.connected(timeout=8):
            log("新着の通知を受け取れます（即時反応）")
        else:
            log(f"通知は使えません。決まった間隔で確認します"
                f"（{watcher.last_error or '接続待ち'}）")
    except Exception as e:
        log(f"通知の準備に失敗（{str(e)[:60]}）。決まった間隔で確認します。")

    while True:
        try:
            # ★状態の取得は1往復にまとめる（生存報告・モード・担当・新着）。
            #   往復が減るぶん通信量も待ち時間も減る。
            #   サーバ側に関数が無い環境では従来の4回問い合わせに落ちる。
            was_test = staff.get("test_mode")
            snap = poll_once(url, key, staff["staff_key"], window.last_id)
            if snap is not None:
                apply_mode(staff, snap.get("mode"))
                since = (lp.parse_ts(snap["since"]) if snap.get("since")
                         else (datetime.now(lp.JST) if snap.get("auto_send") else None))
                if not snap.get("auto_send"):
                    since = None
                duty = snap.get("duty") or "なし"
                has_new = bool(snap.get("has_new")) or bool(snap.get("pending"))
            else:
                heartbeat(url, key, staff["staff_key"])
                resolve_test_mode(url, key, staff)
                since = my_turn_since(url, key, staff["staff_key"])
                duty = (current_sender(url, key) or {}).get("display_name") or "なし"
                has_new = True          # 分からないので毎回見る
            if staff.get("test_mode") != was_test:
                log(f"モードが変わりました → "
                    f"{'テストモード' if staff['test_mode'] else '★本番送信'}")

            now = datetime.now(lp.JST)
            # 1時間ごとに1行だけ残す。朝見たときに「夜中も動いていた」と分かる。
            if last_hour is not None and now.hour != last_hour:
                log(f"稼働中（この時間の 検知{totals['検知']} / 送信{totals['送信']}"
                    f" / 失敗{totals['失敗']}）")
                totals = {"検知": 0, "送信": 0, "失敗": 0}
            last_hour = now.hour

            on_duty = since is not None
            if since is None:
                status(f"待機中 — このPCは送信担当ではありません（現在の担当: {duty}）")
            else:
                # 送信中のまま止まった行を拾う。毎巡回だと問い合わせが増えるので
                # 1分に1回でよい（止まった案件は分単位で気づけば十分）。
                if time.time() - last_reclaim > 60:
                    last_reclaim = time.time()
                    for r in reclaim_stuck(url, key):
                        totals["失敗"] += 1
                        log(f"[要確認] {r['case_no']} … 前回の送信が中断していました"
                            f"（送信済みかどうか確認してください）")

                # ★新着も送信待ちも無いなら、この先は何も起きない。
                #   問い合わせを増やさないために丸ごと飛ばす。
                if not has_new:
                    status(f"監視中 — この時間の 検知{totals['検知']}"
                           f" / 送信{totals['送信']} / 失敗{totals['失敗']}")
                    if args.once:
                        break
                    if watcher and watcher.connected():
                        watcher.wait(SAFETY_POLL_SECONDS)
                    else:
                        time.sleep(args.interval)
                    continue

                evs = window.refresh(url, key)
                added = enqueue(url, key, groups, master, transit_gid, evs, since)
                for a in added:
                    totals["検知"] += 1
                    log(f"[検知] {a['case_no']} ← "
                        f"{a['player_line_name']}（{a['confidence']}）")
                sent, skipped = process_pending(url, key, staff, args.live,
                                                args.confirm, transit_gid)
                totals["送信"] += sent
                totals["失敗"] += skipped
                status(f"監視中 — この時間の 検知{totals['検知']}"
                       f" / 送信{totals['送信']} / 失敗{totals['失敗']}")
        except KeyboardInterrupt:
            raise
        except Exception as ex:
            log(f"[エラー] {ex}")

        if args.once:
            break

        # 通知が使えるなら、来るまで待つ（来た瞬間に次の巡回へ進む）。
        # 使えないときだけ、決まった間隔で回る。
        if on_duty:
            gap = SAFETY_POLL_SECONDS if (watcher and watcher.connected())                 else args.interval
        else:
            gap = IDLE_POLL_SECONDS
        if watcher and watcher.connected():
            watcher.wait(gap)
        else:
            time.sleep(gap)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n終了しました。")
