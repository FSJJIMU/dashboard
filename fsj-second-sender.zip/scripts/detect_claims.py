#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""detect_claims.py — 案件紹介ROOMで「誰がどの案件を取得したか」を判定する。

セカンド自動送信の心臓部。ここを間違えると、取得していない人にセカンドを
送ってしまうため、まず実データで精度を確認するための検証用として作った。

判定の考え方:
  1. FSJ事務bot（事務側）が投稿した【案件番号】入りのメッセージ＝ファースト
  2. そのあとに来る、事務員以外からの短いメッセージ＝取得の意思表示
  3. 引用リプライ(quoted_message_id)があれば、対象案件は確定
  4. 引用がない場合は「直前のファースト」に紐づける。ただし返信が来る前に
     ファーストが2件以上並んだ場合は、どれ宛てか確定できないので保留にする
     （CLAUDE.md「立て続け投稿の曖昧ケース」と同じ扱い）
  5. 同じ案件で先に取得した人がいれば、後の人は対象外（先着のみ）

使い方:
    python -X utf8 scripts/detect_claims.py --date 2026/08/10
    python -X utf8 scripts/detect_claims.py --date 2026/08/10 --all   # 曖昧・重複も表示
"""

import argparse
import csv
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

import line_pull as lp  # noqa: E402

MASTER_CSV = SCRIPT_DIR / "player_master.csv"

# CSVの列順。jsonbはキーの順を保たないため、ここで決め打ちにする。
# 決めておかないと取り込むたびに列の並びが変わり、事務員のPCのCSVを
# 開いたときに毎回違う見た目になる。build_player_master.py の出力と同じ順。
MASTER_COLUMNS = ["管理表名", "担当者2", "グループ", "備考", "txt表記上書き",
                  "LINE登録名", "表示名", "txt表記", "出現回数", "確認", "user_id"]

# 取得の意思表示ではない返信（事務側のやりとり・保留・雑談）
NOT_CLAIM = re.compile(
    r"確認|コール|お願い|よろしく|了解|ありがとう|すみません|申し訳"
    r"|転送|送致|移動|引き継|詳細|至急|折り返し|不在|留守|変更|訂正|取消"
    r"|できま|ですか|ますか|でしょうか|[?？]")

# 取得の意思表示とみなす最大文字数（名前だけを想定）
MAX_CLAIM_LEN = 20
CASE_RE = re.compile(r"(?<!\d)\d{7}(?!\d)")


def refresh_from_db(url, key):
    """担当者マスタをDBから取り直して player_master.csv に書く。

    ★CSVを配る方式をやめた理由:
      配ったあとにマッピングを直しても、各PCのCSVは古いままになる。
      取得者の判定に使うファイルなので、古いと誤った相手に送りかねない。
      また配布物を公開の場所に置けるようにするため、氏名やLINE IDを
      配布物から外す必要もあった。

    取得できなければ何も書かない（手元のCSVをそのまま使う）。
    通信が切れただけで判定材料を失う方が危ないため。
    """
    rows = lp.fetch_all(url, key, "player_master",
                        "token,sort_order,fields", order_col="sort_order")
    rows = [r for r in rows if isinstance(r.get("fields"), dict)]
    if not rows:
        return 0
    keys = set()
    for r in rows:
        keys |= set(r["fields"])
    header = ([c for c in MASTER_COLUMNS if c in keys]
              + [c for c in sorted(keys) if c not in MASTER_COLUMNS])
    with MASTER_CSV.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=header, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r["fields"])
    return len(rows)


def display_name(m, fallback=""):
    """画面に出す取得者の呼び名。

    ★管理表の呼び名で出す。
      LINE登録名は管理者が自分用に付けた名前なので、他の事務員が見ても
      誰のことか分からない（例:「後藤2」「田中久士/オンノット」）。
      担当者2があるときは「森崎T 石井」のように続ける。管理表と同じ
      書き方にしておけば、そのまま突き合わせられる。
      管理表名がまだ空の人（新しく入った人）はLINE登録名で代用する。
    """
    if not m:
        return fallback
    a = (m.get("管理表名") or "").strip()
    b = (m.get("担当者2") or "").strip()
    if a:
        return f"{a} {b}" if b else a
    return (m.get("LINE登録名") or "").strip() or fallback


def load_master():
    """player_master.csv から user_id → (管理表名, LINE登録名, 区分) を作る。"""
    by_uid = {}
    if not MASTER_CSV.exists():
        return by_uid
    with MASTER_CSV.open(encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            uid = (r.get("user_id") or "").strip()
            if uid:
                by_uid[uid] = {
                    "管理表名": (r.get("管理表名") or "").strip(),
                    "担当者2": (r.get("担当者2") or "").strip(),
                    "LINE登録名": (r.get("LINE登録名") or "").strip(),
                    # 友だち一覧に出るのは括弧まで含んだ完全な表記。
                    # 「加藤」で探すと別人の「加藤　亮」まで拾ってしまうため、
                    # 相手を探すときは必ずこちらを使う。
                    "txt表記": (r.get("txt表記") or "").strip(),
                    "確認": (r.get("確認") or "").strip(),
                    "備考": (r.get("備考") or "").strip(),
                }
    return by_uid


def is_office(uid, master):
    """事務側の投稿者か（＝取得者にはなり得ない）。"""
    m = master.get(uid) or {}
    return m.get("確認") in ("事務(対象外)",) or "事務員" in m.get("備考", "")


def detect(events, master, room_name):
    """1ルーム分のイベント列から取得を判定する。

    戻り値: [{case_no, user_id, text, sent_at, confidence, reason}]
    """
    events = sorted(events, key=lambda e: (e["sent_at"], e["id"]))
    by_msgid = {e["message_id"]: e for e in events if e.get("message_id")}

    open_cases = []          # 返信待ちのファースト（案件番号のリスト）
    claimed = {}             # 案件番号 → 最初に取得した人
    results = []

    for e in events:
        if e.get("event_type") != "message":
            continue
        uid = e.get("user_id") or ""
        text = (e.get("text") or "").strip()
        cases = e.get("case_nos") or []

        # --- ファースト（事務側が投稿した案件番号入りの長文） ---
        if cases and (is_office(uid, master) or len(text) > 60):
            open_cases = list(dict.fromkeys(open_cases + cases))
            continue

        if not text or is_office(uid, master):
            continue

        # --- 引用リプライなら対象案件が確定する ---
        quoted = e.get("quoted_message_id")
        target, conf, reason = None, None, ""
        if quoted and quoted in by_msgid:
            qcases = by_msgid[quoted].get("case_nos") or []
            if len(qcases) == 1:
                target, conf, reason = qcases[0], "確定", "引用リプライ"
            elif len(qcases) > 1:
                reason = f"引用先に案件番号が{len(qcases)}件あり特定不可"

        # --- 本文に案件番号が書かれていれば、それも確定扱い ---
        if target is None and len(CASE_RE.findall(text)) == 1 and len(text) <= 40:
            target, conf, reason = CASE_RE.findall(text)[0], "確定", "本文に案件番号"

        # --- 名前だけの短い返信 → 直前のファーストに紐づける ---
        if target is None:
            if len(text) > MAX_CLAIM_LEN or NOT_CLAIM.search(text):
                continue                       # 取得の意思表示ではない
            if not open_cases:
                continue
            if len(open_cases) == 1:
                target, conf, reason = open_cases[0], "推定", "直前のファースト"
            else:
                target, conf = open_cases[-1], "曖昧"
                reason = f"未取得のファーストが{len(open_cases)}件並んでいる"

        if target is None:
            continue

        if target in claimed:
            results.append({"case_no": target, "user_id": uid, "text": text,
                            "sent_at": e["sent_at"], "room": room_name,
                            "message_id": e.get("message_id"),
                            "confidence": "取得済み",
                            "reason": f"先に{claimed[target]}が取得済み"})
            continue

        if conf in ("確定", "推定"):
            claimed[target] = display_name(master.get(uid), uid[:10])
            open_cases = [c for c in open_cases if c != target]
        results.append({"case_no": target, "user_id": uid, "text": text,
                        "sent_at": e["sent_at"], "room": room_name,
                        # 取得リプライのメッセージID。
                        # これがあれば、ルーム内の該当メッセージから送信者本人の
                        # トークを直接開ける（名前で探す必要も紐づけも不要）。
                        "message_id": e.get("message_id"),
                        "confidence": conf, "reason": reason})
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", help="対象日 YYYY/MM/DD（省略時は全期間）")
    ap.add_argument("--all", action="store_true", help="曖昧・取得済みも表示")
    args = ap.parse_args()

    master = load_master()
    url, key = lp.load_config()
    groups = {g["group_id"]: g["name"] for g in
              lp.fetch_all(url, key, "line_groups", "group_id,name",
                           order_col="group_id")}
    events = lp.fetch_all(url, key, "line_events",
                          "id,event_type,group_id,user_id,message_id,text,"
                          "quoted_message_id,case_nos,sent_at")

    target_date = args.date.replace("/", "-") if args.date else None
    by_group = {}
    for e in events:
        name = groups.get(e.get("group_id")) or ""
        if "案件紹介" not in name and "送客" not in name:
            continue
        if target_date and lp.parse_ts(e["sent_at"]).strftime("%Y-%m-%d") != target_date:
            continue
        by_group.setdefault(name, []).append(e)

    total = {"確定": 0, "推定": 0, "曖昧": 0, "取得済み": 0}
    for room, evs in sorted(by_group.items()):
        rows = detect(evs, master, room)
        show = [r for r in rows if args.all or r["confidence"] in ("確定", "推定")]
        if not show:
            continue
        print(f"\n■ {room}")
        for r in rows:
            total[r["confidence"]] = total.get(r["confidence"], 0) + 1
        for r in show:
            m = master.get(r["user_id"]) or {}
            who = display_name(m, r["user_id"][:12])
            line = m.get("LINE登録名") or "-"
            t = lp.parse_ts(r["sent_at"]).strftime("%H:%M")
            print(f"  {t}  {r['case_no']}  {who}（LINE: {line}）"
                  f"  [{r['confidence']}] {r['reason']}")

    print("\n=== 集計 ===")
    for k in ("確定", "推定", "曖昧", "取得済み"):
        print(f"  {k}: {total.get(k, 0)}件")
    print("  ※ セカンド自動送信の対象は「確定」「推定」のみ。"
          "「曖昧」は人が判断する。")


if __name__ == "__main__":
    main()
