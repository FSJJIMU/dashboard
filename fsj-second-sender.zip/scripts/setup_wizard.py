#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""setup_wizard.py — 事務員のPCで最初に1回だけ実行する案内役。

PC操作が得意でない人でも、質問に答えるだけで使える状態になることを目指す。
やること:
  1. 自分の名前を聞いて second_sender.json を作る
  2. データベースの事務員一覧に自動登録する
  3. Chrome版LINEの状態を確認し、必要なら起動を案内する
  4. 最後に全体を診断して、残る問題があれば直し方を出す
"""

import json
import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

CONFIG = SCRIPT_DIR / "second_sender.json"

# 接続先。鍵ではないので配布物に書いてよい（画面のHTMLにも同じものが書いてある）。
SUPABASE_URL = "https://vbzwevceisxliumsqytd.supabase.co"

# 起動用ファイルはOSごとに分けてある。間違ったものを開かせないため。
# 置き場所は2通りある:
#   配布物   FSJセカンド自動送信/Windows/      … 二重フォルダは分かりにくいので浅くした
#   共有側   FSJ関連/セカンド自動送信/Windows/  … 他の資料と並ぶので1段挟む
_OS_DIR = "Mac" if sys.platform == "darwin" else "Windows"
LAUNCH_EXT = ".command" if sys.platform == "darwin" else ".bat"
LAUNCH_DIR = next(
    (p for p in (PROJECT_DIR / _OS_DIR,
                 PROJECT_DIR / "セカンド自動送信" / _OS_DIR)
     if (p / ("はじめに実行" + LAUNCH_EXT)).exists()),
    PROJECT_DIR / _OS_DIR)

# デスクトップに出すもの。毎日使う2つと、困ったとき用の1つ。
# 「はじめに実行」は一度きりなので置かない。
DESKTOP_NAME = "セカンド自動送信"
LAUNCHERS = ["LINE用Chrome起動", "セカンド自動送信_常駐起動", "セットアップ診断"]


def ask(prompt, default=""):
    s = input(prompt).strip()
    return s or default


def line(c="─", n=58):
    print(c * n)


def migrate_old_install():
    """前の置き場所に残っている設定を引き継ぐ。

    フォルダ構成を変えるたびに送信用キーを入れ直させるのは無駄なので、
    心当たりのある場所を順に見て、あればコピーする。
    見つからなければ何もしない（このあと手入力してもらう）。
    """
    home = Path.home()
    desktops = [home / "Desktop", home / "OneDrive" / "デスクトップ",
                home / "OneDrive" / "Desktop", home / "デスクトップ"]
    candidates = [d / "FSJセカンド自動送信" / "scripts" for d in desktops]
    candidates += [Path("C:/FSJ/fsj-second-sender/scripts"),
                   Path("C:/FSJ-SecondSender/scripts"),
                   home / "FSJセカンド自動送信" / "scripts"]

    for old in candidates:
        src = old / "line_log.json"
        if not src.exists() or old.resolve() == SCRIPT_DIR:
            continue
        moved = []
        for name in ("line_log.json", "second_sender.json", "player_master.csv"):
            f = old / name
            if f.exists() and not (SCRIPT_DIR / name).exists():
                shutil.copy2(f, SCRIPT_DIR / name)
                moved.append(name)
        if moved:
            print(f"  前の設定を引き継ぎました（{old}）")
            print(f"    {', '.join(moved)}")
            print()
            return True
    return False


def ensure_db_config():
    """接続情報が無ければ、その場で入れてもらう。

    ★配布物には line_log.json を入れない。
      GitHubのような公開の場所から配る以上、同梱すると鍵が公開され、
      顧客の氏名・住所・電話番号まで誰でも読める状態になる。
      管理者から口頭で受け取って、このPCで1回だけ入力する。
    """
    path = SCRIPT_DIR / "line_log.json"
    if path.exists():
        return True

    # 置き場所を変えたときに、キーと名前を入れ直させないための引き継ぎ。
    # 古い場所が残っていれば、そこから設定だけ持ってくる。
    if migrate_old_install():
        return True

    print("  このパソコンにはまだ接続情報がありません。")
    print("  管理者から受け取った「送信用キー」を貼り付けてください。")
    print("  （ウィンドウ内で右クリックすると貼り付けられます。1回だけです）")
    print()
    key = ask("  送信用キー > ")
    if not key:
        print("\n  [!] 入力が無かったので中断します。")
        print("      管理者に「送信用キー」を聞いてから、もう一度実行してください。")
        return False

    path.write_text(json.dumps({"url": SUPABASE_URL, "service_key": key},
                               ensure_ascii=False, indent=2), encoding="utf-8")

    # 間違った鍵を入れたまま先へ進むと、後の失敗が何のせいか分からなくなる。
    # ここで一度つないでみて、駄目なら消してやり直してもらう。
    try:
        import line_pull as lp
        url, k = lp.load_config()
        lp.fetch_all(url, k, "line_groups", "group_id", order_col="group_id")
    except Exception as e:
        path.unlink(missing_ok=True)
        print(f"\n  [!] そのキーではつながりませんでした（{str(e)[:60]}）")
        print("      管理者にもう一度キーを確認して、実行し直してください。")
        return False
    print("  接続を確認しました。")
    print()
    return True


def refresh_master():
    """担当者マスタをDBから取り込む。配布物には入っていないため必須。"""
    try:
        import line_pull as lp
        import detect_claims as dc
        url, key = lp.load_config()
        n = dc.refresh_from_db(url, key)
        if n:
            print(f"  担当者マスタを取り込みました（{n}人分）")
        else:
            print("  [△] 担当者マスタが空でした。管理者に連絡してください。")
    except Exception as e:
        print(f"  [△] 担当者マスタを取り込めませんでした: {str(e)[:60]}")


def make_desktop_folder():
    """デスクトップに、毎日使うものへのショートカットをまとめて置く。

    共有フォルダの奥（FSJ関連 > セカンド自動送信 > Windows）まで
    毎回たどらせない。出勤のたびに開くものなので、手の届く所に出す。
    失敗しても本体の設定には影響しないので、警告だけ出して先へ進む。
    """
    try:
        if sys.platform == "darwin":
            return _desktop_mac()
        if sys.platform.startswith("win"):
            return _desktop_windows()
    except Exception as e:
        print(f"  [△] デスクトップにショートカットを作れませんでした: {str(e)[:60]}")
    return None


def _desktop_windows():
    # PowerShell に渡すスクリプトは ASCII だけにして、日本語は環境変数で渡す。
    # スクリプト内に日本語を書くと、文字コードの違いでフォルダ名が化ける。
    ps = r"""
$ErrorActionPreference = 'Stop'
$desk = [Environment]::GetFolderPath('Desktop')
$dir  = Join-Path $desk $env:FSJ_DESKNAME
New-Item -ItemType Directory -Force $dir | Out-Null
$w = New-Object -ComObject WScript.Shell
foreach ($n in ($env:FSJ_NAMES -split '\|')) {
  $t = Join-Path $env:FSJ_SRC ($n + '.bat')
  if (Test-Path -LiteralPath $t) {
    $s = $w.CreateShortcut((Join-Path $dir ($n + '.lnk')))
    $s.TargetPath = $t
    $s.WorkingDirectory = $env:FSJ_SRC
    $s.Save()
  }
}
[Console]::Out.Write($dir)
"""
    env = dict(os.environ, FSJ_SRC=str(LAUNCH_DIR), FSJ_DESKNAME=DESKTOP_NAME,
               FSJ_NAMES="|".join(LAUNCHERS))
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive",
                        "-Command", ps],
                       env=env, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or "").strip()[:80])
    return r.stdout.strip()


def _desktop_mac():
    dst = Path.home() / "Desktop" / DESKTOP_NAME
    dst.mkdir(parents=True, exist_ok=True)
    # zipやWindows経由で配ると実行権限が落ちてダブルクリックできない。
    # 「はじめに実行」も含め、この場で全部に付け直す。
    for f in LAUNCH_DIR.glob("*.command"):
        os.chmod(f, 0o755)
    for n in LAUNCHERS:
        target = LAUNCH_DIR / (n + ".command")
        if not target.exists():
            continue
        link = dst / (n + ".command")
        if link.is_symlink() or link.exists():
            link.unlink()
        os.symlink(target, link)
    return str(dst)


def chrome_running():
    try:
        urllib.request.urlopen("http://localhost:9223/json", timeout=3)
        return True
    except Exception:
        return False


def main():
    line("═")
    print("  セカンド自動送信 かんたんセットアップ")
    line("═")
    print()
    print("  質問に答えるだけで使える状態になります。")
    print("  分からない項目は、そのままEnterでも構いません。")
    print()

    # ── 0. 置き場所 ──
    # ここで気づかないと、設定を全部終えたあとに起動できないと分かる。
    try:
        import setup_check
        cloud = setup_check.in_cloud_folder(PROJECT_DIR)
    except Exception:
        cloud = None
    if cloud:
        print(f"  [!] このフォルダは {cloud} の中にあります。")
        print("      同期中にファイルを掴まれて起動できなくなることがあります。")
        print("      いったん閉じて「fsj-setup」を動かし、")
        print("      C:\\FSJセカンド自動送信 に入れ直してください。")
        print()
        if ask("  このまま続けますか？ (y/やり直す=Enter) > ").lower() not in ("y", "yes"):
            return 1
        print()

    # ── 0.5 接続情報 ──
    if not ensure_db_config():
        return 1

    # ── 1. 名前 ──
    cur = {}
    if CONFIG.exists():
        try:
            cur = json.loads(CONFIG.read_text(encoding="utf-8"))
        except Exception:
            cur = {}
    if cur.get("staff_key"):
        print(f"  すでに「{cur.get('display_name') or cur['staff_key']}」として"
              f"設定されています。")
        if ask("  設定し直しますか？ (y/そのままならEnter) > ").lower() not in ("y", "yes"):
            print("\n  設定はそのままにします。")
            return finish(cur)
        print()

    name = ""
    while not name:
        name = ask("  あなたのお名前を入力してください（例: 川上） > ")
    print()

    # ── 2. データベースへ登録 ──
    try:
        import line_pull as lp
        import second_sender as ss
        url, key = lp.load_config()
    except SystemExit:
        print("  [!] データベースの接続情報がありません。")
        print("      scripts/line_log.json を管理者から受け取って置いてください。")
        return 1
    except Exception as e:
        print(f"  [!] 準備でエラーが出ました: {e}")
        return 1

    try:
        rows = ss.api(url, key, "GET", "staff",
                      {"select": "staff_key,display_name"})
    except Exception as e:
        print(f"  [!] データベースに接続できません: {str(e)[:60]}")
        print("      ネットワークを確認してください。")
        return 1

    same = [r for r in rows if r.get("display_name") == name]
    if same:
        staff_key = same[0]["staff_key"]
        print(f"  「{name}」さんはすでに登録済みです。この設定を使います。")
    else:
        used = {r["staff_key"] for r in rows}
        i = 1
        while f"staff{i:02d}" in used:
            i += 1
        staff_key = f"staff{i:02d}"
        ss.api(url, key, "POST", "staff",
               body={"staff_key": staff_key, "display_name": name},
               prefer="return=minimal,resolution=ignore-duplicates")
        print(f"  「{name}」さんを登録しました。")

    # ★書き換えるのは名前だけ。既にある項目は消さない。
    #   丸ごと上書きすると、設定し直しただけで他の設定（テストモード等）が
    #   静かに消える。消えたことは画面に出ないので気づけない。
    cfg = dict(cur) if isinstance(cur, dict) else {}
    cfg["staff_key"] = staff_key
    cfg["display_name"] = name
    cfg.setdefault("_reaction_emoji",
                   "送信成功後に付けるリアクションID。付けない場合は null")
    cfg.setdefault("reaction_emoji", "1003")
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2),
                      encoding="utf-8")
    print(f"  この PC を「{name}」さんのPCとして設定しました。")
    print()

    return finish({"staff_key": staff_key, "display_name": name})


def finish(cfg):
    # ── 3. Chrome版LINE ──
    line()
    if chrome_running():
        print("  Chrome版LINE: 起動しています")
    else:
        print("  Chrome版LINEが起動していません。")
        print("  送信にはChrome版LINEが必要です。")
        if ask("  いま起動しますか？ (y/あとで=Enter) > ").lower() in ("y", "yes"):
            launcher = LAUNCH_DIR / ("LINE用Chrome起動" + LAUNCH_EXT)
            try:
                if sys.platform == "darwin":
                    subprocess.Popen(["open", str(launcher)], cwd=str(PROJECT_DIR))
                else:
                    subprocess.Popen(["cmd", "/c", "start", "", str(launcher)],
                                     cwd=str(PROJECT_DIR))
                print("  起動しました。LINEにログインしてから、この続きを見てください。")
            except Exception as e:
                print(f"  自動起動できませんでした: {e}")
                print("  「LINE用Chrome起動」を手で実行してください。")
    print()

    # ── 3.5 担当者マスタ ──
    # 配布物には入っていない（氏名とLINE IDのため）。毎回DBから取る。
    line()
    refresh_master()
    print()

    # ── 4. デスクトップにショートカット ──
    line()
    desk = make_desktop_folder()
    if desk:
        print(f"  デスクトップに「{DESKTOP_NAME}」フォルダを作りました。")
        print("  明日からは、ここを開くだけで使えます。")
    print()

    # ── 5. 診断 ──
    line()
    print("  最終確認をします...")
    print()
    try:
        import setup_check
        rc = setup_check.main()
    except Exception as e:
        print(f"  診断でエラー: {e}")
        rc = 1

    print()
    line("═")
    if rc == 0:
        print("  セットアップ完了です。")
        print()
        print("  【毎日の使い方】")
        print(f"   デスクトップの「{DESKTOP_NAME}」フォルダを開いて、")
        print("   1. 「セカンド自動送信_常駐起動」をダブルクリック（出勤時に1回）")
        print("   2. ダッシュボードで自分のトグルをONにする")
        print()
        print("   ※ トグルがOFFの間は何も送りません。開いたままで大丈夫です。")
    else:
        print("  あと少しです。上の[NG]項目を直してから、もう一度実行してください。")
    line("═")
    return rc


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n中断しました。")
