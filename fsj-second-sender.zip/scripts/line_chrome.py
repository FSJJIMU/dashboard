from __future__ import annotations
import json, logging, time, urllib.parse, urllib.request
from dataclasses import dataclass
import websocket

logger = logging.getLogger(__name__)
DEBUG_PORT = 9223
# 前回つながったLINEタブのURL。閉じられていたら開き直すのに使う。
_TAB_MEMO = __import__("pathlib").Path(__file__).resolve().parent / "line_tab.json"
STEP_SLEEP = 0.3
ENTER_SLEEP = 0.5

class LineSendError(RuntimeError):
    pass


def _line_targets(targets):
    """LINE拡張のページを拾う。

    ★titleの完全一致で見ない。
      未読があると "LINE (3)" のようにタブ名が変わることがあり、
      完全一致だと開いているのに「未検出」になる。
      URLが chrome-extension:// の時点で他のサイトは入らないので、
      titleに LINE が含まれていれば十分に絞れる。
    """
    return [t for t in targets
            if t.get("type") == "page"
            and t.get("url", "").startswith("chrome-extension://")
            and "LINE" in (t.get("title") or "")]


def _remember_tab(tab_url):
    """つながったLINEタブのURLを控える。閉じられたとき開き直すため。"""
    try:
        _TAB_MEMO.write_text(json.dumps({"url": tab_url}), encoding="utf-8")
    except Exception:
        pass


def _reopen_tab():
    """LINEタブが無いとき、前に控えたURLで開き直す。

    ★これが無いと、タブを閉じただけで送信が全部失敗する。
      実際に、Chromeは動いているのにLINEタブが無い状態で常駐していて、
      案件が来た瞬間に「拡張ターゲット未検出」で落ちた。
      「タブを閉じないでください」と頼むより、開き直す方が確実。

    Returns:
        bool: 開き直せたら True
    """
    try:
        tab_url = json.loads(_TAB_MEMO.read_text(encoding="utf-8")).get("url") or ""
    except Exception:
        return False
    if not tab_url.startswith("chrome-extension://"):
        return False
    try:
        # Chrome 111以降、新規タブは PUT でないと受け付けない
        req = urllib.request.Request(
            f"http://localhost:{DEBUG_PORT}/json/new?"
            + urllib.parse.quote(tab_url, safe=""), method="PUT")
        urllib.request.urlopen(req, timeout=5).read()
    except Exception as e:
        logger.debug(f"reopen failed: {e}")
        return False
    # 読み込みが終わってタイトルが付くまで待つ
    for _ in range(20):
        time.sleep(0.25)
        try:
            with urllib.request.urlopen(
                    f"http://localhost:{DEBUG_PORT}/json", timeout=5) as r:
                if _line_targets(json.loads(r.read())):
                    logger.info("LINEタブを開き直しました")
                    return True
        except Exception:
            pass
    return False

class _CDPClient:
    def __init__(self):
        self.ws = None
        self._next_id = 0
        try:
            with urllib.request.urlopen(f"http://localhost:{DEBUG_PORT}/json", timeout=5) as r:
                targets = json.loads(r.read())
        except Exception as e:
            raise LineSendError(f"CDP 到達不可 (port {DEBUG_PORT}): {e}") from e
        found = _line_targets(targets)
        if not found and _reopen_tab():
            with urllib.request.urlopen(f"http://localhost:{DEBUG_PORT}/json",
                                        timeout=5) as r:
                found = _line_targets(json.loads(r.read()))
        if not found:
            raise LineSendError("LINE Chrome 拡張ターゲット未検出")
        target = found[0]
        _remember_tab(target.get("url", ""))
        # Chrome 111以降、CDPのWebSocketは Origin ヘッダ付きの接続を拒否する
        # （--remote-allow-origins を付けて起動していない場合）。
        # suppress_origin=True で Origin を送らなければ、Chrome側の起動オプションに
        # 関係なく接続できる。
        self.ws = websocket.create_connection(target["webSocketDebuggerUrl"],
                                              suppress_origin=True)
        logger.debug(f"CDP connected: {target['id']}")

    def cmd(self, method, params=None):
        self._next_id += 1
        self.ws.send(json.dumps({"id":self._next_id,"method":method,"params":params or {}}))
        while True:
            r = json.loads(self.ws.recv())
            if r.get("id") == self._next_id:
                return r

    def ev(self, expr):
        r = self.cmd("Runtime.evaluate", {"expression": expr, "returnByValue": True})
        res = r.get("result", {})
        # ★JS側で例外が出たことを黙って捨てない。
        #   捨てると値がNoneで返り、呼び出し側は「見つからなかった」と解釈する。
        #   書き間違いやLINE側のDOM変更が「対象なし」に化けて、原因究明が
        #   何時間も遅れる（実際に遅れた）。
        exc = res.get("exceptionDetails")
        if exc:
            desc = ((exc.get("exception") or {}).get("description")
                    or exc.get("text") or "不明なJSエラー")
            logger.warning(f"ページ内のJSでエラー: {str(desc).splitlines()[0]}"
                           f" / 式: {expr[:80]}")
        return res.get("result", {}).get("value")

    def close(self):
        if self.ws:
            try: self.ws.close()
            except Exception: pass

def _until(cdp, expr, limit, step=0.05):
    """条件が満たされるまで待つ。固定待ちの置き換え用。

    ★上限は「置き換える前の固定待ちと同じ長さ」にする。
      そうすれば最悪でも今までと同じで、速くなることはあっても
      遅くなることはない。確認処理は一切減らさない。
    """
    end = time.perf_counter() + limit
    while time.perf_counter() < end:
        if cdp.ev(expr):
            return True
        time.sleep(step)
    return False


def _ensure_chats_mode(cdp):
    """friends モードなら chats モードに切替してトーク一覧をレンダさせる。

    グループルーム (案件紹介ROOM【東海B】等) は chats タブにのみ表示されるため、
    friends モードから切替が必要。既に chats モードなら no-op。

    ★検索窓に文字が残っていないかも見る。
      _friend_search は宛先の名前を入れたまま終わる（絞り込み結果を
      呼び出し側が読むため、その場では消せない）。放っておくと一覧が
      絞り込まれたまま次の案件に入り、ルームが候補に出てこず
      「未検出」で失敗する。実際に 9442671 がこれで落ちた
      （そのとき見えていたのは人名3件だけだった）。
      片付けは「一覧を使う側」でやる。使う直前に必ずここを通るため。
    """
    dirty = cdp.ev(
        '(() => {'
        '  const s = document.querySelector('
        '    \'input[class*="searchInput-module__input"]\');'
        '  if (!s || !s.value) return false;'
        '  const setter = Object.getOwnPropertyDescriptor('
        '    window.HTMLInputElement.prototype, "value").set;'
        '  setter.call(s, ""); s.dispatchEvent(new Event("input", {bubbles: true}));'
        '  return true;'
        '})()')

    cur_hash = cdp.ev("location.hash") or ""
    if cur_hash.startswith("#/chats/"):
        if dirty:
            # 絞り込みが解けて一覧が戻るまで待つ
            _until(cdp,
                   'document.querySelectorAll('
                   '  \'[class*="chatlistItem-module__chatlist_item"]\').length > 3',
                   1.0)
            logger.debug("cleared leftover search text (chats mode)")
        return
    cur_id = cur_hash.split("/")[-1] if "/" in cur_hash else ""
    if cur_id:
        cdp.ev(f'location.hash = "#/chats/{cur_id}"')
    else:
        cdp.ev('location.hash = "#/chats/"')
    # トーク一覧が描けた時点で先へ進む（従来は一律1秒待っていた）
    _until(cdp,
           'document.querySelectorAll('
           '  \'[class*="chatlistItem-module__chatlist_item"]\').length > 0', 1.0)
    logger.debug(f"switched to chats mode (was {cur_hash!r})")

def _navigate_to_room(cdp, room_name):
    """ルーム名から data-mid (room ID) を引いて location.hash を直接書き換える。

    1. **exact match のみ** で探索 (partial includes は禁止: "テスト〇〇"と"〇〇"
       のような共存ルームでテスト用に誤マッチする事故を防ぐ)。
    2. 現サイドバー描画範囲で見つからない場合、サイドバーをスクロールしながら
       全件走査 (LINE 拡張は virtualization で可視範囲のみ DOM 生成のため)。
    3. 見つかったら data-mid を取り、`location.hash = '#/chats/<id>'` で SPA
       ルーターに直接遷移 (item.click() は React synthetic event に届かない)。

    Returns:
        str | None: 取得した data-mid。
    """
    _ensure_chats_mode(cdp)

    # ルーム名抽出 + 比較ロジック:
    #   1. LINE Chrome 拡張は絵文字を <img alt="🌼"> として描画 → textContent には現れない。
    #      子ノードを walk して TEXT は値を、IMG は alt を取り出して組み立てる。
    #   2. 末尾の見えない文字 (Hangul Filler U+3164, NBSP, ZWJ, 全角空白等) を normalize で除去。
    #      LINE 側ルーム名にこれらが混入する事故 (e.g. 末尾 ㅤ) を吸収。
    js_find_exact = f'''
(() => {{
  const getName = (el) => {{
    if (!el) return '';
    let s = '';
    for (const n of el.childNodes) {{
      if (n.nodeType === 3) {{ s += n.nodeValue; }}
      else if (n.nodeType === 1) {{
        if (n.tagName === 'IMG') s += (n.getAttribute('alt') || '');
        else s += getName(n);
      }}
    }}
    return s;
  }};
  const norm = s => (s || '').replace(/[\\u00A0\\u1680\\u2000-\\u200D\\u202F\\u205F\\u3000\\u3164\\uFEFF\\s]+$/gu, '').trim();
  const target = norm({json.dumps(room_name)});
  const items = document.querySelectorAll('[class*="chatlistItem-module__chatlist_item"]');
  for (const item of items) {{
    const textEl = item.querySelector('[class*="chatlistItem-module__text"]');
    const raw = getName(textEl);
    const text = norm(raw);
    if (text === target) {{
      return {{found:true, mid: item.getAttribute('data-mid'), matched: raw.trim()}};
    }}
  }}
  return {{found:false}};
}})()
'''

    # まず現状の sidebar で exact 探索
    result = cdp.ev(js_find_exact)
    if result and result.get("found") and result.get("mid"):
        cdp.ev(f'location.hash = "#/chats/{result["mid"]}"')
        logger.debug(
            f"navigated (no scroll): '{result['matched']}' mid={result['mid']}"
        )
        # 直後に _verify_current_room がポーリングで確認するので待たない
        return result["mid"]

    # 見つからない → サイドバーをスクロールしながら走査
    logger.debug(f"sidebar scroll 開始 (target='{room_name}')")
    found_mid = _scroll_search_room(cdp, room_name, js_find_exact)
    if found_mid:
        cdp.ev(f'location.hash = "#/chats/{found_mid}"')
        logger.debug(f"navigated (with scroll): '{room_name}' mid={found_mid}")
        # 直後に _verify_current_room がポーリングで確認するので待たない
        return found_mid

    # 最終手段: 検索窓に room_name を打ち込んで sidebar を絞り込ませる
    # (LINE の sidebar は最近活動順で動的に並び替え、活動がない room は
    # 表示から外れることがある = scroll では救えない)
    logger.debug(f"検索窓経由 navigate 開始 (target='{room_name}')")
    found_mid = _search_via_searchbox(cdp, room_name, js_find_exact)
    if found_mid:
        cdp.ev(f'location.hash = "#/chats/{found_mid}"')
        logger.debug(f"navigated (via searchbox): '{room_name}' mid={found_mid}")
        # 直後に _verify_current_room がポーリングで確認するので待たない
        return found_mid

    # 全ルート失敗 → エラー
    samples = cdp.ev(
        '(() => { const items = document.querySelectorAll(\'[class*="chatlistItem-module__chatlist_item"]\'); return Array.from(items).slice(0, 10).map(i => { const t = i.querySelector(\'[class*="chatlistItem-module__text"]\'); return t ? t.textContent.trim() : "(no text)"; }); })()'
    ) or []
    raise LineSendError(
        f"ルーム '{room_name}' 未検出 (exact + scroll + searchbox 全て失敗、"
        f"現可視先頭10={samples})"
    )


def _search_via_searchbox(cdp, room_name, js_find_exact, timeout=2.5):
    """LINE 拡張の検索窓 (placeholder='トークルーム検索') に room_name を入力して
    sidebar を絞り込み、絞り込まれた中から exact match を探す。

    sidebar に表示すらされてない room (LINE の最近活動順並び替えでスクロール
    では到達不能) を navigate する最終手段。

    Returns:
        str | None: 見つかった mid、見つからなければ None
    """
    # 検索 input を focus (search activates → 結果表示用に sidebar が変わる)
    focused = cdp.ev(
        '(() => { const el = document.querySelector(\'input[class*="searchInput-module__input"]\'); if (!el) return false; el.focus(); el.click(); return document.activeElement === el; })()'
    )
    if not focused:
        return None

    # 既存入力クリア → room_name 入力
    _clear_input_via_kbd(cdp)
    cdp.cmd("Input.insertText", {"text": room_name})

    # 絞り込み描画待ち + 再 query
    deadline = time.perf_counter() + timeout
    found_mid = None
    while time.perf_counter() < deadline:
        time.sleep(0.15)
        result = cdp.ev(js_find_exact)
        if result and result.get("found") and result.get("mid"):
            found_mid = result["mid"]
            break

    # 副作用残さないため検索窓を clear + Escape で検索 mode 解除
    _clear_input_via_kbd(cdp)
    cdp.cmd(
        "Input.dispatchKeyEvent",
        {"type": "keyDown", "key": "Escape", "code": "Escape", "windowsVirtualKeyCode": 27},
    )
    cdp.cmd(
        "Input.dispatchKeyEvent",
        {"type": "keyUp", "key": "Escape", "code": "Escape", "windowsVirtualKeyCode": 27},
    )
    time.sleep(0.2)
    return found_mid


def _clear_input_via_kbd(cdp):
    """現フォーカス input を Ctrl+A + Delete で空にする。"""
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyDown","key":"a","code":"KeyA","windowsVirtualKeyCode":65,"modifiers":2})
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyUp","key":"a","code":"KeyA","windowsVirtualKeyCode":65,"modifiers":2})
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyDown","key":"Delete","code":"Delete","windowsVirtualKeyCode":46})
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyUp","key":"Delete","code":"Delete","windowsVirtualKeyCode":46})


def _scroll_search_room(cdp, room_name, js_find_exact, max_scroll_attempts=30):
    """サイドバーを上から下までスクロールしながら exact match を探す。

    LINE 拡張のサイドバーは virtualization で画面内要素のみ DOM 描画するため、
    target ルームがスクロールアウトしてると querySelectorAll で見つからない。
    `chatlist-module__chatlist_inner` の親 (scroll コンテナ) を scrollTop で
    動かして、各ステップで再 query する。

    Returns:
        str | None: 見つかった mid、見つからなければ None
    """
    # まず一旦最上部にスクロール
    cdp.ev(
        '(() => { const inner = document.querySelector(\'[class*="chatlist-module__chatlist_inner"]\'); if (inner && inner.parentElement) inner.parentElement.scrollTop = 0; return true; })()'
    )
    time.sleep(0.15)

    # スクロールコンテナの最大スクロール量を取得
    max_scroll = cdp.ev(
        '(() => { const inner = document.querySelector(\'[class*="chatlist-module__chatlist_inner"]\'); if (!inner || !inner.parentElement) return 0; const c = inner.parentElement; return Math.max(0, c.scrollHeight - c.clientHeight); })()'
    ) or 0

    if max_scroll == 0:
        # スクロール不要 (リスト全体が画面内) なのに見つからない = 存在しない
        return None

    # 各 step でビューポート分スクロール
    step = 400  # 行高 ~71px、6 行ずつ進む程度
    for i in range(max_scroll_attempts):
        scroll_pos = min(step * (i + 1), max_scroll)
        cdp.ev(
            f'(() => {{ const inner = document.querySelector(\'[class*="chatlist-module__chatlist_inner"]\'); if (inner && inner.parentElement) inner.parentElement.scrollTop = {scroll_pos}; return true; }})()'
        )
        time.sleep(0.15)  # virtualization 再レンダ待ち

        result = cdp.ev(js_find_exact)
        if result and result.get("found") and result.get("mid"):
            return result["mid"]

        if scroll_pos >= max_scroll:
            break  # 末端まで到達

    return None

def _verify_current_room(cdp, expected_room_name, expected_mid=None, timeout=3.0):
    """ヘッダー名 + (あれば) compose の所属 data-mid が期待値と一致するか確認。

    ヘッダーだけでなく textarea-ex 祖先の data-mid も検証することで、hash 変更後
    DOM に古い compose が残っている race condition を捕捉する。

    安全網構成:
      1. _navigate_to_room: sidebar のルーム行を正確に選択、data-mid 取得
      2. _verify_current_room (本関数): ヘッダー名 + compose ancestor data-mid 検証
      3. _type_and_send: paste 前に再度 compose data-mid を確認 + Enter 後 compose 空検証
    """
    deadline = time.perf_counter() + timeout
    last_header = None
    last_compose_mid = None
    # 末尾の不可視文字を除去する Python 側ヘルパー (JS 側の norm と同等)
    import re as _re
    _trailing_invisible = _re.compile(
        r"[   -‍  　ㅤ﻿\s]+$"
    )

    def _norm(s):
        if not s:
            return ""
        return _trailing_invisible.sub("", s).strip()

    expected_norm = _norm(expected_room_name)
    # ヘッダーも同様に img.alt を含めて name を抽出する
    header_js = (
        '(() => {'
        '  const getName = (el) => {'
        '    if (!el) return "";'
        '    let s = "";'
        '    for (const n of el.childNodes) {'
        '      if (n.nodeType === 3) { s += n.nodeValue; }'
        '      else if (n.nodeType === 1) {'
        '        if (n.tagName === "IMG") s += (n.getAttribute("alt") || "");'
        '        else s += getName(n);'
        '      }'
        '    }'
        '    return s;'
        '  };'
        '  const el = document.querySelector(\'strong[class*="chatroomHeader-module__name"]\');'
        '  return el ? getName(el).trim() : null;'
        '})()'
    )
    while time.perf_counter() < deadline:
        header = cdp.ev(header_js)
        compose_mid = cdp.ev(
            '(() => { let el = document.querySelector("textarea-ex"); while (el) { if (el.getAttribute && el.getAttribute("data-mid")) return el.getAttribute("data-mid"); el = el.parentElement; } return null; })()'
        )
        if header:
            last_header = header
        if compose_mid:
            last_compose_mid = compose_mid
        header_ok = _norm(header) == expected_norm
        mid_ok = expected_mid is None or compose_mid == expected_mid
        if header_ok and mid_ok:
            return header
        time.sleep(0.1)
    raise LineSendError(
        f"ルーム検証失敗: 期待='{expected_room_name}' (mid={expected_mid}) "
        f"実際 header='{last_header}' compose_mid='{last_compose_mid}' "
        f"(ヘッダー or compose data-mid が期待値と不一致、誤送信防止のため中断)"
    )


def _type_and_send(cdp, message, expected_mid=None):
    """compose にメッセージを paste して Enter 送信。

    expected_mid が指定されている場合、paste 直前にも compose の data-mid を再度確認し、
    想定外ルームなら LineSendError を raise (navigate verify 通過後の race 対策)。
    """
    # paste 直前の最終安全チェック: compose が期待ルーム内にあるか
    if expected_mid:
        compose_mid = cdp.ev(
            '(() => { let el = document.querySelector("textarea-ex"); while (el) { if (el.getAttribute && el.getAttribute("data-mid")) return el.getAttribute("data-mid"); el = el.parentElement; } return null; })()'
        )
        if compose_mid != expected_mid:
            raise LineSendError(
                f"paste 直前 compose data-mid 不一致: 期待={expected_mid!r} 実際={compose_mid!r} "
                f"(誤送信防止のため中断)"
            )

    active = cdp.ev('(()=>{const ta=document.querySelector("textarea-ex");if(!ta)return null;ta.click();ta.focus();return document.activeElement.tagName;})()')
    if active != "TEXTAREA-EX":
        raise LineSendError(f"compose フォーカス失敗: {active}")
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyDown","key":"a","code":"KeyA","windowsVirtualKeyCode":65,"modifiers":2})
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyUp","key":"a","code":"KeyA","windowsVirtualKeyCode":65,"modifiers":2})
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyDown","key":"Delete","code":"Delete","windowsVirtualKeyCode":46})
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyUp","key":"Delete","code":"Delete","windowsVirtualKeyCode":46})
    cdp.cmd("Input.insertText", {"text": message})
    # 文字が入った時点で先へ進む（従来は一律0.3秒待っていた）。
    # 「入ったこと」の確認は今まで通り必ず行う。
    _until(cdp, '!!(document.querySelector("textarea-ex")||{}).value', STEP_SLEEP + 0.1)
    val = cdp.ev('document.querySelector("textarea-ex").value')
    is_empty = (len(val)==0) if isinstance(val, list) else (not val)
    if is_empty:
        raise LineSendError(f"compose 値が入らず (value={val})")
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyDown","key":"Enter","code":"Enter","windowsVirtualKeyCode":13,"nativeVirtualKeyCode":13})
    cdp.cmd("Input.dispatchKeyEvent", {"type":"keyUp","key":"Enter","code":"Enter","windowsVirtualKeyCode":13,"nativeVirtualKeyCode":13})
    # 入力欄が空になった＝送信された。その瞬間に先へ進む（従来は一律0.5秒）。
    _until(cdp, '!(document.querySelector("textarea-ex")||{}).value', ENTER_SLEEP)
    val_after = cdp.ev('document.querySelector("textarea-ex").value')
    sent = (len(val_after)==0) if isinstance(val_after, list) else (not val_after)
    if not sent:
        raise LineSendError(f"送信検証失敗 (value_after={val_after})")

@dataclass
class SendContext:
    dry_run: bool = False
    verbose: bool = False
    offset_x: int | None = None
    offset_y: int | None = None
    compose_x: int | None = None
    compose_y: int | None = None

def _friend_search(cdp, person_name):
    """友だちタブの検索窓に名前を入れる。Reactが値の変更を検知できるよう
    ネイティブsetter経由で入れてからinputイベントを発火する。"""
    cdp.ev('location.hash="#/friends"')
    # 検索窓が現れた時点で先へ進む（従来は一律0.8秒待っていた）
    _until(cdp,
           '!!document.querySelector('
           '  \'input[class*="searchInput-module__input"]\')', 0.8)
    js = (
        '(() => {'
        '  const s = document.querySelector(\'input[class*="searchInput-module__input"]\');'
        '  if (!s) return "no-input";'
        '  const setter = Object.getOwnPropertyDescriptor('
        '    window.HTMLInputElement.prototype, "value").set;'
        '  setter.call(s, ""); s.dispatchEvent(new Event("input", {bubbles:true}));'
        '  setter.call(s, %s); s.dispatchEvent(new Event("input", {bubbles:true}));'
        '  return "ok";'
        '})()' % json.dumps(person_name)
    )
    if cdp.ev(js) != "ok":
        raise LineSendError("友だちタブの検索窓が見つかりません")
    # 絞り込み結果が出た時点で先へ進む（従来は一律1.2秒待っていた）。
    # 0件のまま時間切れになっても、呼び出し側が「見つかりません」で止める。
    _until(cdp,
           'document.querySelectorAll('
           '  \'[class*="friendlistItem-module__item"]\').length > 0', 1.2)


def sender_mid_of_message(cdp, room_name, message_id):
    """ルーム内の指定メッセージから、その送信者の内部IDを読み取る。

    ★これが最も確実な宛先特定。名前で探す必要も、事前の紐づけも要らない。
      グループのメッセージ要素には送信者の data-mid が入っており、
      data-message-select-id には LINE のメッセージIDが入っている。
      Webhookで受け取った message_id と突き合わせれば、
      「取得のリプライを送った本人」を一意に特定できる。

      同じ人が複数アカウントを持っていても、実際にリプライしたアカウントの
      IDがそのまま得られるので取り違えが起きない。

    戻り値: (送信者の内部ID, 画面上の表記)
    """
    _ensure_chats_mode(cdp)
    _navigate_with_verify(cdp, room_name)
    # 対象メッセージが描けた時点で先へ進む（従来は一律0.8秒待っていた）。
    # 出なくても下の探索が "not-found" を返すので、判定は変わらない。
    _until(cdp,
           '(() => Array.from(document.querySelectorAll('
           '  "[data-message-select-id]")).some(e =>'
           '  (e.getAttribute("data-message-select-id")||"")'
           '    .endsWith("-" + %s)))()' % json.dumps(str(message_id)), 0.8)
    found = cdp.ev(
        '(() => {'
        '  const q = %s;'
        '  for (const e of document.querySelectorAll("[data-message-select-id]")) {'
        '    const sel = e.getAttribute("data-message-select-id") || "";'
        '    if (!sel.endsWith("-" + q)) continue;'
        '    const mid = e.getAttribute("data-mid");'
        '    if (!mid) continue;'
        '    return JSON.stringify({mid: mid,'
        '      pre: e.getAttribute("data-message-content-prefix") || ""});'
        '  }'
        '  return null;'
        '})()' % json.dumps(str(message_id)))
    if not found:
        raise LineSendError(
            f"ルーム '{room_name}' にメッセージ {message_id} が見つかりません"
            f"（画面に読み込まれていない可能性）")
    d = json.loads(found)
    return d["mid"], d.get("pre", "").strip()


def _find_reaction(cdp, emoji):
    """リアクションの一覧から目的の絵文字を探す。

    戻り値: (位置 or None, いま表示されている絵文字IDの一覧)
    IDも返すのは、見つからなかったときに「まだ描画されていない」のか
    「このアカウントには無い」のかを切り分けるため。
    """
    r = cdp.ev(
        '(() => {'
        '  const want = %s, ids = []; let hit = null;'
        '  for (const e of document.querySelectorAll('
        '      \'[class*="reactionPopover"] img\')) {'
        '    const m = (e.src || "").match(/con_button_(\\d+)\\./);'
        '    if (!m) continue;'
        '    const b = e.getBoundingClientRect();'
        '    if (!b.width) continue;'
        '    ids.push(m[1]);'
        '    if (m[1] === want) hit = {x: b.left + b.width / 2,'
        '                              y: b.top + b.height / 2, src: m[0]};'
        '  }'
        '  return JSON.stringify({hit: hit, ids: ids});'
        '})()' % json.dumps(str(emoji)))
    try:
        d = json.loads(r) if r else {}
    except Exception:
        d = {}
    return d.get("hit"), d.get("ids") or []


def add_reaction(cdp, room_name, message_id, emoji="1003", navigate=True):
    """ルーム内の指定メッセージにリアクションを付ける。

    セカンドを送り終えた印として、取得リプライにマークを残す用途。
    事務員が目視で「対応済み」を判別できるようにする。

    ホバーで出るボタンはCDPの合成マウス移動では反応しないため、
    DOM上のボタンを直接クリックしてポップオーバーを開く。

    emoji: LINEのリアクションID（1001〜1006）。並び順ではなくIDで指定するので、
           ポップオーバーの並びが変わっても選ぶ絵文字は変わらない。
    """
    if navigate:
        _ensure_chats_mode(cdp)
        _navigate_with_verify(cdp, room_name)
        # 対象メッセージが描けた時点で先へ進む（従来は一律0.6秒待っていた）
        _until(cdp,
               '(() => Array.from(document.querySelectorAll('
               '  "[data-message-select-id]")).some(e =>'
               '  (e.getAttribute("data-message-select-id")||"")'
               '    .endsWith("-" + %s)))()' % json.dumps(str(message_id)), 0.6)

    opened = cdp.ev(
        '(() => {'
        '  const q = %s;'
        '  for (const e of document.querySelectorAll("[data-message-select-id]")) {'
        '    const sel = e.getAttribute("data-message-select-id") || "";'
        '    if (!sel.endsWith("-" + q)) continue;'
        '    const b = e.querySelector(\'[class*="button_popover"]\');'
        '    if (!b) return "no-button";'
        '    b.dispatchEvent(new MouseEvent("mouseover", {bubbles: true}));'
        '    b.click();'
        '    return "ok";'
        '  }'
        '  return "no-message";'
        '})()' % json.dumps(str(message_id)))
    if opened != "ok":
        raise LineSendError(f"リアクションを付けられません（{opened}）")
    # この直後に「絵文字が出るまで待つ」処理があるので、ここで待つ必要はない。
    # 従来は0.8秒待ってから待ち直しており、まるまる無駄だった。

    # ★描画待ちは固定秒にしない。
    #   ポップオーバーの表示はPCの速さや負荷でぶれるため、固定待ちだと
    #   「まだ出ていないだけ」を「選択肢に無い」と取り違える。
    #   出るまで待ち、それでも無ければ“実際に出ている絵文字”を添えて報告する。
    #   （原因が「描画が遅い」のか「このアカウントの絵文字が違う」のか、
    #     ログだけで区別できるようにするため）
    p, ids, seen = None, [], 0
    for _ in range(80):                       # 最大約4秒（上限は据え置き）
        time.sleep(0.05)                      # 見に行く間隔だけ細かくした
        p, ids = _find_reaction(cdp, emoji)
        if p:
            break
        if ids:
            seen += 1
            if seen >= 20:                    # 一覧は出ているのに目的の物が無い
                break
    if not p:
        cdp.cmd("Input.dispatchKeyEvent", {"type": "keyDown", "key": "Escape",
                                           "windowsVirtualKeyCode": 27})
        if ids:
            raise LineSendError(
                f"リアクション {emoji} がこのアカウントの選択肢にありません"
                f"（出ているのは {', '.join(ids)}）")
        raise LineSendError("リアクションの選択肢が開きませんでした（描画待ち切れ）")

    # ★まずJSのclickで押す。
    #   座標クリックはLINEの窓が他の窓に隠れていると効かない
    #   （Chromeが描画を止めるため）。押せたかどうかは、
    #   ポップオーバーが閉じたかで判断する。
    clicked = cdp.ev(
        '(() => {'
        '  const want = %s;'
        '  for (const e of document.querySelectorAll('
        '      \'[class*="reactionPopover"] img\')) {'
        '    const m = (e.src || "").match(/con_button_(\\d+)\\./);'
        '    if (!m || m[1] !== want) continue;'
        '    const t = e.closest("button") || e.parentElement || e;'
        '    t.click();'
        '    return true;'
        '  }'
        '  return false;'
        '})()' % json.dumps(str(emoji)))
    # 選択肢が閉じた＝押せた。その瞬間に先へ進む（従来は一律0.8秒）
    for _ in range(16):
        if _popover_closed(cdp):
            break
        time.sleep(0.05)

    if not _popover_closed(cdp):
        # JSのclickで閉じないUIのときだけ、座標クリックに落とす
        logger.debug("JSのclickで閉じないため座標クリックに切り替えます")
        for ev_type, extra in (("mouseMoved", {}),
                               ("mousePressed", {"buttons": 1}),
                               ("mouseReleased", {"buttons": 0})):
            cdp.cmd("Input.dispatchMouseEvent",
                    dict({"type": ev_type, "x": p["x"], "y": p["y"],
                          "button": "left", "clickCount": 1}, **extra))
            time.sleep(0.12)
        for _ in range(16):
            if _popover_closed(cdp):
                break
            time.sleep(0.05)

    logger.debug(f"reaction added: msg={message_id} emoji={p.get('src')} "
                 f"js={clicked}")
    return p.get("src", "")


def _popover_closed(cdp):
    """リアクションの選択肢が閉じたか。押せたことの確認に使う。"""
    return not cdp.ev(
        '(() => Array.from(document.querySelectorAll('
        '  \'[class*="reactionPopover"] img\'))'
        '  .some(e => e.getBoundingClientRect().width > 0))()')


def _wait_chat(cdp, expect_mid, limit=8.0):
    """狙ったトークが開くまで待つ。戻り値: (開いたmid, 表示名)

    ★固定秒待ちにしない。
      画面切り替えが間に合っていないと、前に開いていたトークを読んでしまう。
      送信先の確認に使う値なので、ここがずれると「別人に送る」か
      「開けたのに失敗扱いにする」のどちらかになる。
    """
    end = time.perf_counter() + limit
    opened = name = None
    while time.perf_counter() < end:
        opened, name = current_chat(cdp)
        if opened == expect_mid:
            return opened, name
        time.sleep(0.3)
    return opened, name


def _press_talk_button(cdp):
    """プロフィール画面の「トーク」を押して1対1トークを始める。

    ★押し方を3段階にする。人の操作を邪魔しない順に試す。
      1. JSの click()  … 描画が止まっていても効く。窓は前面に出ない
      2. 前面に出してから座標クリック … 1で駄目なReactコンポーネント向け
      3. あきらめる
      以前は座標クリックだけだったため、LINEの窓が他の窓に隠れていると
      Chromeが描画を止めていて押せず、事務員に「前面に出してください」と
      頼むしかなかった。

    一覧の各行にも aria-label="Go chatroom" のボタンが隠れており、そちらを
    押しても開かない。幅が広い（行いっぱい）ので大きさで見分ける。
    """
    find = (
        '(() => {'
        '  const vis = Array.from(document.querySelectorAll("button"))'
        '    .filter(x => x.getBoundingClientRect().width > 0);'
        '  return vis.find(x => (x.innerText || "").trim() === "トーク")'
        '    || vis.find(x => x.getAttribute("aria-label") === "Go chatroom"'
        '                  && x.getBoundingClientRect().width < 200) || null;'
        '})()')

    # 1) JSのclick。描画が止まっていても届く
    if cdp.ev('(() => { const b = %s; if (!b) return false;'
              '  b.click(); return true; })()' % find):
        # 入力欄が出た時点で先へ進む（従来は一律1.0秒待っていた）
        if _until(cdp, 'document.querySelectorAll("textarea-ex").length', 1.0):
            return True
    else:
        return False

    # 2) 前面に出してから座標クリック。ここに来るのは滅多にない
    logger.debug("JSのclickで開かないため、窓を前面に出して押し直します")
    try:
        cdp.cmd("Page.bringToFront", {})
        time.sleep(0.6)
    except Exception as e:
        logger.debug(f"前面化できません: {e}")

    box = cdp.ev(
        '(() => { const b = %s; if (!b) return null;'
        '  const r = b.getBoundingClientRect();'
        '  return JSON.stringify({x: r.left + r.width/2, y: r.top + r.height/2});'
        '})()' % find)
    if not box:
        return False
    q = json.loads(box)
    for ev_type, extra in (("mouseMoved", {}),
                           ("mousePressed", {"buttons": 1}),
                           ("mouseReleased", {"buttons": 0})):
        cdp.cmd("Input.dispatchMouseEvent",
                dict({"type": ev_type, "x": q["x"], "y": q["y"],
                      "button": "left", "clickCount": 1}, **extra))
        time.sleep(0.15)
    return True


def friend_mid(cdp, name):
    """友だち一覧から名前を引いて内部IDを返す。0件・複数なら中断。

    ★座標クリックはしない。
      一覧の要素に data-mid が載っているので、そこから読む。
      LINEの窓が他の窓に隠れているとChromeが描画を止め、合成クリックが
      処理されない。実際に「'FSJ事務bot' を開けませんでした」で何度も落ちた。

    ★完全一致を優先する。
      LINEの検索は前方一致なので「FSJ事務bot」で「FSJ事務bot2」まで出る。
      同名が2件あるときは exact も2件になり、下の中断に落ちる。
    """
    _friend_search(cdp, name)
    raw = cdp.ev(
        '(() => JSON.stringify(Array.from(document.querySelectorAll('
        '  \'[class*="friendlistItem-module__item"]\')).map(e => {'
        '  const t = e.querySelector(\'[class*="friendlistItem-module__text"]\');'
        '  return {name: t ? t.textContent.trim() : "",'
        '          mid: e.getAttribute("data-mid") || ""};'
        '}).filter(x => x.mid)))()')
    cands = json.loads(raw) if raw else []
    if not cands:
        raise LineSendError(f"友だちに '{name}' が見つかりません")

    exact = [c for c in cands if c["name"] == name]
    if len(exact) == 1:
        return exact[0]["mid"]
    if len(cands) == 1:
        return cands[0]["mid"]
    raise LineSendError(
        f"'{name}' の候補が{len(cands)}件あります"
        f"（{[c['name'] for c in cands[:5]]}）。誤送信防止のため中断しました")


def open_friend_mid(cdp, mid, label=""):
    """内部IDで1対1トークを開く。戻り値: 実際に開いたmid

    URLで直接開くので、窓が見えていなくても確実に動く。
    まだ一度も会話していない相手はプロフィール画面が開くため、
    そのときだけ「トーク」ボタンを押す。
    """
    cdp.ev(f'location.hash={json.dumps("#/friends/" + mid)}')

    def _wait_compose(limit):
        end = time.perf_counter() + limit
        while time.perf_counter() < end:
            if cdp.ev('document.querySelectorAll("textarea-ex").length'):
                return True
            time.sleep(0.3)
        return False

    if not _wait_compose(3.0):
        logger.debug(f"プロフィール画面のため「トーク」を押します: {label!r}")
        if not _press_talk_button(cdp):
            raise LineSendError(f"'{label}' の「トーク」ボタンが見つかりません")
        if not _wait_compose(8.0):
            raise LineSendError(f"'{label}' の入力欄が出ません")

    opened = cdp.ev(
        '(() => { let el = document.querySelector("textarea-ex");'
        '  while (el) { if (el.getAttribute && el.getAttribute("data-mid"))'
        '    return el.getAttribute("data-mid"); el = el.parentElement; }'
        '  return null; })()')
    if opened and opened != mid:
        raise LineSendError(
            f"'{label}' とは違うトークが開いています（期待={mid} 実際={opened}）")
    logger.debug(f"friend opened: {label!r} mid={opened}")
    return opened


def _navigate_to_friend(cdp, person_name):
    """友だちタブから相手の1対1トークを開く。

    トーク一覧に無い相手（まだ一度も会話していないプレイヤー）にも送れるよう、
    トーク検索ではなく友だち一覧から開く。グループ名と一致して誤ってグループへ
    送ってしまう事故も、この経路なら構造的に起こらない。
    """
    return open_friend_mid(cdp, friend_mid(cdp, person_name), person_name)


def current_chat(cdp=None):
    """いまChrome版LINEで開いているトークの (内部ID, 表示名) を返す。

    事務員が「正しい相手」を自分の目で開いた状態で紐づけを行うために使う。
    名前で相手を探すのではなく、人が確認した相手のIDを控えるのが目的。
    """
    own = cdp is None
    cdp = cdp or _CDPClient()
    try:
        mid = cdp.ev(
            '(() => { let el = document.querySelector("textarea-ex");'
            '  while (el) { if (el.getAttribute && el.getAttribute("data-mid"))'
            '    return el.getAttribute("data-mid"); el = el.parentElement; }'
            '  return null; })()')
        name = cdp.ev(
            '(() => { const h = document.querySelector('
            '  \'[class*="chatHeader"] [class*="name"], [class*="header"] [class*="name"]\');'
            '  return h ? h.innerText.trim().split("\\n")[0] : null; })()')
        return mid, name
    finally:
        if own:
            cdp.close()


def send_to_person_by_mid(line_mid, message, expect_name=None, ctx=None):
    """内部ID（line_mid）を直接指定して1対1トークに送る。

    名前で探さないので、同姓の知人や本人の2つ目のアカウントと取り違えない。
    送信先の決定に名前は一切使わず、expect_name は記録との食い違いを
    知らせるための参考情報としてしか見ない。
    """
    ctx = ctx or SendContext()
    if not line_mid:
        raise ValueError("line_mid が空")
    if not message:
        raise ValueError("message が空")
    if ctx.dry_run:
        logger.debug(f"[DRY] mid={line_mid} <- {message[:60]!r}")
        return
    cdp = _CDPClient()
    try:
        cdp.ev(f'location.hash={json.dumps("#/friends/" + line_mid)}')
        opened, name = _wait_chat(cdp, line_mid)
        if opened != line_mid:
            raise LineSendError(
                f"指定したトークを開けませんでした（期待={line_mid} 実際={opened}）")
        if expect_name and name and expect_name != name:
            logger.warning(f"表示名が記録と違います: 記録={expect_name!r} 画面={name!r}")
        _type_and_send(cdp, message, expected_mid=line_mid)
        logger.debug(f"sent mid={line_mid} name={name!r} chars={len(message)}")
    finally:
        cdp.close()


def send_reply_sender(room_name, message_id, message, ctx=None, react_emoji=None):
    """取得のリプライを送った本人の1対1トークにメッセージを送る。

    ルーム内の該当メッセージから送信者の内部IDを読み取り、そのトークを開いて送る。
    名前で探さないため、同姓の知人や本人の2つ目のアカウントと取り違えない。
    事前の紐づけも不要で、どの事務員のPCでもそのまま動く。

    react_emoji を指定すると、**送信が成功したあとで**取得リプライに
    リアクションを付ける。届いた印になるので、リアクションが無い＝未送信として
    事務員が目視で漏れを見つけられる。
    リアクションに失敗しても送信自体は成功しているので、例外にはしない。
    """
    ctx = ctx or SendContext()
    if not message:
        raise ValueError("message が空")
    cdp = _CDPClient()
    try:
        mid, shown = sender_mid_of_message(cdp, room_name, message_id)
        if ctx.dry_run:
            logger.info(f"[DRY] {shown} (mid={mid[:16]}…) <- {message[:40]!r}")
            return mid, shown
        cdp.ev(f'location.hash={json.dumps("#/friends/" + mid)}')
        opened, name = _wait_chat(cdp, mid)
        if opened != mid:
            raise LineSendError(
                f"送信者のトークを開けませんでした（期待={mid} 実際={opened}）")
        _type_and_send(cdp, message, expected_mid=mid)
        logger.debug(f"sent to sender of {message_id}: {name!r} mid={mid}")

        if react_emoji:
            try:
                add_reaction(cdp, room_name, message_id, react_emoji)
                logger.debug(f"reaction marked: {message_id}")
            except Exception as e:
                logger.warning(f"送信は成功しましたが、リアクションを付けられませんでした: {e}")
        return mid, name
    finally:
        cdp.close()


def send_reply_sender_test(room_name, message_id, message,
                           redirect_to, report_room, report_prefix,
                           react_emoji="1003"):
    """テストモードの送信。実際のプレイヤーには送らない。

    本番と同じ手順で取得者を特定したうえで、セカンド本文は redirect_to
    （MSRのもう一つのアカウント等）に送る。リアクションは**付けず**、
    付けられる状態かどうかだけ確認する。最後に report_room へ結果を書く。

    検証したいのは「誰の取得か正しく特定できるか」なので、その部分は
    本番とまったく同じ経路を通す。

    戻り値: dict（取得者名・リアクション可否）
    """
    cdp = _CDPClient()
    try:
        # ① 本番と同じ手順で取得者を特定する
        mid, shown = sender_mid_of_message(cdp, room_name, message_id)

        # ② リアクションを付けられる状態か確認する（付けはしない）
        can_react = bool(cdp.ev(
            '(() => {'
            '  const q = %s;'
            '  for (const e of document.querySelectorAll("[data-message-select-id]")) {'
            '    const sel = e.getAttribute("data-message-select-id") || "";'
            '    if (sel.endsWith("-" + q))'
            '      return !!e.querySelector(\'[class*="button_popover"]\');'
            '  }'
            '  return false;'
            '})()' % json.dumps(str(message_id))))

        # ③ セカンド本文は転送先へ送る（プレイヤーには送らない）
        #    本番と同じ経路（data-mid → URLで直接開く）を使う。
        #    ここだけ座標クリックにしていたため、LINEの窓が隠れていると
        #    「'FSJ事務bot' を開けませんでした」で落ちていた。
        target_mid = open_friend_mid(cdp, friend_mid(cdp, redirect_to), redirect_to)
        _type_and_send(cdp, message, expected_mid=target_mid)
        logger.debug(f"[TEST] second sent to {redirect_to!r} instead of {shown!r}")

        # ④ 結果をテスト用ルームへ報告する。
        #    会話履歴の無いルームはトーク一覧に出ないので、
        #    見つからなければ友だち／グループのタブから開く。
        try:
            _ensure_chats_mode(cdp)
            rmid = _navigate_with_verify(cdp, report_room)
        except LineSendError:
            logger.debug(f"トーク一覧に無いため友だちタブから開きます: {report_room!r}")
            rmid = open_friend_mid(cdp, friend_mid(cdp, report_room), report_room)
        _type_and_send(cdp,
                       f"{report_prefix}\n"
                       f"本来の送信先: {shown}\n"
                       f"リアクション: {'付与可能（テストのため未付与）' if can_react else '付与できません'}",
                       expected_mid=rmid)
        return {"sender": shown, "mid": mid, "can_react": can_react}
    finally:
        cdp.close()


def send_to_person(person_name, message, ctx=None):
    """個人（プレイヤー）の1対1トークにメッセージを送る。

    グループ宛ての send_to_room とは経路を分けている。
    同名のグループが存在しても、そちらへ送ってしまうことはない。
    """
    ctx = ctx or SendContext()
    if not person_name:
        raise ValueError("person_name が空")
    if not message:
        raise ValueError("message が空")
    if ctx.dry_run:
        logger.debug(f"[DRY] {person_name!r} <- {message[:60]!r}")
        return
    cdp = _CDPClient()
    try:
        mid = _navigate_to_friend(cdp, person_name)
        _type_and_send(cdp, message, expected_mid=mid)
        logger.debug(f"sent person={person_name!r} chars={len(message)} mid={mid}")
    finally:
        cdp.close()


def send_to_room(room_name, message, ctx=None):
    ctx = ctx or SendContext()
    if not room_name: raise ValueError("room_name が空")
    if not message: raise ValueError("message が空")
    if ctx.dry_run:
        logger.debug(f"[DRY] {room_name!r} <- {message[:60]!r}")
        return
    cdp = _CDPClient()
    try:
        expected_mid = _navigate_with_verify(cdp, room_name)
        _type_and_send(cdp, message, expected_mid=expected_mid)
        logger.debug(f"sent room={room_name!r} chars={len(message)} mid={expected_mid}")
    finally:
        cdp.close()


def _navigate_with_verify(cdp, room_name, max_attempts=3):
    """navigate + verify を最大 max_attempts 回まで試行。成功時に expected_mid を返す。

    LINE Chrome 拡張の UI は race condition (ルーム切替直後 DOM に旧/新両方の
    要素が一時共存する等) で別ルーム扱いになるケースがあり得るため、
    ヘッダー検証 + compose data-mid 検証の失敗を検知したら同じ navigate から
    やり直して復旧を試みる。
    """
    last_err = None
    for attempt in range(max_attempts):
        try:
            expected_mid = _navigate_to_room(cdp, room_name)
            _verify_current_room(
                cdp, room_name, expected_mid=expected_mid, timeout=2.0
            )
            if attempt > 0:
                logger.info(f"navigate 成功 (試行 {attempt + 1}/{max_attempts})")
            return expected_mid
        except LineSendError as e:
            last_err = e
            if attempt < max_attempts - 1:
                logger.warning(
                    f"navigate/verify 失敗 {attempt + 1}/{max_attempts}、再試行: "
                    f"{str(e)[:120]}"
                )
                time.sleep(0.8)
            else:
                raise LineSendError(
                    f"navigate 最大試行超過 ({max_attempts}回): {last_err}"
                )

if __name__ == "__main__":
    import argparse
    from datetime import datetime
    ap = argparse.ArgumentParser()
    ap.add_argument("--room", required=True)
    ap.add_argument("--message", default=None)
    args = ap.parse_args()
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    msg = args.message or f"line_chrome.py test {datetime.now():%H:%M:%S}"
    send_to_room(args.room, msg)
    print("送信成功")