#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""resident.py — 出勤時に開くもの。送信を始めるまでに必要なことを全部やる。

  1. 新しい版があれば取り込む
  2. LINE用のChromeが動いていなければ起動する
  3. 接続を確かめる
  4. 送信クライアントを動かし続ける

★中身をここ（Python）に置いてあるのが要点。
  起動用ファイル（.bat / .command）を書き換えると、事務員に
  「fsj-setup をやり直してください」とお願いすることになる。
  Pythonは自動更新で入れ替わるので、ここに置いておけば
  **常駐起動をダブルクリックするだけ**で最新になる。

  なぜ起動用ファイルを自動更新できないのか（実測）:
    実行中の .bat を差し替えると、cmd は読み位置がずれて途中で止まる
    （DONE を出さずに終了することを確認済み）。
    Python は丸ごと読んでから動くので、差し替えても最後まで正しく動く。
"""

import subprocess
import sys
import time
import urllib.request
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

PORT = 9223
RESTART_WAIT = 10       # 送信クライアントが落ちたとき、次に立ち上げるまで


def py():
    """子プロセスを動かすPython。いま自分を動かしているものをそのまま使う。"""
    return sys.executable


def run(script, *args):
    return subprocess.call([py(), "-X", "utf8", str(SCRIPT_DIR / script), *args])


def chrome_up():
    try:
        urllib.request.urlopen(f"http://localhost:{PORT}/json", timeout=2).read()
        return True
    except Exception:
        return False


def ensure_chrome():
    """LINE用のChromeが動いていなければ起動して、繋がるまで待つ。"""
    if chrome_up():
        return True
    import line_chrome_check as lcc
    print("LINE用のChromeを起動しています...")
    if not lcc.launch_chrome():
        return False
    for _ in range(20):
        time.sleep(1)
        if chrome_up():
            return True
    print("[!] Chromeは起動しましたが、ポート9223に繋がりません。")
    print("    Chromeをすべて終了してから、もう一度お試しください。")
    return False


def main():
    # ── 1. 更新 ──
    # ★起動用ファイルの更新もここで済ませる。実行中の1つだけは
    #   差し替えられないので、それは self_update 側で除外している。
    try:
        import self_update
        self_update.main()
    except Exception as e:
        print(f"[情報] 更新を確認できませんでした（{str(e)[:60]}）。今の版で動きます。")

    # ── 2. Chrome ──
    print()
    ensure_chrome()

    # ── 3. 接続確認 ──
    run("line_chrome_check.py")

    # ── 4. 送信クライアント ──
    # ★別プロセスで動かす。落ちてもここは生き残るので、
    #   立ち上げ直せる。更新後の新しい中身も毎回読み直される。
    run("second_sender_banner.py")
    # ★すぐ終わるのが続いたら止める。
    #   設定が足りない等でクライアントが即終了する場合、
    #   黙って10秒ごとに同じエラーを出し続けることになる。
    #   何回か続いたら諦めて、原因を調べる方へ案内する。
    quick = 0
    while True:
        started = time.time()
        run("second_sender.py", "--live")
        quick = quick + 1 if time.time() - started < 15 else 0
        if quick >= 5:
            print()
            print("=" * 58)
            print("  送信クライアントがすぐ終了してしまいます。")
            print("  原因を調べます...")
            print("=" * 58)
            run("setup_check.py")
            return 1
        print()
        print(f"[{RESTART_WAIT}秒後に再起動します]  終了するには Ctrl+C")
        time.sleep(RESTART_WAIT)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n終了しました。")
