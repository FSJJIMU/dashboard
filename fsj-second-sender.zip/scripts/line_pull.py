#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""line_pull.py — LINE-LOG(Supabase)から従来形式のLINEエクスポートtxtを生成する。

`LINE一括エクスポート.bat`（物理マウス操作・管理者昇格・PC占有）の代替。
Webhookで常時収集済みのデータをダウンロードしてtxtに整形するだけなので数秒で終わる。

出力は従来と同じ `LINEエクスポートtxt/run_YYYYMMDD_HHMMSS/[LINE]<ルーム名>.txt` なので、
fsj_core / horyu_kakutei_check / line_enrich / seisa 等は**無改修**で読める。

使い方:
    python -X utf8 line_pull.py              # 前回run_を引き継いで新着分を追記（通常運用）
    python -X utf8 line_pull.py --fresh      # DB内容だけで生成（本物エクスポートとの照合用）
    python -X utf8 line_pull.py --dry-run    # 書き込まずに件数だけ表示

接続情報は環境変数か scripts/line_log.json から読む:
    {"url": "https://xxxx.supabase.co", "service_key": "eyJ..."}
"""

import argparse
import json
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
EXPORT_ROOT = PROJECT_DIR / "LINEエクスポートtxt"
CONFIG_PATH = SCRIPT_DIR / "line_log.json"

JST = timezone(timedelta(hours=9))
WEEKDAYS = ["月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日", "日曜日"]

# 非テキストメッセージのプレースホルダ（本物のエクスポートの表記に合わせる）
MEDIA_LABEL = {
    "image": "画像",
    "video": "動画",
    "audio": "音声",
    "sticker": "スタンプ",
    "file": "ファイル",
    "location": "位置情報",
}

PAGE = 1000  # SupabaseのDataAPIは暗黙で1000件上限。必ず明示してページングする


# ══════════════════════════════════════════════════════════
#  接続
# ══════════════════════════════════════════════════════════

def load_config():
    url = os.environ.get("SUPABASE_LINE_URL")
    key = os.environ.get("SUPABASE_LINE_KEY")
    if url and key:
        return url.rstrip("/"), key
    if CONFIG_PATH.exists():
        cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        url = (cfg.get("url") or "").rstrip("/")
        key = cfg.get("service_key") or cfg.get("key") or ""
        if url and key:
            return url, key
    sys.exit(
        f"接続情報がありません。{CONFIG_PATH} を作って以下を書いてください:\n"
        '{\n  "url": "https://<プロジェクトref>.supabase.co",\n'
        '  "service_key": "<Project Settings → API Keys の service_role キー>"\n}\n'
    )


def rest(base_url, key, table, params):
    url = f"{base_url}/rest/v1/{table}?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=120) as res:
            return json.loads(res.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        sys.exit(f"取得失敗 {table}: HTTP {e.code} {e.read().decode('utf-8', 'ignore')[:300]}")


def fetch_all(base_url, key, table, select, order_col="id"):
    """キーセットページングで全件取得する（暗黙1000件上限の回避）。"""
    rows, last = [], None
    while True:
        params = {"select": select, "order": f"{order_col}.asc", "limit": PAGE}
        if last is not None:
            params[order_col] = f"gt.{last}"
        page = rest(base_url, key, table, params)
        if not page:
            break
        rows.extend(page)
        last = page[-1][order_col]
        if len(page) < PAGE:
            break
    return rows


# ══════════════════════════════════════════════════════════
#  整形
# ══════════════════════════════════════════════════════════

def parse_ts(s):
    """PostgRESTのtimestamptz文字列 → JSTのdatetime。

    ★小数点以下の桁数をそろえてから渡す。
      Python 3.11未満の fromisoformat は「3桁か6桁ちょうど」しか受け付けない。
      PostgreSQL は末尾の0を落とすので '.510' が '.51' になって返ることがあり、
      そのまま渡すと Invalid isoformat string で落ちる。
      実際に事務員のMac（古いPython）で2秒ごとにこのエラーが出て、
      送信がまったく進まなくなった。10件に1件くらいの割合で当たるため、
      「たまに動かない」という分かりにくい壊れ方をする。
    """
    s = s.strip().replace("Z", "+00:00")
    if re.search(r"[+-]\d{2}$", s):  # '+00' のような2桁オフセット対策
        s += ":00"
    m = re.search(r"\.(\d+)", s)
    if m:                            # 多ければ切り、少なければ0で埋めて6桁に
        s = s[:m.start()] + "." + (m.group(1) + "000000")[:6] + s[m.end():]
    return datetime.fromisoformat(s).astimezone(JST)


_NAME_MAP = None


def name_map():
    """プロフィール名 → 従来txtでの送信者表記（build_name_map.py が生成）。"""
    global _NAME_MAP
    if _NAME_MAP is None:
        p = SCRIPT_DIR / "line_name_map.json"
        try:
            _NAME_MAP = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            _NAME_MAP = {}
    return _NAME_MAP


def sender_label(user_id, users):
    """従来のエクスポートtxtでの送信者表記を再現する。

    txtは事務アカウント側で名前を変更した人だけ `石井(いしい はじめ)` と括弧付きになり、
    変更していない人は `Masao Kawakami` `田中久士/オンノット` のように素の名前で出る。
    括弧の有無は事務アカウントの登録状態次第で、Messaging APIからは判別できない。
    そこで次の順に解決する:

      1. line_users.player_name … 明示的な登録（LINE収集/user_mapping.sql）。
         LINE側でプロフィール名を変えた人はここで上書きする必要がある
      2. line_name_map.json     … 過去のエクスポートから作った対応表。
         プロフィール名が当時のままの人は、初投稿の時点で自動的に正しい名前になる
      3. 表示名そのまま      … どちらにも無い場合。事務アカウント側で名前を変更して
         いない人は本物のエクスポートでも括弧なしで出るため、それに合わせる
    """
    u = users.get(user_id) or {}
    name = (u.get("player_name") or "").strip()
    if name:
        return name
    disp = (u.get("display_name") or "").strip()
    if not disp:
        return user_id or "不明"
    return name_map().get(disp) or disp


def render(events, users, unsent_ids, start_date=None):
    """イベント列 → エクスポートtxt形式の行リスト。

    start_date に日付文字列('YYYY.MM.DD')を渡すと、その日付の見出しは再出力しない
    （既存txtへの追記時に日付ヘッダが重複するのを防ぐ）。
    """
    lines, cur_date = [], start_date
    for e in events:
        if e.get("event_type") != "message":
            continue
        dt = parse_ts(e["sent_at"])
        date_str = dt.strftime("%Y.%m.%d")
        if date_str != cur_date:
            lines.append(f"{date_str} {WEEKDAYS[dt.weekday()]}")
            cur_date = date_str
        who = sender_label(e.get("user_id"), users)
        hm = dt.strftime("%H:%M")

        if e.get("message_id") and e["message_id"] in unsent_ids:
            lines.append(f"{hm} {who}がメッセージの送信を取り消しました")
            continue

        mtype = e.get("message_type")
        if mtype == "text":
            body = (e.get("text") or "").replace("\r\n", "\n").replace("\r", "\n")
            head, *tail = body.split("\n")
            lines.append(f"{hm} {who} {head}")
            lines.extend(tail)
        else:
            lines.append(f"{hm} {who} {MEDIA_LABEL.get(mtype, mtype or '')}".rstrip())
    return lines


def read_txt(path):
    """既存txtを改行コードを保ったまま読む。

    ※ Path.read_text / open() の既定は universal newlines で、CRLFがLFに潰れる。
       それに気づかず書き戻すと、本物のエクスポート(CRLF)が1行あたり1バイト縮み、
       さらに scan_existing の行分割が効かなくなって追記位置の判定まで壊れる。
    """
    with open(path, encoding="utf-8", errors="ignore", newline="") as f:
        return f.read()


def scan_existing(text):
    """既存txtから (最終日付, 最終メッセージ時刻, 末尾付近の署名集合) を得る。

    署名は `日付 時刻 送信者+本文先頭` の文字列。追記時の重複除去に使う
    （txtは分精度しかないので、同じ分のメッセージを二重に書かないため）。
    """
    cur_date, last_dt, sigs = None, None, set()
    recent = []  # (date, line) を保持して末尾2日分だけ署名化
    for line in re.split(r"\r\n|\n|\r", text):
        m = re.match(r"^(\d{4})\.(\d{2})\.(\d{2}) ", line)
        if m:
            cur_date = f"{m.group(1)}.{m.group(2)}.{m.group(3)}"
            continue
        m = re.match(r"^(\d{2}):(\d{2}) ", line)
        if m and cur_date:
            y, mo, d = (int(x) for x in cur_date.split("."))
            last_dt = datetime(y, mo, d, int(m.group(1)), int(m.group(2)), tzinfo=JST)
            recent.append((cur_date, line))
    for date_str, line in recent[-2000:]:
        sigs.add(f"{date_str} {line}")
    return cur_date, last_dt, sigs


# ══════════════════════════════════════════════════════════
#  メイン
# ══════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fresh", action="store_true",
                    help="前回run_を引き継がずDB内容だけで生成（照合用）")
    ap.add_argument("--dry-run", action="store_true", help="書き込まずに件数だけ表示")
    ap.add_argument("--check-names", action="store_true",
                    help="送信者名がどう解決されるか一覧表示（要手当ての人を洗い出す）")
    ap.add_argument("--rebuild", action="append", default=[], metavar="ルーム名",
                    help="指定ルームをDBから作り直す（複数指定可）。"
                         "送信者名のマッピングを直したときに使う。"
                         "★物理エクスポートでしか取れない過去分は失われるので、"
                         "DBに全履歴があるルームにだけ使うこと")
    ap.add_argument("--keep", type=int, default=3, help="残すrun_フォルダ世代数")
    args = ap.parse_args()

    base_url, key = load_config()

    if args.check_names:
        users = {u["user_id"]: u for u in
                 fetch_all(base_url, key, "line_users",
                           "user_id,display_name,player_name,last_seen_at",
                           order_col="user_id")}
        rows = []
        for uid, u in users.items():
            disp = (u.get("display_name") or "").strip()
            if (u.get("player_name") or "").strip():
                src = "登録済み"
            elif disp and name_map().get(disp):
                src = "対応表"
            else:
                src = "★要手当て"
            rows.append((src, disp or uid, sender_label(uid, users)))
        for src, disp, out in sorted(rows):
            print(f"  [{src}] {disp}  →  {out}")
        todo = sum(1 for r in rows if r[0].startswith("★"))
        print(f"\n送信者 {len(rows)}人 / 要手当て {todo}人"
              + ("（LINE収集/user_mapping.sql に追記してください）" if todo else ""))
        return

    print("Supabaseから取得中...")
    groups = {g["group_id"]: g for g in
              fetch_all(base_url, key, "line_groups",
                        "group_id,name,active", order_col="group_id")}
    users = {u["user_id"]: u for u in
             fetch_all(base_url, key, "line_users",
                       "user_id,display_name,player_name", order_col="user_id")}
    events = fetch_all(base_url, key, "line_events",
                       "id,event_type,group_id,user_id,message_id,message_type,text,sent_at,raw")
    print(f"  ルーム {len(groups)} / 送信者 {len(users)} / イベント {len(events)}")

    # 取り消されたメッセージのIDを集める（本文は元メッセージの位置に置き換える）
    unsent_ids = set()
    for e in events:
        if e.get("event_type") == "unsend":
            mid = (e.get("raw") or {}).get("unsend", {}).get("messageId") or e.get("message_id")
            if mid:
                unsent_ids.add(mid)

    by_group = {}
    for e in events:
        if e.get("group_id"):
            by_group.setdefault(e["group_id"], []).append(e)
    for evs in by_group.values():
        evs.sort(key=lambda x: (x["sent_at"], x["id"]))

    if args.dry_run:
        for gid, evs in sorted(by_group.items(), key=lambda kv: -len(kv[1])):
            name = (groups.get(gid) or {}).get("name") or gid
            msgs = [e for e in evs if e.get("event_type") == "message"]
            span = ""
            if msgs:
                span = (f"  {parse_ts(msgs[0]['sent_at']):%Y/%m/%d} 〜 "
                        f"{parse_ts(msgs[-1]['sent_at']):%Y/%m/%d}")
            print(f"  {name}: {len(msgs)}件{span}")
        print("（--dry-run のため書き込みはしていません）")
        return

    EXPORT_ROOT.mkdir(exist_ok=True)
    export_dir = EXPORT_ROOT / time.strftime("run_%Y%m%d_%H%M%S")
    export_dir.mkdir(parents=True, exist_ok=True)

    # 前回run_の全txtを引き継ぐ。
    # bot未招待のルームは従来の本物エクスポートtxtがそのまま残り、
    # 招待済みルームだけがDBの新着で伸びていく（並走移行のため必須）。
    prev_dir = None
    if not args.fresh:
        prev_runs = sorted(p for p in EXPORT_ROOT.iterdir()
                           if p.is_dir() and p.name.startswith("run_") and p != export_dir)
        # ★空のrun_フォルダは引き継ぎ元にしない（2026-08-12）
        #   line_export_auto.py の掃除は rmtree(ignore_errors=True) なので、
        #   OneDriveにロックされたファイルがあると空フォルダが残る。それを掴むと
        #   物理エクスポート専用ルーム(蜂・大分)のtxtが引き継がれず、DBにも無いため
        #   丸ごと消える。しかも例外は出ないので気づけない。中身のある世代まで遡る。
        prev_dir = next((p for p in reversed(prev_runs) if any(p.glob("*.txt"))), None)
        seed = prev_dir or EXPORT_ROOT
        for txt in seed.glob("*.txt"):
            shutil.copy2(txt, export_dir / txt.name)

    written = 0
    for gid, evs in by_group.items():
        g = groups.get(gid) or {}
        name = g.get("name")
        if not name:
            # 参加直後に自動退会したルーム（先住の公式アカウントがいる場合）は
            # join/leaveしか無く名前も取れない。警告は本文のあるルームだけに出す。
            if any(e.get("event_type") == "message" for e in evs):
                print(f"  [skip] ルーム名が未取得: {gid}（line_groups.name を手動で埋めてください）")
            continue
        out_path = export_dir / f"[LINE]{name}.txt"

        base_text = ""
        if not args.fresh and name not in args.rebuild and out_path.exists():
            base_text = read_txt(out_path)

        if base_text.strip():
            last_date, last_dt, sigs = scan_existing(base_text)
            fresh_evs = [e for e in evs
                         if last_dt is None or parse_ts(e["sent_at"]) >= last_dt]
            new_lines = render(fresh_evs, users, unsent_ids, start_date=last_date)
            # 既存txtに既にある行（同じ分に入った重複）は落とす
            cur = last_date
            deduped = []
            for line in new_lines:
                m = re.match(r"^(\d{4})\.(\d{2})\.(\d{2}) ", line)
                if m:
                    cur = f"{m.group(1)}.{m.group(2)}.{m.group(3)}"
                    deduped.append(line)
                    continue
                if re.match(r"^\d{2}:\d{2} ", line) and f"{cur} {line}" in sigs:
                    continue
                deduped.append(line)
            new_lines = deduped
            if not any(re.match(r"^\d{2}:\d{2} ", l) for l in new_lines):
                continue  # 新着なし
            # 既存部分は1バイトも変えない。末尾の空行はメッセージ本文の一部なので
            # rstripしてはいけない（元ファイルは ...\r\n\r\n で終わることがある）。
            sep = "" if base_text.endswith(("\r\n", "\n")) else "\r\n"
            text = base_text + sep + "\r\n".join(new_lines) + "\r\n"
        else:
            lines = render(evs, users, unsent_ids)
            if not lines:
                continue
            text = "\r\n".join(lines) + "\r\n"

        out_path.write_text(text, encoding="utf-8", newline="")
        written += 1
        print(f"  書き出し: {out_path.name}")

    # 古いrun_は指定世代だけ残す
    try:
        old = sorted(p for p in EXPORT_ROOT.iterdir()
                     if p.is_dir() and p.name.startswith("run_"))
        for p in old[:-args.keep]:
            shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass

    print(f"\n完了: {export_dir}")
    print(f"  DBから更新したルーム {written} 件"
          + (f" / 前回から引き継ぎ {prev_dir.name}" if prev_dir else ""))


if __name__ == "__main__":
    main()
