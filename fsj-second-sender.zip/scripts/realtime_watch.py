#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""realtime_watch.py — LINEの新着を「入った瞬間」に受け取る。

★なぜ必要か:
  2秒ごとに聞きに行く方式だと、最悪2秒の遅れが出る。セカンドは
  受取から15分が期限で、プレイヤーを待たせるほど不利になるので、
  ここは速いほど良い。何も起きていないのに通信が発生するのも無駄。

★取りこぼさないための考え方:
  この仕組みは「速くするための補助」であって、正しさの根拠にはしない。
  接続が切れている間の分は届かないので、本体側は今まで通り
  一定間隔でも確認する（ただし間隔は長くてよい）。
  つまり「通知が来たらすぐ動く / 来なくても保険で動く」の二段構え。

使い方:
    w = Watcher(url, key)
    w.start()
    ...
    w.wait(60)      # 新着が来るまで最大60秒待つ（来たら即座に返る）
"""

import json
import threading
import time
from urllib.parse import urlparse

TOPIC = "realtime:fsj-second-sender"
HEARTBEAT_SEC = 25          # Supabase側は60秒で切るので、その半分以下で送る
RECONNECT_SEC = 5


class Watcher:
    """別スレッドで接続を張り、新着があったことだけを本体に知らせる。

    本体（送信処理）は一切ここでは動かさない。受け取るのは「何か入った」
    という合図だけで、中身の判断もDB操作も本体側で行う。
    こうしておくと、この仕組みが壊れても送信は止まらない。
    """

    def __init__(self, url, key, table="line_events"):
        host = urlparse(url).hostname
        self._ws_url = (f"wss://{host}/realtime/v1/websocket"
                        f"?apikey={key}&vsn=1.0.0")
        self._table = table
        self._event = threading.Event()
        self._connected = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self.last_error = ""

    # ── 本体から使うもの ──────────────────────────────
    def start(self):
        if self._thread:
            return
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def connected(self, timeout=0.0):
        """購読できている状態か。"""
        return self._connected.wait(timeout) if timeout else self._connected.is_set()

    def wait(self, timeout):
        """新着が来るまで待つ。来たら True。時間切れなら False。"""
        hit = self._event.wait(timeout)
        self._event.clear()
        return hit

    def stop(self):
        self._stop.set()

    # ── 内部 ────────────────────────────────────────
    def _run(self):
        import websocket                      # 同梱済み（送信でも使っている）
        while not self._stop.is_set():
            ws = None
            try:
                # Chrome 111以降と同じ理由で Origin は送らない
                ws = websocket.create_connection(self._ws_url, timeout=20,
                                                 suppress_origin=True)
                ws.send(json.dumps({
                    "topic": TOPIC, "event": "phx_join", "ref": "1",
                    "payload": {"config": {"postgres_changes": [
                        {"event": "INSERT", "schema": "public",
                         "table": self._table}]}}}))
                threading.Thread(target=self._beat, args=(ws,),
                                 daemon=True).start()
                self._listen(ws)
            except Exception as e:
                self.last_error = str(e)[:120]
            finally:
                self._connected.clear()
                if ws is not None:
                    try:
                        ws.close()
                    except Exception:
                        pass
            if not self._stop.is_set():
                time.sleep(RECONNECT_SEC)

    def _beat(self, ws):
        n = 100
        while not self._stop.is_set():
            time.sleep(HEARTBEAT_SEC)
            try:
                ws.send(json.dumps({"topic": "phoenix", "event": "heartbeat",
                                    "payload": {}, "ref": str(n)}))
                n += 1
            except Exception:
                return

    def _listen(self, ws):
        while not self._stop.is_set():
            msg = json.loads(ws.recv())
            ev = msg.get("event")
            if ev == "postgres_changes":
                self._event.set()
            elif ev == "phx_reply":
                if (msg.get("payload") or {}).get("status") == "ok":
                    self._connected.set()
                    self.last_error = ""
            elif ev == "system":
                # 購読できなかった理由はここに来る（publication未登録など）
                p = msg.get("payload") or {}
                if p.get("status") == "error":
                    self.last_error = str(p.get("message"))[:120]
                    self._connected.clear()
                    raise RuntimeError(self.last_error)
