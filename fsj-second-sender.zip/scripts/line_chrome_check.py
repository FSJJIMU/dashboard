#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""line_chrome_check.py — Chrome版LINEに接続できるか確認する（送信はしない）。

セカンド自動送信は、Chrome拡張版LINEをCDP（デバッグポート9223）経由で操作する。
マウスもキーボードも奪わないので事務員は普通に作業できるが、そのぶん
「Chromeが起動しているか」「LINEにログインしているか」を先に確かめる必要がある。

使い方:
    python -X utf8 scripts/line_chrome_check.py
"""

import json
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

PORT = 9223

# LINE公式のChrome拡張。IDは動いているプロファイルから実測した値。
# ★ストアには名前も見た目も似た別物があるので、必ずこのIDで開く。
#   検索させると、事務員がどれを入れればよいか分からない。
LINE_EXT_ID = "ophjlpahpchlmihnnnihgmmeilfjmjjc"
LINE_PAGE_URL = f"chrome-extension://{LINE_EXT_ID}/index.html"
LINE_STORE_URL = f"https://chromewebstore.google.com/detail/{LINE_EXT_ID}"


def profile_dir():
    """このPCのLINE用Chromeプロファイル。

    共有フォルダにもインストール先にも置かない。中身はその人のLINEログインで、
    フォルダごとコピーされると別人のアカウントから送信されてしまう。
    """
    import os
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "FSJ" / "chrome_line_profile"
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "FSJ" / "chrome_line_profile"


def find_chrome():
    import os
    if sys.platform == "darwin":
        p = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
        return p if p.exists() else None
    for var in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        root = os.environ.get(var)
        if not root:
            continue
        p = Path(root) / "Google" / "Chrome" / "Application" / "chrome.exe"
        if p.exists():
            return p
    return None


def is_installed():
    """LINE拡張がこの専用プロファイルに入っているか。

    ★普段使いのChromeに入れても意味がない。
      専用プロファイルは何も入っていない新品なので、拡張もログインも
      ここに入れ直す必要がある。「LINEは入れたのに動かない」の大半がこれ。
    """
    import json as _json
    for name in ("Secure Preferences", "Preferences"):
        f = profile_dir() / "Default" / name
        if not f.exists():
            continue
        try:
            d = _json.loads(f.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            continue
        if LINE_EXT_ID in ((d.get("extensions") or {}).get("settings") or {}):
            return True
    return False


def open_in_chrome(url):
    """起動済みの専用Chromeに、指定のURLでタブを開く。

    同じ --user-data-dir でchrome.exeを呼ぶと、新しい窓ではなく
    既に動いている方にタブが増える。事務員に探させずに済む。
    """
    import subprocess
    chrome = find_chrome()
    if not chrome:
        return False
    try:
        subprocess.Popen([str(chrome), f"--user-data-dir={profile_dir()}", url],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def launch_chrome():
    """LINE用のChromeを起動する。

    ★ウィザードから直接呼ぶ。別のbatを新しい窓で開くと、
      窓が2つになり「どちらにキーを押すのか」で必ず迷う。
    """
    import subprocess
    chrome = find_chrome()
    if not chrome:
        print("[NG] Google Chrome が見つかりません。")
        print("     https://www.google.com/chrome/ からインストールしてください。")
        return False
    prof = profile_dir()
    prof.mkdir(parents=True, exist_ok=True)
    subprocess.Popen([str(chrome), f"--remote-debugging-port={PORT}",
                      f"--user-data-dir={prof}",
                      # ★最小化・別デスクトップでの速度低下を抑える。
                      #   実測（最小化・3秒あたり）: 付けないとページの
                      #   タイマーが3回しか進まず、付けると60回。
                      #   画面更新(rAF)は隠れると必ず止まるので、
                      #   出したままが最速なのは変わらないが差は縮む。
                      "--disable-background-timer-throttling",
                      "--disable-backgrounding-occluded-windows",
                      "--disable-renderer-backgrounding"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True


def launched_notice():
    """起動直後の案内。batは純ASCIIにする必要があるので日本語はここで出す。"""
    print("Chromeを起動しました。")
    print()
    print("【初回のみ】")
    print("  1. Chromeの拡張機能ストアからLINEを追加する")
    print("  2. 自分のLINEアカウントでログインする")
    print()
    print("2回目以降はログイン状態が残るので、この操作は不要です。")
    print("普段使いのChromeとは別のプロファイルなので、履歴やブックマークは混ざりません。")
    print()


def wait_for_login(limit_sec=600):
    """ログインが済むまで待つ。

    ★キー入力待ちにしない。
      別ウィンドウで開くため手前に無いことが多く、押しても反応しないように
      見える（クリックでコンソールが選択モードに入ると本当に反応しない）。
      画面を見て判断せず、LINEが開いたことを自分で検知する。
    """
    import time
    print("LINEが開くのを待っています（済んだら自動で次へ進みます）")
    print("  やめるときはこのウィンドウを閉じてください。")
    last = None
    opened, stored = False, False
    for i in range(limit_sec // 3):
        state = probe()
        # 待たせる前に、開けるものは自分で開く。
        if state == "noext" and not opened:
            opened = open_in_chrome(LINE_PAGE_URL)
        if state == "notinstalled" and not stored:
            stored = open_in_chrome(LINE_STORE_URL)
            if stored:
                print("  ストアのLINEのページを開きました。")
                print("  「Chromeに追加」を押してください。")
        if state == "ok":
            print("\nLINEを確認しました。")
            return 0
        msg = {"noport": "  Chromeの起動を待っています...",
               "noext": "  LINEのページを開いています...",
               "notinstalled": "  拡張機能ストアからLINEを追加してください...",
               "nologin": "  LINEにログインしてください..."}.get(state, "  待機中...")
        if msg != last:
            print(msg)
            last = msg
        time.sleep(3)
    print("\n時間内にLINEを確認できませんでした。あとで診断を実行してください。")
    return 1


def probe():
    """いまの状態を一言で返す。"""
    try:
        with urllib.request.urlopen(f"http://localhost:{PORT}/json", timeout=5) as r:
            targets = json.loads(r.read())
    except Exception:
        return "noport"
    pages = [t for t in targets if t.get("type") == "page"
             and t.get("url", "").startswith("chrome-extension://")]
    if not pages:
        # 「入っていない」と「入っているが開いていない」は直し方が違う。
        # まとめて「LINEを開いてください」と言うと、入れていない人は
        # 開くものが無いので詰まる。
        return "noext" if is_installed() else "notinstalled"
    if not any("LINE" in (t.get("title") or "") for t in pages):
        return "nologin"
    return "ok"


def dump_state():
    """繋がらない理由を突き止めるための実測ダンプ。

    ★推測で直さないための道具。
      「拡張も入れたしLINEも開いている」のに見つからない、という報告が出た。
      よくあるのは**別のChromeを見ている**ケースで、画面を見るだけでは
      どのChromeなのか区別が付かない。プロセスの起動オプションと
      デバッグポートが返す一覧を並べれば、どこがずれているか一目で分かる。
    """
    import subprocess
    print("=" * 60)
    print("  接続できない原因を調べます")
    print("=" * 60)

    prof = profile_dir()
    print(f"\n■ 専用プロファイル")
    print(f"   {prof}")
    print(f"   フォルダあり : {prof.exists()}")
    print(f"   LINE拡張あり : {is_installed()}")

    print(f"\n■ デバッグポート {PORT} が返す一覧")
    try:
        with urllib.request.urlopen(f"http://localhost:{PORT}/json/version",
                                    timeout=5) as r:
            v = json.loads(r.read())
        print(f"   Chrome: {v.get('Browser')}")
    except Exception as e:
        print(f"   ★繋がりません: {str(e)[:70]}")
    try:
        with urllib.request.urlopen(f"http://localhost:{PORT}/json",
                                    timeout=5) as r:
            targets = json.loads(r.read())
    except Exception as e:
        targets = []
        print(f"   ★一覧を取れません: {str(e)[:70]}")
    if not targets:
        print("   （空）")
    for t in targets:
        u = t.get("url", "")
        mark = "★" if u.startswith("chrome-extension://") else "  "
        print(f"   {mark} type={t.get('type'):<14} title={str(t.get('title'))[:34]!r}")
        print(f"        url={u[:88]}")

    print("\n■ 動いている Chrome（どのプロファイルを使っているか）")
    try:
        if sys.platform == "darwin":
            out = subprocess.run(["ps", "-Ao", "command"], capture_output=True,
                                 text=True, errors="replace").stdout or ""
            lines = [l for l in out.splitlines()
                     if "Google Chrome" in l and "--type=" not in l]
        else:
            # ★PowerShellの出力はコンソールの文字コード（日本語Windowsは
            #   Shift-JIS）で返る。UTF-8として読むと日本語のパスで落ちるので、
            #   PowerShell側にUTF-8で出させる。
            ps = ("[Console]::OutputEncoding=[Text.Encoding]::UTF8; "
                  "Get-CimInstance Win32_Process -Filter \"name='chrome.exe'\" | "
                  "Select-Object -ExpandProperty CommandLine")
            out = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                                 capture_output=True, text=True,
                                 encoding="utf-8", errors="replace").stdout or ""
            lines = [l for l in out.splitlines()
                     if l.strip() and "--type=" not in l]
        if not lines:
            print("   Chrome は動いていません")
        for l in lines[:6]:
            port = "9223あり" if "remote-debugging-port=9223" in l else "ポート無し"
            udd = ""
            for part in l.split("--"):
                if part.startswith("user-data-dir="):
                    udd = part[len("user-data-dir="):].strip().strip('"')
            print(f"   [{port}] user-data-dir={udd or '（既定＝普段使いのChrome）'}")
    except Exception as e:
        print(f"   調べられません: {str(e)[:70]}")

    print("\n" + "=" * 60)
    print("  この内容をそのまま管理者に送ってください。")
    print("=" * 60)


def main():
    if "--dump" in sys.argv:
        return dump_state()
    if "--launched" in sys.argv:
        launched_notice()
        return wait_for_login()
    try:
        with urllib.request.urlopen(f"http://localhost:{PORT}/json", timeout=5) as r:
            targets = json.loads(r.read())
    except Exception as e:
        print(f"[NG] Chromeのデバッグポート {PORT} に繋がりません: {e}")
        print("     LINE用Chrome起動.bat から起動してください。")
        return 1

    line_targets = [t for t in targets
                    if t.get("type") == "page"
                    and t.get("url", "").startswith("chrome-extension://")]
    if not line_targets:
        if not is_installed():
            print("[NG] この専用ChromeにLINE拡張機能が入っていません。")
            print("     ★普段使いのChromeに入れても効きません。")
            print("       セカンド自動送信は専用のChromeを使うので、そちらに入れます。")
            if open_in_chrome(LINE_STORE_URL):
                print("     ストアのページを開きました。「Chromeに追加」を押してください。")
            else:
                print(f"     {LINE_STORE_URL}")
            print()
            dump_state()
            return 2
        print("[NG] LINEは入っていますが、ページが開かれていません。")
        if open_in_chrome(LINE_PAGE_URL):
            print("     いま開きました。数秒待ってからもう一度実行してください。")
        else:
            print("     Chromeの中でLINEを開いてください。")
        print()
        dump_state()
        return 2

    logged_in = [t for t in line_targets if "LINE" in (t.get("title") or "")]
    if not logged_in:
        titles = ", ".join(repr(t.get("title")) for t in line_targets)
        print(f"[NG] LINEのページはありますが、状態が想定と違います（title={titles}）")
        print("     ログインが済んでいるか確認してください。")
        return 3

    print("[OK] Chrome版LINEに接続できます。自動送信の準備ができました。")

    # 送信はせず、compose欄が見つかるかだけ確認する
    try:
        import websocket
        # Chrome 111以降は Origin 付きのCDP接続を拒否するため送らない
        ws = websocket.create_connection(logged_in[0]["webSocketDebuggerUrl"],
                                         timeout=5, suppress_origin=True)
        # LINE拡張の入力欄は <textarea-ex> というカスタム要素。
        # 素の textarea では見つからないので注意。
        EXPR = ("JSON.stringify({compose:"
                "document.querySelectorAll('textarea-ex').length,"
                "list:document.querySelectorAll("
                "'[class*=\"chatlistItem-module__chatlist_item\"]').length})")
        ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate",
                            "params": {"expression": EXPR,
                                       "returnByValue": True}}))
        # ★開いた直後は0件で当たり前。LINEは開いてから一覧を取りに行くので、
        #   すぐ数えると「0件です」と出て、直しようのない指示になる。
        #   出てくるまで少し待ってから数える。
        import time as _t
        info = {}
        deadline = _t.time() + 15
        while True:
            res = json.loads(ws.recv())
            info = json.loads(
                res.get("result", {}).get("result", {}).get("value") or "{}")
            if info.get("list") or _t.time() > deadline:
                break
            _t.sleep(1)
            ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate",
                                "params": {"expression": EXPR,
                                           "returnByValue": True}}))
        ws.close()
        print(f"     トーク一覧: {info.get('list', 0)}件 / 入力欄: {info.get('compose', 0)}個")
        if not info.get("list"):
            print("     ※ トーク一覧が出てきません。")
            print("        LINEの左端にある「トーク」のタブを開いてください。")
            print("        （窓が狭いと一覧が隠れることがあります。広げてみてください）")
    except ImportError:
        print("     ※ websocket-client が未インストールです: pip install websocket-client")
    except Exception as e:
        print(f"     ※ 画面の確認は省略しました: {e}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
