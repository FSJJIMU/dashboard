#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""self_update.py — 常駐を始める前に、新しい版があれば取り込む。

★なぜ必要か:
  直すたびに全員へ「落とし直して、設定ファイルは残して上書きして」と
  頼むのは現実的でない。実際に1日で2回発生した。
  起動のたびにここが見に行けば、事務員は何もしなくてよくなる。

★入れ替えるのは scripts/*.py だけ。
  起動用の .bat は、cmd が実行中に読み進めているファイルなので、
  上書きすると途中から違う行を読んで誤動作する。python-embed も
  自分自身が使っている最中で置き換えられない。
  それらに変更があった場合は「セットアップをやり直してください」と出す。
"""

import io
import json
import sys
import urllib.request
import zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
MARK = SCRIPT_DIR / ".version.json"
URL = "https://fsjjimu.github.io/dashboard/fsj-second-sender.zip"

# 個人の設定。配布物には入っていないが、念のため二重に守る。
KEEP = {"line_log.json", "second_sender.json", "player_master.csv",
        ".version.json"}


def remote_stamp():
    """本体を落とさずに「変わったか」だけ見る。"""
    req = urllib.request.Request(URL, method="HEAD")
    with urllib.request.urlopen(req, timeout=20) as r:
        return {"etag": r.headers.get("ETag") or "",
                "modified": r.headers.get("Last-Modified") or "",
                "length": r.headers.get("Content-Length") or ""}


def load_mark():
    try:
        return json.loads(MARK.read_text(encoding="utf-8"))
    except Exception:
        return {}


def main():
    try:
        stamp = remote_stamp()
    except Exception as e:
        # 更新できないだけで送信はできる。止めない。
        print(f"[情報] 更新の確認をとばしました（{str(e)[:50]}）")
        return 0

    if stamp and stamp == load_mark().get("stamp"):
        return 0

    print("新しい版があるか確認しています...")
    try:
        with urllib.request.urlopen(URL, timeout=120) as r:
            blob = r.read()
    except Exception as e:
        print(f"[情報] 取得できませんでした（{str(e)[:50]}）。今の版で動きます。")
        return 0

    updated, other = [], []
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        for name in z.namelist():
            if name.endswith("/"):
                continue
            parts = name.split("/")
            new = z.read(name)

            if parts[0] == "scripts" and len(parts) == 2:
                if parts[1] in KEEP:
                    continue
                cur = SCRIPT_DIR / parts[1]
                if cur.exists() and cur.read_bytes() == new:
                    continue
                cur.write_bytes(new)
                updated.append(parts[1])
                continue

            # .bat / .command / python-embed は実行中で置き換えられない。
            # 変わっていることだけ伝える。
            cur = PROJECT_DIR / Path(*parts)
            if not cur.exists() or cur.read_bytes() != new:
                other.append(name)

    if updated:
        print(f"更新しました: {', '.join(sorted(updated))}")
    else:
        print("すでに最新です。")

    if other:
        print()
        print("[!] 起動用ファイルにも更新があります。")
        print("    このまま使えますが、手が空いたら「fsj-setup」を")
        print("    もう一度ダブルクリックして入れ直してください。")
        for n in sorted(other)[:5]:
            print(f"      - {n}")
        print()
        # ★ここでは記録しない。
        #   記録すると次回は「最新」と判断して確認を飛ばし、この案内が
        #   二度と出なくなる。古い起動ファイルのまま気づかず使い続けることに
        #   なるので、入れ直すまで毎回言い続ける。
        return 0

    MARK.write_text(json.dumps({"stamp": stamp}, ensure_ascii=False, indent=1),
                    encoding="utf-8")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(f"[情報] 更新処理でエラー（{str(e)[:60]}）。今の版で続けます。")
        sys.exit(0)
