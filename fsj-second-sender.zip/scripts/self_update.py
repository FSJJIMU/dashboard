#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""self_update.py — 常駐を始める前に、新しい版があれば取り込む。

★なぜ必要か:
  直すたびに全員へ「落とし直して、設定ファイルは残して上書きして」と
  頼むのは現実的でない。実際に1日で2回発生した。
  起動のたびにここが見に行けば、事務員は何もしなくてよくなる。

★入れ替えるのは scripts/*.py だけ。
  起動用の .bat は、cmd が実行中に読み進めているファイルなので、
  上書きすると途中から違う行を読んで誤動作する。python-embed も
  自分自身が使っている最中で置き換えられない。
  それらに変更があった場合は「セットアップをやり直してください」と出す。
"""

import io
import json
import sys
import urllib.request
import os
import zipfile
from pathlib import Path

# このPCのOS。配布物には両方の起動ファイルが入っているので、
# 自分のOSのものだけを見るために使う。
_OS_DIR = "Mac" if sys.platform == "darwin" else "Windows"

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
MARK = SCRIPT_DIR / ".version.json"
URL = "https://fsjjimu.github.io/dashboard/fsj-second-sender.zip"

# 個人の設定。配布物には入っていないが、念のため二重に守る。
KEEP = {"line_log.json", "second_sender.json", "player_master.csv",
        "line_tab.json",
        ".version.json"}


def remote_stamp():
    """本体を落とさずに「変わったか」だけ見る。"""
    req = urllib.request.Request(URL, method="HEAD")
    with urllib.request.urlopen(req, timeout=20) as r:
        return {"etag": r.headers.get("ETag") or "",
                "modified": r.headers.get("Last-Modified") or "",
                "length": r.headers.get("Content-Length") or ""}


def load_mark():
    try:
        return json.loads(MARK.read_text(encoding="utf-8"))
    except Exception:
        return {}


# 常駐起動から呼ばれたときに「いま動いている起動用ファイル」。
# ★これだけは差し替えない。
#   実測: 実行中の .bat を差し替えると cmd の読み位置がずれ、
#   途中で止まる（最後の行が実行されないことを確認済み）。
#   Python は丸ごと読んでから動くので差し替えても安全。
_LAUNCHER_EXT = ".command" if sys.platform == "darwin" else ".bat"
RUNNING_LAUNCHER = f"{_OS_DIR}/セカンド自動送信_常駐起動{_LAUNCHER_EXT}"


def replace_file(path, data):
    """壊れた版が残らないように、書いてから差し替える。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".new")
    try:
        tmp.write_bytes(data)
        os.replace(tmp, path)
        if path.suffix == ".command":
            os.chmod(path, 0o755)     # zip経由で実行権限が落ちるため
        return True
    except Exception:
        try:
            tmp.unlink()
        except Exception:
            pass
        return False


def notice(names):
    """動かしたままでは入れ替えられなかったものを伝える。"""
    print()
    print("[!] 動かしたままでは入れ替えられないものが残りました。")
    print("    このまま使えます。急がないので、手が空いたときに入れ直してください。")
    if sys.platform == "darwin":
        # Macに fsj-setup.bat は無い。1行を貼り直すのが入れ直し方。
        print("    ターミナルに、この1行をもう一度貼ってください:")
        print("      curl -fsSL "
              "https://fsjjimu.github.io/dashboard/fsj-setup.command | bash")
    else:
        print("    「fsj-setup」をもう一度ダブルクリックしてください。")
    for n in sorted(names)[:5]:
        print(f"      - {n}")
    print()


def main():
    try:
        stamp = remote_stamp()
    except Exception as e:
        # 更新できないだけで送信はできる。止めない。
        print(f"[情報] 更新の確認をとばしました（{str(e)[:50]}）")
        return 0

    mark = load_mark()
    if stamp and stamp == mark.get("stamp"):
        # ★同じ版だと分かっているので本体は落とさない。
        #   前回入れ替えられなかったものがあれば、それだけ伝える。
        #   ここで落とし直すと、入れ直すまで毎回10MB取ることになる。
        if mark.get("pending"):
            notice(mark["pending"])
        return 0

    # 前回の差し替えが途中で落ちていたら、その置き土産を片付ける。
    # ★探すのは自分が書き込む場所だけ。インストール先を丸ごと走査すると、
    #   共有フォルダに置いている人の環境で3万件を毎回舐めることになる。
    for d in (SCRIPT_DIR, PROJECT_DIR / "Windows", PROJECT_DIR / "Mac"):
        if not d.is_dir():
            continue
        for junk in d.glob("*.new"):
            try:
                junk.unlink()
            except Exception:
                pass

    print("新しい版があるか確認しています...")
    try:
        with urllib.request.urlopen(URL, timeout=120) as r:
            blob = r.read()
    except Exception as e:
        print(f"[情報] 取得できませんでした（{str(e)[:50]}）。今の版で動きます。")
        return 0

    updated, other = [], []
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        for name in z.namelist():
            if name.endswith("/"):
                continue
            parts = name.split("/")
            new = z.read(name)

            if parts[0] == "scripts" and len(parts) == 2:
                if parts[1] in KEEP:
                    continue
                cur = SCRIPT_DIR / parts[1]
                if cur.exists() and cur.read_bytes() == new:
                    continue
                cur.write_bytes(new)
                updated.append(parts[1])
                continue

            # ★自分のOSのものだけ見る。
            #   配布物にはWindows用とMac用の両方が入っている。区別せずに
            #   数えると、Windowsで動かしているのに「Mac/…を入れ直して」と
            #   出て、何をすればよいのか分からなくなる（実際にそうなった）。
            if parts[0] in ("Windows", "Mac") and parts[0] != _OS_DIR:
                continue
            # MacはWindows同梱のPythonを使わないので、差があっても関係ない。
            if parts[0] == "python-embed" and sys.platform == "darwin":
                continue

            cur = PROJECT_DIR / Path(*parts)
            if cur.exists() and cur.read_bytes() == new:
                continue

            # ★起動用ファイルも入れ替える。ただし、いま動いている1つは除く。
            #   これで「fsj-setup をやり直してください」がほぼ要らなくなる。
            #   python-embed（Python本体）は実行中なので触らない。
            if parts[0] == "python-embed":
                other.append(name)
            elif name == RUNNING_LAUNCHER:
                other.append(name)
            elif replace_file(cur, new):
                updated.append("/".join(parts[-2:]))
            else:
                other.append(name)

    if updated:
        print(f"更新しました: {', '.join(sorted(updated))}")
    else:
        print("すでに最新です。")

    # ★記録には「入れ替えられなかったもの」も一緒に残す。
    #   こうすると、次回は本体を落とさずに済み、かつ案内は出し続けられる。
    #   ここに残るのは、動かしている本人（常駐起動そのもの）と
    #   同梱のPython本体だけ。それ以外は上で自動的に入れ替わっている。
    MARK.write_text(json.dumps({"stamp": stamp, "pending": sorted(other)},
                               ensure_ascii=False, indent=1), encoding="utf-8")
    if other:
        notice(other)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:
        print(f"[情報] 更新処理でエラー（{str(e)[:60]}）。今の版で続けます。")
        sys.exit(0)
