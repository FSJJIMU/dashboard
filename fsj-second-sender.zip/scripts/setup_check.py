#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""setup_check.py — 事務員のPCでセカンド自動送信が動く状態か診断する。

新しい事務員に渡したとき「何が足りないか」をその場で分かるようにするための確認用。
足りないものがあれば、直し方まで表示する。Windows / Mac の両方で動く。

使い方:
    python -X utf8 scripts/setup_check.py
"""

import json
import platform
import sys
import urllib.request
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))


def in_cloud_folder(path):
    """OneDrive / Dropbox / Google Drive の中にあるか。

    同期サービスはファイルを開いたままにするので、実行中のプログラムと
    奪い合いになる。特にPythonのDLLは起動のたびに読むため当たりやすい。
    """
    import os
    p = str(path).replace("/", "\\").lower()
    for var in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        root = (os.environ.get(var) or "").replace("/", "\\").lower()
        if root and p.startswith(root):
            return os.environ.get(var)
    for name in ("\\onedrive", "\\dropbox", "\\google drive", "\\googleドライブ"):
        if name in p:
            return name.strip("\\")
    return None

OK, NG, WARN = "[OK]", "[NG]", "[△]"
problems = []


def check(label, ok, detail="", fix=""):
    mark = OK if ok else NG
    print(f"  {mark} {label}" + (f" … {detail}" if detail else ""))
    if not ok:
        problems.append((label, fix))
    return ok


def main():
    print("=" * 60)
    print("  セカンド自動送信 セットアップ診断")
    print("=" * 60)
    print(f"  OS: {platform.system()} {platform.release()} / "
          f"Python {sys.version.split()[0]}")
    print()

    # ── 1. Python本体 ──
    print("■ Python")
    check("バージョン 3.8 以上", sys.version_info >= (3, 8),
          f"{sys.version.split()[0]}",
          "python.org から新しいPythonを入れてください")

    # ── 2. 必要なライブラリ ──
    print("\n■ ライブラリ")
    try:
        import websocket  # noqa: F401
        check("websocket-client", True)
    except ImportError:
        check("websocket-client", False, "未インストール",
              "pip install websocket-client")

    # ── 2.5 置き場所 ──
    # OneDrive等の同期フォルダに置くと、同期中にDLLを掴まれて
    # 「python312.dll は Windows 上では実行できない（0xC0000043）」で
    # 起動できなくなる。ファイルは壊れていないので原因が分かりにくい。
    print("\n■ 置き場所")
    cloud = in_cloud_folder(PROJECT_DIR)
    check("クラウド同期フォルダの外にある", not cloud,
          cloud or str(PROJECT_DIR),
          "「fsj-setup」をもう一度動かして、"
          "C:\\FSJセカンド自動送信 に入れ直してください")

    # ── 3. 設定ファイル ──
    print("\n■ 設定ファイル")
    cfg_ok = check("scripts/line_log.json（DB接続情報）",
                   (SCRIPT_DIR / "line_log.json").exists(), "",
                   "「はじめに実行」をダブルクリックして、"
                   "管理者から受け取った送信用キーを貼り付けてください")
    staff = None
    # 手でJSONを書かせない。「はじめに実行」が作るものなので、そう案内する。
    if check("scripts/second_sender.json（自分の識別名）",
             (SCRIPT_DIR / "second_sender.json").exists(), "",
             "「はじめに実行」をダブルクリックして、名前を入力してください"):
        try:
            staff = json.loads(
                (SCRIPT_DIR / "second_sender.json").read_text(encoding="utf-8"))
            check("  staff_key が入っている", bool(staff.get("staff_key")),
                  staff.get("staff_key") or "空",
                  "「はじめに実行」をもう一度動かしてください")
        except Exception as e:
            check("  second_sender.json の形式", False, str(e)[:40],
                  "JSONの書式を確認してください")
    # 配布物には入っていない（氏名とLINE IDのため）。DBから取り込まれる。
    check("scripts/player_master.csv（担当者マスタ）",
          (SCRIPT_DIR / "player_master.csv").exists(), "",
          "「はじめに実行」をダブルクリックすると自動で取り込まれます")

    # ── 4. データベース接続 ──
    print("\n■ データベース")
    url = key = None
    if cfg_ok:
        try:
            import line_pull as lp
            url, key = lp.load_config()
            rooms = lp.fetch_all(url, key, "line_groups", "group_id,name",
                                 order_col="group_id")
            check("Supabaseに接続できる", True, f"ルーム{len(rooms)}件")
        except SystemExit:
            check("Supabaseに接続できる", False, "接続情報が不正",
                  "line_log.json の url と service_key を確認してください")
        except Exception as e:
            check("Supabaseに接続できる", False, str(e)[:50],
                  "ネットワークと line_log.json を確認してください")

    # ── 5. 事務員登録 ──
    if url and staff and staff.get("staff_key"):
        try:
            import second_sender as ss
            rows = ss.api(url, key, "GET", "staff",
                          {"staff_key": f"eq.{staff['staff_key']}",
                           "select": "staff_key,display_name,auto_send"})
            check(f"事務員「{staff['staff_key']}」がDBに登録済み", bool(rows),
                  rows[0]["display_name"] if rows else "未登録",
                  f"管理者に staff テーブルへの登録を依頼してください"
                  f"（staff_key = {staff['staff_key']}）")
        except Exception as e:
            check("事務員の登録確認", False, str(e)[:50], "")

    # ── 6. 送信モード ──
    # テストか本番かは全員共通。どちらで動くのかを必ず目に入れる。
    if url:
        print("\n■ 送信モード")
        try:
            import second_sender as ss
            m = {}
            ss.resolve_test_mode(url, key, m)
            if m["test_mode"]:
                print(f"  {OK} テストモード … プレイヤーには送りません"
                      f"（{m['test_redirect_to']} に送って動作だけ確認します）")
            else:
                print("  [!!] ★本番送信 … "
                      "取得したプレイヤー本人へ実際にセカンドが送られます")
        except Exception as e:
            print(f"  {WARN} モードを確認できません: {str(e)[:50]}")

    # ── 7. Chrome版LINE ──
    print("\n■ Chrome版LINE")
    try:
        with urllib.request.urlopen("http://localhost:9223/json", timeout=3) as r:
            targets = json.loads(r.read())
        line_pages = [t for t in targets if t.get("type") == "page"
                      and t.get("url", "").startswith("chrome-extension://")]
        check("デバッグポート9223に繋がる", True)
        check("LINE拡張機能が開いている", bool(line_pages), "",
              "Chromeの中でLINEを開いてログインしてください")
        if line_pages:
            check("  ログイン済み",
                  any(t.get("title") == "LINE" for t in line_pages), "",
                  "LINEにログインしてください")
    except Exception:
        check("デバッグポート9223に繋がる", False, "未起動",
              "デスクトップの「セカンド自動送信」フォルダにある "
              "LINE用Chrome起動 を実行してください")

    # ── まとめ ──
    print("\n" + "=" * 60)
    if not problems:
        print("  すべて問題ありません。自動送信を開始できます。")
        print("  次: ダッシュボードで自分のトグルをONにしてください。")
        return 0
    print(f"  {len(problems)}件の問題があります:\n")
    for i, (label, fix) in enumerate(problems, 1):
        print(f"  {i}. {label}")
        if fix:
            print(f"     → {fix}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
