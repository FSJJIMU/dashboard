#!/bin/bash
# Mac用: セカンド自動送信クライアントを常駐させる。
# ダッシュボードで自分のトグルがOFFの間は何もしないので、開いたままで構わない。

ROOT=""
for d in "$(dirname "$0")/.." "$(dirname "$0")/../.."; do
  if [ -f "$d/scripts/second_sender.py" ]; then ROOT="$d"; break; fi
done
if [ -z "$ROOT" ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        ダウンロードしたフォルダは、分けずにそのまま置いてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi
cd "$ROOT" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

python3 -X utf8 scripts/second_sender_banner.py

while true; do
  python3 -X utf8 scripts/second_sender.py --live
  echo ""
  echo "[10秒後に再起動します]  終了するには Ctrl+C"
  sleep 10
done
