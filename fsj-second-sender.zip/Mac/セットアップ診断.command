#!/bin/bash
# Mac用: うまく動かないときに、何が足りないかを調べる。

# 自分の居場所を突き止める。
# ★デスクトップの近道（シンボリックリンク）から開かれると $0 がリンク側になる。
#   辿らずに1つ上を見るとデスクトップなので、scripts が見つからず
#   「置き場所が違います」で止まってしまう。必ず実体まで辿る。
SELF="$0"
while [ -L "$SELF" ]; do
  LINK="$(readlink "$SELF")"
  case "$LINK" in
    /*) SELF="$LINK" ;;
    *)  SELF="$(dirname "$SELF")/$LINK" ;;
  esac
done
HERE="$(cd "$(dirname "$SELF")" && pwd -P)"

# scripts フォルダのある場所を探す。ダウンロードした一式では1つ上、
# 共有フォルダでは2つ上にあるため、深さを決め打ちにしない。
ROOT=""
for d in "$HERE/.." "$HERE/../.."; do
  if [ -f "$d/scripts/setup_check.py" ]; then ROOT="$(cd "$d" && pwd -P)"; break; fi
done
if [ -z "$ROOT" ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        ダウンロードしたフォルダは、分けずにそのまま置いてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi
cd "$ROOT" || exit 1

# 使うPythonを決める。FSJ専用の入れ物があればそれを使う。
# ★なぜ専用の入れ物なのか
#   Macの python3 に直接 pip install しようとすると環境によって拒否される
#   （Homebrew版は --user 不可・python.org版/システム版は PEP 668）。
#   セットアップが $ROOT/.venv を作ってそこに部品を入れているので、
#   起動側も同じものを使わないと「入れたのに無い」ことになる。
#   壊れていたら本体のPythonに戻す（診断が理由を教えてくれる）。
PY="$ROOT/.venv/bin/python3"
"$PY" -c "" >/dev/null 2>&1 || PY="$(command -v python3)"
if [ -z "$PY" ]; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

"$PY" -X utf8 scripts/setup_check.py
echo ""
read -r -p "Enterで閉じます"
