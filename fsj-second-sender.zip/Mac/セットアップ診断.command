#!/bin/bash
# Mac用: うまく動かないときに、何が足りないかを調べる。

ROOT=""
for d in "$(dirname "$0")/.." "$(dirname "$0")/../.."; do
  if [ -f "$d/scripts/setup_check.py" ]; then ROOT="$d"; break; fi
done
if [ -z "$ROOT" ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        ダウンロードしたフォルダは、分けずにそのまま置いてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi
cd "$ROOT" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

python3 -X utf8 scripts/setup_check.py
echo ""
read -r -p "Enterで閉じます"
