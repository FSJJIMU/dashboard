#!/bin/bash
# Mac用: LINE拡張機能を動かす専用Chromeを、デバッグポート付きで起動する。

ROOT=""
for d in "$(dirname "$0")/.." "$(dirname "$0")/../.."; do
  if [ -f "$d/scripts/line_chrome_check.py" ]; then ROOT="$d"; break; fi
done
if [ -z "$ROOT" ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        ダウンロードしたフォルダは、分けずにそのまま置いてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi
cd "$ROOT" || exit 1

# プロファイルには「この人のLINEログイン」が入る。共有フォルダの中に置くと、
# フォルダをコピーしただけで他人のPCにログインごと渡ってしまい、
# 別人のアカウントから送信される事故になる。必ず個人の領域に置く。
PROFILE="$HOME/Library/Application Support/FSJ/chrome_line_profile"
CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

if [ ! -x "$CHROME" ]; then
  echo "[エラー] Google Chrome が見つかりません。"
  echo "        /Applications にインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

if curl -s --max-time 2 http://localhost:9223/json >/dev/null 2>&1; then
  python3 -X utf8 scripts/line_chrome_check.py
  read -r -p "Enterで閉じます"
  exit 0
fi

mkdir -p "$PROFILE"
"$CHROME" --remote-debugging-port=9223 --user-data-dir="$PROFILE" >/dev/null 2>&1 &

python3 -X utf8 scripts/line_chrome_check.py --launched
read -r -p ""
python3 -X utf8 scripts/line_chrome_check.py
read -r -p "Enterで閉じます"
