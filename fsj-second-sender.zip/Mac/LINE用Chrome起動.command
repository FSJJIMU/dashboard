#!/bin/bash
# Mac用: LINE拡張機能を動かす専用Chromeを、デバッグポート付きで起動する。

# 自分の居場所を突き止める。
# ★デスクトップの近道（シンボリックリンク）から開かれると $0 がリンク側になる。
#   辿らずに1つ上を見るとデスクトップなので、scripts が見つからず
#   「置き場所が違います」で止まってしまう。必ず実体まで辿る。
SELF="$0"
while [ -L "$SELF" ]; do
  LINK="$(readlink "$SELF")"
  case "$LINK" in
    /*) SELF="$LINK" ;;
    *)  SELF="$(dirname "$SELF")/$LINK" ;;
  esac
done
HERE="$(cd "$(dirname "$SELF")" && pwd -P)"

# scripts フォルダのある場所を探す。ダウンロードした一式では1つ上、
# 共有フォルダでは2つ上にあるため、深さを決め打ちにしない。
ROOT=""
for d in "$HERE/.." "$HERE/../.."; do
  if [ -f "$d/scripts/line_chrome_check.py" ]; then ROOT="$(cd "$d" && pwd -P)"; break; fi
done
if [ -z "$ROOT" ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        ダウンロードしたフォルダは、分けずにそのまま置いてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi
cd "$ROOT" || exit 1

# 使うPythonを決める。FSJ専用の入れ物があればそれを使う。
# ★なぜ専用の入れ物なのか
#   Macの python3 に直接 pip install しようとすると環境によって拒否される
#   （Homebrew版は --user 不可・python.org版/システム版は PEP 668）。
#   セットアップが $ROOT/.venv を作ってそこに部品を入れているので、
#   起動側も同じものを使わないと「入れたのに無い」ことになる。
#   壊れていたら本体のPythonに戻す（診断が理由を教えてくれる）。
PY="$ROOT/.venv/bin/python3"
"$PY" -c "" >/dev/null 2>&1 || PY="$(command -v python3)"
if [ -z "$PY" ]; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

# プロファイルには「この人のLINEログイン」が入る。共有フォルダの中に置くと、
# フォルダをコピーしただけで他人のPCにログインごと渡ってしまい、
# 別人のアカウントから送信される事故になる。必ず個人の領域に置く。

# ── LINE用Chromeを起動する ────────────────────────────
PROFILE="$HOME/Library/Application Support/FSJ/chrome_line_profile"
CHROME_ARGS=(
  --remote-debugging-port=9223
  "--user-data-dir=$PROFILE"
  # 最小化や別のデスクトップに置いても速度が落ちないようにする。
  # 実測（最小化・3秒あたり）: 付けないとタイマー3回、付けると60回。
  --disable-background-timer-throttling
  --disable-backgrounding-occluded-windows
  --disable-renderer-backgrounding
)

start_chrome() {
  mkdir -p "$PROFILE"
  # 置き場所は人によって違う。よくある場所を順に見て、
  # 見つからなければmacOSに探させる。1か所の決め打ちだと
  # そこに無い人は「何も起きない」で終わってしまう。
  local c
  for c in "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
           "$HOME/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"; do
    if [ -x "$c" ]; then
      "$c" "${CHROME_ARGS[@]}" >/dev/null 2>&1 &
      return 0
    fi
  done
  if open -na "Google Chrome" --args "${CHROME_ARGS[@]}" >/dev/null 2>&1; then
    return 0
  fi
  return 1
}

chrome_up() { curl -s --max-time 2 http://localhost:9223/json >/dev/null 2>&1; }

if chrome_up; then
  "$PY" -X utf8 scripts/line_chrome_check.py
  read -r -p "Enterで閉じます"
  exit 0
fi

if ! start_chrome; then
  echo "[エラー] Google Chrome を起動できませんでした。"
  echo "        https://www.google.com/chrome/ からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

# 起動できたか確かめる。黙って失敗すると「押しても何も起きない」に見える。
for _ in $(seq 1 20); do
  chrome_up && break
  sleep 1
done
if ! chrome_up; then
  echo "[エラー] Chrome は起動しましたが、ポート9223に繋がりません。"
  echo "        別のChromeが同じプロファイルを使っている可能性があります。"
  echo "        Chrome をすべて終了してから、もう一度お試しください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

"$PY" -X utf8 scripts/line_chrome_check.py --launched
read -r -p ""
"$PY" -X utf8 scripts/line_chrome_check.py
read -r -p "Enterで閉じます"
