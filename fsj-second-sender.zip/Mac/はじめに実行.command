#!/bin/bash
# Mac用: 初回セットアップ。名前と送信用キーを入れるだけで使える状態になる。

# scripts フォルダのある場所を探す。ダウンロードした一式では1つ上、
# 共有フォルダでは2つ上にあるため、深さを決め打ちにしない。
ROOT=""
for d in "$(dirname "$0")/.." "$(dirname "$0")/../.."; do
  if [ -f "$d/scripts/second_sender.py" ]; then ROOT="$d"; break; fi
done
if [ -z "$ROOT" ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        ダウンロードしたフォルダは、分けずにそのまま置いてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi
cd "$ROOT" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

# Windowsは python-embed に同梱しているが、Macは同梱できないため
# 足りなければここで入れる。入らなくても後の診断で理由が出る。
if ! python3 -c "import websocket" >/dev/null 2>&1; then
  echo "必要な部品を入れています（1分ほどかかることがあります）..."
  python3 -m pip install --user --quiet websocket-client || \
    echo "[!] 自動で入りませんでした。診断結果の指示に従ってください。"
  echo ""
fi

python3 -X utf8 scripts/setup_wizard.py
echo ""
read -r -p "Enterで閉じます"
