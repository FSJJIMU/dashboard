@echo off
chcp 65001 >nul
title FSJ Setup

rem First-run wizard. Uses the bundled Python in python-embed if present,
rem so staff do not need to install anything.
rem NOTE: keep this file ASCII-only. Japanese comes from Python.

call :FINDROOT
if "%ROOT%"=="" goto :NOROOT
cd /d "%ROOT%"

call :FINDPY
if "%PY%"=="" (
    echo.
    echo  Python not found.
    echo  Ask the administrator to restore the "python-embed" folder,
    echo  or install Python from https://www.python.org/
    echo.
    pause
    exit /b 1
)

"%PY%" -X utf8 scripts\setup_wizard.py
echo.
pause
exit /b 0

:NOROOT
echo.
echo  [ERROR] Wrong location.
echo  A "scripts" folder was expected near this file.
echo  Please keep the whole downloaded folder together.
echo.
pause
exit /b 1

rem Find the folder that holds "scripts". It is one level up in the
rem downloaded package and two levels up in the shared folder, so try both
rem rather than hard-coding a depth.
:FINDROOT
set "ROOT="
for %%d in ("%~dp0.." "%~dp0..\..") do (
    if not defined ROOT if exist "%%~fd\scripts\second_sender.py" set "ROOT=%%~fd"
)
goto :eof

:FINDPY
set "PY="
if exist "%ROOT%\python-embed\python.exe" set "PY=%ROOT%\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
