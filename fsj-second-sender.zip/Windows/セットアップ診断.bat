@echo off
chcp 65001 >nul
title FSJ Setup Check

rem Diagnoses whether this PC is ready to run the second auto-sender.
rem NOTE: keep this file ASCII-only. Japanese messages come from Python.

call :FINDROOT
if "%ROOT%"=="" goto :NOROOT
cd /d "%ROOT%"

call :FINDPY
if "%PY%"=="" (
    echo [ERROR] Python not found in PATH.
    echo         Install Python from https://www.python.org/
    echo         and check "Add python.exe to PATH" during setup.
    goto :END
)

"%PY%" -X utf8 scripts\setup_check.py

:END
echo.
pause
exit /b 0

:NOROOT
echo.
echo  [ERROR] Wrong location.
echo  A "scripts" folder was expected near this file.
echo  Please keep the whole downloaded folder together.
echo.
pause
exit /b 1

:FINDROOT
set "ROOT="
for %%d in ("%~dp0.." "%~dp0..\..") do (
    if not defined ROOT if exist "%%~fd\scripts\second_sender.py" set "ROOT=%%~fd"
)
goto :eof

:FINDPY
set "PY="
if exist "%ROOT%\python-embed\python.exe" set "PY=%ROOT%\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
