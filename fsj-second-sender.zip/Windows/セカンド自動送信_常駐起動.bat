@echo off
chcp 65001 >nul
title FSJ Second Auto Sender

rem Daily entry point. Deliberately tiny: it only finds Python and hands over
rem to scripts\resident.py, which does the real work (update, Chrome, sender).
rem
rem WHY THIS FILE MUST STAY SMALL AND STABLE
rem   A running .bat cannot be swapped: cmd reads it a piece at a time, so
rem   replacing it mid-run makes it stop partway (measured - the last line
rem   never ran). Python files are read in full before running, so they can be
rem   replaced safely. Keeping the logic in Python means a normal double-click
rem   picks up every change; only this shim would ever need a reinstall.
rem NOTE: keep this file ASCII-only. Japanese messages are printed by Python.

call :FINDROOT
if "%ROOT%"=="" goto :NOROOT
cd /d "%ROOT%"

call :FINDPY
if "%PY%"=="" goto :NOPY

"%PY%" -X utf8 scripts\resident.py
echo.
pause
exit /b 0

:NOPY
echo.
echo  [ERROR] Python not found.
echo  Ask the administrator to restore the "python-embed" folder,
echo  or install Python from https://www.python.org/
echo.
pause
exit /b 1

:NOROOT
echo.
echo  [ERROR] Wrong location.
echo  A "scripts" folder was expected near this file.
echo  Please run "fsj-setup" again.
echo.
pause
exit /b 1

:FINDROOT
set "ROOT="
for %%d in ("%~dp0.." "%~dp0..\..") do (
    if not defined ROOT if exist "%%~fd\scripts\second_sender.py" set "ROOT=%%~fd"
)
goto :eof

:FINDPY
set "PY="
if exist "%ROOT%\python-embed\python.exe" set "PY=%ROOT%\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
