@echo off
chcp 65001 >nul
title FSJ Second Auto Sender

rem Daily entry point. Does everything needed to start sending:
rem   1. pick up a newer version if one was published
rem   2. start Chrome with the LINE extension if it is not up
rem   3. keep second_sender.py running
rem It does nothing while this staff member's toggle is OFF on the dashboard,
rem so it is safe to leave running all day.
rem NOTE: keep this file ASCII-only. Japanese messages are printed by Python.

call :FINDROOT
if "%ROOT%"=="" goto :NOROOT
cd /d "%ROOT%"

call :FINDPY
if "%PY%"=="" (
    echo [ERROR] Python not found in PATH.
    pause
    exit /b 1
)

rem ---- 1. update ----
"%PY%" -X utf8 scripts\self_update.py

rem ---- 2. Chrome with the LINE extension ----
"%PY%" -c "import urllib.request;urllib.request.urlopen('http://localhost:9223/json',timeout=2)" >nul 2>&1
if not errorlevel 1 goto :CHROMEOK

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" (
    echo [ERROR] Chrome not found.
    pause
    exit /b 1
)

rem The profile holds THIS staff member's LINE login, so it lives outside the
rem shared folder. Keeping it under LOCALAPPDATA also stops OneDrive syncing it.
set "PROFILE=%LOCALAPPDATA%\FSJ\chrome_line_profile"
if not exist "%PROFILE%" mkdir "%PROFILE%"
start "" "%CHROME%" --remote-debugging-port=9223 --user-data-dir="%PROFILE%"

rem Wait for it to come up (up to about 40 seconds).
for /l %%i in (1,1,20) do (
    "%PY%" -c "import urllib.request;urllib.request.urlopen('http://localhost:9223/json',timeout=2)" >nul 2>&1
    if not errorlevel 1 goto :CHROMEOK
    timeout /t 2 >nul
)

:CHROMEOK
"%PY%" -X utf8 scripts\line_chrome_check.py

rem ---- 3. keep the sender running ----
"%PY%" -X utf8 scripts\second_sender_banner.py

:LOOP
"%PY%" -X utf8 scripts\second_sender.py --live
echo.
echo [restarting in 10s]  Ctrl+C to quit
timeout /t 10 >nul
goto :LOOP

exit /b 0

:NOROOT
echo.
echo  [ERROR] Wrong location.
echo  A "scripts" folder was expected near this file.
echo  Please run "fsj-setup" again.
echo.
pause
exit /b 1

:FINDROOT
set "ROOT="
for %%d in ("%~dp0.." "%~dp0..\..") do (
    if not defined ROOT if exist "%%~fd\scripts\second_sender.py" set "ROOT=%%~fd"
)
goto :eof

:FINDPY
set "PY="
if exist "%ROOT%\python-embed\python.exe" set "PY=%ROOT%\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
