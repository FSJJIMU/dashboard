@echo off
chcp 65001 >nul
title FSJ Second Auto Sender

rem Keeps second_sender.py running. It does nothing while this staff member's
rem toggle is OFF on the dashboard, so it is safe to leave running all day.
rem NOTE: keep this file ASCII-only. Japanese messages are printed by Python.

call :FINDROOT
if "%ROOT%"=="" goto :NOROOT
cd /d "%ROOT%"

call :FINDPY
if "%PY%"=="" (
    echo [ERROR] Python not found in PATH.
    pause
    exit /b 1
)

"%PY%" -X utf8 scripts\second_sender_banner.py

:LOOP
"%PY%" -X utf8 scripts\second_sender.py --live
echo.
echo [restarting in 10s]  Ctrl+C to quit
timeout /t 10 >nul
goto :LOOP

exit /b 0

:NOROOT
echo.
echo  [ERROR] Wrong location.
echo  A "scripts" folder was expected near this file.
echo  Please keep the whole downloaded folder together.
echo.
pause
exit /b 1

:FINDROOT
set "ROOT="
for %%d in ("%~dp0.." "%~dp0..\..") do (
    if not defined ROOT if exist "%%~fd\scripts\second_sender.py" set "ROOT=%%~fd"
)
goto :eof

:FINDPY
set "PY="
if exist "%ROOT%\python-embed\python.exe" set "PY=%ROOT%\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
