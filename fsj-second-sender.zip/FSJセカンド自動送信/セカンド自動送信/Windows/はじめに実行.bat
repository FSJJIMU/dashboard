@echo off
chcp 65001 >nul
cd /d "%~dp0..\.."
title FSJ Setup

rem This folder must stay inside the shared folder, next to "scripts".
rem Copying only this folder gives a confusing "file not found" later,
rem so stop here with a message that says what to do.
if not exist "scripts\second_sender.py" (
    echo.
    echo  [ERROR] Wrong location.
    echo  A "scripts" folder was expected next to this one.
    echo.
    echo  Correct layout:
    echo    FSJ shared folder
    echo      +-- scripts
    echo      +-- python-embed
    echo      +-- this folder
    echo.
    echo  Please copy the WHOLE shared folder, not just this folder.
    echo.
    pause
    exit /b 1
)

rem First-run wizard. Uses the bundled Python in python-embed if present,
rem so staff do not need to install anything.
rem NOTE: keep this file ASCII-only. Japanese comes from Python.

call :FINDPY
if "%PY%"=="" (
    echo.
    echo  Python not found.
    echo  Ask the administrator to restore the "python-embed" folder,
    echo  or install Python from https://www.python.org/
    echo.
    pause
    exit /b 1
)

"%PY%" -X utf8 scripts\setup_wizard.py
echo.
pause
exit /b 0

:FINDPY
set "PY="
if exist "%~dp0..\..\python-embed\python.exe" set "PY=%~dp0..\..\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
