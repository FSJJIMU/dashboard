@echo off
chcp 65001 >nul
cd /d "%~dp0..\.."

rem Diagnoses whether this PC is ready to run the second auto-sender.
rem NOTE: keep this file ASCII-only. Japanese messages come from Python.

if not exist "scripts\setup_check.py" (
    echo.
    echo  [ERROR] Wrong location.
    echo  A "scripts" folder was expected next to this one.
    echo  Please copy the WHOLE shared folder, not just this folder.
    echo.
    pause
    exit /b 1
)

call :FINDPY
if "%PY%"=="" (
    echo [ERROR] Python not found in PATH.
    echo         Install Python from https://www.python.org/
    echo         and check "Add python.exe to PATH" during setup.
    goto :END
)

"%PY%" -X utf8 scripts\setup_check.py

:END
echo.
pause

exit /b 0

:FINDPY
set "PY="
if exist "%~dp0..\..\python-embed\python.exe" set "PY=%~dp0..\..\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
