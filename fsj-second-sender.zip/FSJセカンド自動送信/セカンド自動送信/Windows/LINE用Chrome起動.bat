@echo off
chcp 65001 >nul
cd /d "%~dp0..\.."

rem Chrome for the LINE extension, with remote debugging on port 9223.
rem The sender script talks to this Chrome and injects JavaScript,
rem so it never steals the mouse or keyboard.
rem NOTE: keep this file ASCII-only. Japanese messages are printed by Python.

title FSJ LINE Chrome

if not exist "scripts\line_chrome_check.py" (
    echo.
    echo  [ERROR] Wrong location.
    echo  A "scripts" folder was expected next to this one.
    echo  Please copy the WHOLE shared folder, not just this folder.
    echo.
    pause
    exit /b 1
)

call :FINDPY
if "%PY%"=="" (
    echo.
    echo  Python not found.
    echo  Ask the administrator to restore the "python-embed" folder,
    echo  or install Python from https://www.python.org/
    goto :END
)

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"

if not exist "%CHROME%" (
    echo [ERROR] Chrome not found.
    goto :END
)

rem The profile holds THIS staff member's LINE login, so it must never live
rem inside the shared folder. If it did, copying the folder to another PC
rem would hand over the login and messages would be sent from the wrong
rem account. Keeping it under LOCALAPPDATA also stops OneDrive from syncing it.
set "PROFILE=%LOCALAPPDATA%\FSJ\chrome_line_profile"

"%PY%" -c "import urllib.request;urllib.request.urlopen('http://localhost:9223/json',timeout=2)" >nul 2>&1
if not errorlevel 1 (
    "%PY%" -X utf8 scripts\line_chrome_check.py
    goto :END
)

if not exist "%PROFILE%" mkdir "%PROFILE%"
start "" "%CHROME%" --remote-debugging-port=9223 --user-data-dir="%PROFILE%"

"%PY%" -X utf8 scripts\line_chrome_check.py --launched
pause >nul
"%PY%" -X utf8 scripts\line_chrome_check.py

:END
echo.
pause

exit /b 0

:FINDPY
set "PY="
if exist "%~dp0..\..\python-embed\python.exe" set "PY=%~dp0..\..\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
