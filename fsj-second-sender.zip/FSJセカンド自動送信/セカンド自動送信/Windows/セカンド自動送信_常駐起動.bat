@echo off
chcp 65001 >nul
cd /d "%~dp0..\.."

rem Keeps second_sender.py running. It does nothing while this staff member's
rem toggle is OFF on the dashboard, so it is safe to leave running all day.
rem NOTE: keep this file ASCII-only. Japanese messages are printed by Python.

title FSJ Second Auto Sender

if not exist "scripts\second_sender.py" (
    echo.
    echo  [ERROR] Wrong location.
    echo  A "scripts" folder was expected next to this one.
    echo  Please copy the WHOLE shared folder, not just this folder.
    echo.
    pause
    exit /b 1
)

call :FINDPY
if "%PY%"=="" (
    echo [ERROR] Python not found in PATH.
    pause
    exit /b 1
)

"%PY%" -X utf8 scripts\second_sender_banner.py

:LOOP
"%PY%" -X utf8 scripts\second_sender.py --live
echo.
echo [restarting in 10s]  Ctrl+C to quit
timeout /t 10 >nul
goto :LOOP

exit /b 0

:FINDPY
set "PY="
if exist "%~dp0..\..\python-embed\python.exe" set "PY=%~dp0..\..\python-embed\python.exe" & goto :eof
where python >nul 2>&1
if not errorlevel 1 set "PY=python"
goto :eof
