#!/bin/bash
# Mac用: 初回セットアップ。名前を入れるだけで使える状態になる。
# 初回のみ実行権限が必要: chmod +x "はじめに実行.command"

cd "$(dirname "$0")/../.." || exit 1

if [ ! -f scripts/setup_wizard.py ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        このフォルダの隣に scripts フォルダがある状態にしてください。"
  echo "        共有フォルダ全体をコピーしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

# Windowsは python-embed に同梱しているが、Macは同梱できないため
# 足りなければここで入れる。入らなくても後の診断で理由が出る。
if ! python3 -c "import websocket" >/dev/null 2>&1; then
  echo "必要な部品を入れています（1分ほどかかることがあります）..."
  python3 -m pip install --user --quiet websocket-client || \
    echo "[!] 自動で入りませんでした。診断結果の指示に従ってください。"
  echo ""
fi

python3 -X utf8 scripts/setup_wizard.py
echo ""
read -r -p "Enterで閉じます"
