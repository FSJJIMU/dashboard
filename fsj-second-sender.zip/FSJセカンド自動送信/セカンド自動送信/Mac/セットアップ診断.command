#!/bin/bash
# Mac用: うまく動かないときに、何が足りないかを調べる。
# 初回のみ実行権限が必要: chmod +x "セットアップ診断.command"

cd "$(dirname "$0")/../.." || exit 1

if [ ! -f scripts/setup_check.py ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        このフォルダの隣に scripts フォルダがある状態にしてください。"
  echo "        共有フォルダ全体をコピーしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

python3 -X utf8 scripts/setup_check.py
echo ""
read -r -p "Enterで閉じます"
