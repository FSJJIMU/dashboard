#!/bin/bash
# Mac用: セカンド自動送信クライアントを常駐させる。
# ダッシュボードで自分のトグルがOFFの間は何もしないので、開いたままで構わない。
# 初回のみ実行権限が必要: chmod +x "セカンド自動送信_常駐起動.command"

cd "$(dirname "$0")/../.." || exit 1

# このフォルダは共有フォルダの中（scripts と並ぶ位置）に置く必要がある。
# このフォルダだけコピーすると、後で分かりにくいエラーになるため先に止める。
if [ ! -f scripts/second_sender.py ]; then
  echo "[エラー] 置き場所が違います。"
  echo "        このフォルダの隣に scripts フォルダがある状態にしてください。"
  echo "        共有フォルダ全体をコピーしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[エラー] python3 が見つかりません。"
  echo "        https://www.python.org からインストールしてください。"
  read -r -p "Enterで閉じます"
  exit 1
fi

python3 -X utf8 scripts/second_sender_banner.py

while true; do
  python3 -X utf8 scripts/second_sender.py --live
  echo ""
  echo "[10秒後に再起動します]  終了するには Ctrl+C"
  sleep 10
done
